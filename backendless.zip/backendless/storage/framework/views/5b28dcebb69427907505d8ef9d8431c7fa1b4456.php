<?php $__env->startSection('content'); ?>

<!-- /.register-box -->
<section class="content">
	<div class="row">
		 <div class="col-md-12">
		 	<div class="box-header with-border">
				<h3 class="box-title">Add Restaurant</h3>
			</div>
			<!-- form start -->
            <form class="form-horizontal" action="" method="POST">
              <div class="box-body">
              	<div class="row">
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">City</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="city" id="city" placeholder="Email">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Password</label>

		                  <div class="col-sm-10">
		                    <input type="password" class="form-control" name="password" id="inputPassword3" placeholder="Password">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">GlutenFree</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="glutenFree" id="glutenFree" placeholder="glutenFree">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Halal</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="halal" id="halal" placeholder="Halal">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Kosher</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="kosher" id="kosher" placeholder="kosher">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Name</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="name" id="name"  placeholder="name" data-role="tagsinput">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Occeanwise</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="occeanwise" id="occeanwise" placeholder="Occeanwise">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Phone</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="phone" id="phone" placeholder="phone">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Postal</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="postal" id="postal" placeholder="Postal">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">prov</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="prov" id="prov" placeholder="Prov">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Sideright</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="sideright" id="sideright" placeholder="Sideright">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Spicy</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="spicy" id="spicy" placeholder="spicy">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Street</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="street" id="street" placeholder="Street">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Vegan</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="vegan" id="vegan" placeholder="Vegan">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">vegetarian</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="vegetarian" id="vegetarian" placeholder="Vegetarian">
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">website</label>

		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" name="website" id="website" placeholder="Website">
		                  </div>
		                </div>
					</div>

					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">menuImages</label>

		                  <div class="col-sm-10">
		                    <input type="file[]" multiple class="form-control" name="menuImages" id="menuImages" placeholder="Website">
		                  </div>
		                </div>
					</div>

					
				</div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-default">Cancel</button>
                <button type="submit" class="btn btn-info pull-right">Submit</button>
              </div>
              <!-- /.box-footer -->
            </form>
		 </div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('after.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\backendless\resources\views/admin/editrestaurant.blade.php ENDPATH**/ ?>
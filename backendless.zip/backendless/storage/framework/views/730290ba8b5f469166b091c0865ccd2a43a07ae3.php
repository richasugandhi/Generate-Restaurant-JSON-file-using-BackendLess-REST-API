<?php echo $__env->make('before.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





    <?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('before.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/menuburst/public_html/dashboard/backendless/resources/views/before/layout.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Restaurent | Dashboard</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

  <!-- Bootstrap 3.3.7 -->
  <link href="<?php echo e(asset("/public/bower_components/bootstrap/dist/css/bootstrap.min.css")); ?>" rel="stylesheet" />
  <!-- Font Awesome -->
  <link href="<?php echo e(asset("/public/bower_components/font-awesome/css/font-awesome.min.css")); ?>" rel="stylesheet" />
  <!-- Ionicons -->
  <link href="<?php echo e(asset("/public/bower_components/Ionicons/css/ionicons.min.css")); ?>" rel="stylesheet" />
  <!-- jvectormap -->
  <link href="<?php echo e(asset("/public/bower_components/jvectormap/jquery-jvectormap.css")); ?>" rel="stylesheet" />
  <!-- Theme style -->
  <link href="<?php echo e(asset("/public/bower_components/admin-lte/dist/css/AdminLTE.min.css")); ?>" rel="stylesheet" />
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link href="<?php echo e(asset("/public/bower_components/admin-lte/dist/css/skins/_all-skins.min.css")); ?>" rel="stylesheet" />

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<style type="text/css">
    /* Style the form */
#regForm {
  background-color: #ffffff;
  margin:auto;
      padding: 5px 40px;
}
.allcp-form label {
    color: #ffffff;
    font-weight: 600;
}
.menudetailsform {
    padding: 15px;
    background: #00A1AF;
    margin-bottom: 15px;
}
/* Style the input fields */
input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

/* Make circles that indicate the steps of the form: */
.step {
  /*height: 15px;*/
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none; 
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

/* Mark the active step: */
.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}
.btn-contain {
  display:block;
  width:100%;
}
 .allcp-form .checkbox,
  
  .allcp-form .radio {
  
    cursor: pointer;
  
    position: relative;
  
    margin-right: 5px;
  
    background: #fff;
  
    display: inline-block;
  
    border: 2px solid #fff;
  
    height: 21px;
  
    width: 21px;
  
    top: 4px;
  
    -webkit-border-radius: 2px;
  
    border-radius: 2px;
  
  }
  
  .allcp-form .checkbox:before,
  
  .allcp-form .radio:before {
  
    content: '';
  
    display: none;
  
  }
  
  .allcp-form input:checked + .checkbox:before,
  
  .allcp-form input:checked + .radio:before {
  
    display: block;
  
  }
  
  .allcp-form .checkbox:before {
  
    position: absolute;
  
    top: 5px;
  
    left: 5px;
  
    width: 6px;
  
    height: 3px;
  
    border: solid #fff;
  
    border-width: 0 0 2px 2px;
  
    -webkit-transform: rotate(-45deg);
  
    -moz-transform: rotate(-45deg);
  
    -ms-transform: rotate(-45deg);
  
    -o-transform: rotate(-45deg);
  
    transform: rotate(-45deg);
  
  }
  
  .allcp-form input:checked + .checkbox,
  
  .allcp-form input:checked + .radio {
  
    border: 2px solid #fff;
  
  }
  
  .allcp-form .radio {
  
    -webkit-border-radius: 20px;
  
    -moz-border-radius: 20px;
  
    -o-border-radius: 20px;
  
    border-radius: 20px;
  
  }
  
  .allcp-form .radio:before {
  
    margin: 5px;
  
    width: 7px;
  
    height: 7px;
  
    background: #aaa;
  
    -webkit-border-radius: 10px;
  
    -moz-border-radius: 10px;
  
    -o-border-radius: 10px;
  
    border-radius: 10px;
  
  }
  
  .allcp-form input:not([disabled]):hover + .checkbox,
  
  .allcp-form input:not([disabled]):hover + .radio {
  
    border-color: #aaa;
  
  }
  
  .allcp-form input:focus + .checkbox,
  
  .allcp-form input:focus + .radio {
  
    border-color: #aaa;
  
  }
  
  .allcp-form input:focus + .radio:before {
  
    background: #aaa;
  
  }
  
  .allcp-form input:focus + .checkbox:before {
  
    border-color: #aaa;
  
  }
  
  .allcp-form .switch {
  
    cursor: pointer;
  
    position: relative;
  
    padding-right: 10px;
  
    display: inline-block;
  
    margin-bottom: 5px;
  
    height: 26px;
    width:10%;
    text-align: center;
  
  }
  
  .allcp-form .switch > label {
  
    cursor: pointer;
  
    display: inline-block;
  
    position: relative;
  
    height: 25px;
  
    width: 58px;
  
    color: #fff;
  
    font-size: 10px;
  
    font-weight: bold;
  
    line-height: 20px;
  
    text-align: center;
  
    background: transparent;
  
    border: 2px solid #fff;
  
    text-transform: uppercase;
  
    font-family: Helvetica, Arial, sans-serif;
  
    -webkit-transition: 0.3s ease-out;
  
    -moz-transition: 0.3s ease-out;
  
    -o-transition: 0.3s ease-out;
  
    transition: 0.3s ease-out;
  
    -webkit-border-radius: 3px;
  
    border-radius: 3px;
  
  }
  
  .allcp-form .switch > label + span {
  
    display: inline-block;
  
    padding-left: 5px;
  
    position: relative;
  
    top: -7px;
  
  }
  
  .allcp-form .switch > label:before {
  
    content: attr(data-off);
  
    position: absolute;
  
    top: 1px;
  
    right: 3px;
  
    width: 33px;
  
  }
  
  .allcp-form .switch > label:after {
  
    content: "";
  
    margin: 2px;
  
    width: 17px;
  
    height: 17px;
  
    display: block;
  
    background: #fff;
  
    -webkit-border-radius: 2px;
  
    border-radius: 2px;
  
  }
  
  .allcp-form .switch > input {
  
    -webkit-appearance: none;
  
    position: absolute;
  
    width: inherit;
  
    height: inherit;
  
    opacity: 0;
  
    left: 0;
  
    top: 0;
  
  }
  
  .allcp-form .switch > input:focus {
  
    outline: none;
  
  }
  
  .allcp-form .switch > input:checked + label {
  
    border-color: #fff;
  
    background: transparent;
  
    padding-left: 33px;
  
    color: #fff;
  
  }
  
  .allcp-form .switch > input:checked + label:before {
  
    content: attr(data-on);
  
    left: 1px;
  
    top: 1px;
  
  }
  
  .allcp-form .switch > input:checked + label:after {
  
    margin: 2px;
  
    width: 17px;
  
    height: 17px;
  
    background: #fff;
  
  }
  
  .allcp-form .switch > input:checked:focus + label {
  
    background: transparent;
  
    border-color: #aaa;
  
  }
  
  .allcp-form .switch-round > label {
  
    -webkit-border-radius: 13px;
  
    -moz-border-radius: 13px;
  
    -o-border-radius: 13px;
  
    border-radius: 13px;
  
  }
  
  .allcp-form .switch-round > label + span {
  
    top: -2px;
  
  }
  
  .allcp-form .switch-round > label:before {
  
    width: 33px;
  
  }
  
  .allcp-form .switch-round > label:after {
  
    width: 17px;
  
    color: #fff;
  
    content: "\2022";
  
    font: 20px/20px Times, Serif;
  
    -webkit-border-radius: 13px;
  
    -moz-border-radius: 13px;
  
    -o-border-radius: 13px;
  
    border-radius: 13px;
  
  }
  
  .allcp-form .switch-round > input:checked + label {
  
    padding-left: 33px;
  
  }
  
  .allcp-form .switch-round > input:checked + label:after {
  
    color: #aaa;
  
  }
  
  .allcp-form .switch-custom > label {
  
    color: #fa9a9c;
  
    border-color: #fa9a9c;
  
  }
  
  .allcp-form .switch-custom > label:after {
  
    background: #fa9a9c;
  
  }
  
  .allcp-form .switch-custom > input:hover + label,
  
  .allcp-form .switch-custom > input:focus + label {
  
    color: #f42a2f;
  
    border-color: #f42a2f;
  
  }
  
  .allcp-form .switch-custom > input:hover + label:after,
  
  .allcp-form .switch-custom > input:focus + label:after {
  
    background: #f42a2f;
  
  }
  
  .allcp-form .switch-custom > input:checked + label {
  
    color: #c3d62d;
  
    border-color: #c3d62d;
  
  }
  
  .allcp-form .switch-custom > input:checked + label:after {
  
    background: #c3d62d;
  
  }
  
  .allcp-form .switch-custom > input:checked:hover + label,
  
  .allcp-form .switch-custom > input:checked:focus + label {
  
    color: #8b991e;
  
    border-color: #8b991e;
  
  }
  
  .allcp-form .switch-custom > input:checked:hover + label:after,
  
  .allcp-form .switch-custom > input:checked:focus + label:after {
  
    background: #8b991e;
  
  }
  
  .allcp-form .button[disabled],
  
  .allcp-form .state-disabled .button,
  
  .allcp-form input[disabled] + .radio,
  
  .allcp-form input[disabled] + .checkbox,
  
  .allcp-form .switch > input[disabled] + label {
  
    cursor: default;
  
    opacity: 0.5;
  
  }
  .tab{
    min-height:350px;
  }
  .bg-color.clearfix{
    background:#00A1AF;
    padding:15px;
  }
  .btn,.btn:focus,.btn:hover{
    background-color: #F89C24;
    border-color: #F89C24;
    min-width:100px;
}

.form-horizontal .form-group {
    margin-right:0;
    margin-left:0;
}
.menu_head {
    font-size: 25px;
    text-transform: capitalize;
    font-weight: 600;
    color: #fff;
    padding: 10px;
    /* border: 1px solid; */
    margin: 15px;
    text-align: center;
}
.item-content-div {
    box-shadow: 0px 0px 2px 1px #fff;
    padding: 0px 30px 10px;
    margin-bottom: 17px;
    background: rgba(0,0,0,0.4);
}
.w-100{
  display:100%;
  width:100%;
}
.skin-blue .main-header .navbar {
     background: linear-gradient(90deg,#00a1af 0,#10b1bf 75%,#29c0ce 100%);
}
.skin-blue .wrapper, .skin-blue .main-sidebar, .skin-blue .left-side {
    background: linear-gradient(90deg,#00a1af 0,#10b1bf 75%,#29c0ce 100%);
}
.skin-blue .main-header .logo,.skin-blue .main-header .logo:hover {
    color: #fff;
    /* border-bottom: 1px solid #544e4e; */
    background: #003b40;
}
.skin-blue .main-header .navbar .sidebar-toggle:hover {
    background-color: #20bbc9;
}
.skin-blue .sidebar-menu>li.header {
    color: #ffffff;
    background: #003b40;
}

.skin-blue .sidebar li a {
    color: #ffffff;
    border-bottom: 1px solid #cecece;
}
.skin-blue .sidebar-menu>li:hover>a, .skin-blue .sidebar-menu>li.active>a, .skin-blue .sidebar-menu>li.menu-open>a {
    color: #fff;
    background:#49c5d0;
}
h1.text-center{
  background: #003b40;
    padding: 6px;
    font-weight: 600;
    color: #fff;
}
@media (min-width: 992px)
{
.col-md-2 {
    width: 20%;
}
}

.navbar-nav>.user-menu>.dropdown-menu {
    width: 55px !important;
}

  </style>

</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
    <header class="main-header">

    <!-- Logo -->
    <a href="<?php echo e(url('')); ?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>LT</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Admin</b>LTE</span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <?php 
                $loginData = loginUserData();
              ?>
              <span class="hidden-xs"><?php echo e($loginData->name); ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-right">
                  <a href="<?php echo e(route('hq.hqlogout')); ?>" class="btn btn-default">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
        </ul>
      </div>

    </nav>
  </header><?php /**PATH /home4/menuburst/public_html/dashboard/backendless/resources/views/after/restaurant/common/header.blade.php ENDPATH**/ ?>
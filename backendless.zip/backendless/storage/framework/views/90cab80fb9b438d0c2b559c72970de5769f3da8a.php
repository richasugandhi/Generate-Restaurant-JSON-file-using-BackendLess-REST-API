<?php echo $__env->make('after.restaurant.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('after.restaurant.common.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <div class="content-wrapper">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<?php echo $__env->make('after.restaurant.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\backendless\resources\views/after/restaurant/layout.blade.php ENDPATH**/ ?>
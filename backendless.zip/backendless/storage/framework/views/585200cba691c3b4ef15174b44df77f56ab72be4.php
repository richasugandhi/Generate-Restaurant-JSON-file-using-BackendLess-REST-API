<?php $__env->startSection('content'); ?>
<style>
    .dashboard-content {
            text-align: center;
        color: #F89C24;
        text-transform: uppercase;
    }
    .dashboard-menu-count {
        font-weight: 700;
    }
</style>

<!-- /.register-box -->
<section class="content">
	<div class="row">
	    <div class="col-md-12">
    		<div>
    			<?php if(session()->has('success')): ?>
    			    <div class="alert alert-success">
    			        <?php echo e(session()->get('success')); ?>

    			    </div>
    			<?php endif; ?>
    		</div>
    		<div class="dashboard-content">
    		    <h3 class="dashboard-menu-count">You have <?php echo e($countMenu); ?> menus entered .</h3>
    		   
    		</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('after.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/menuburst/public_html/dashboard/backendless/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>
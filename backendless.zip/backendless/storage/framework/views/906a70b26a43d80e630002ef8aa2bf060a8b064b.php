</div>

<!-- jQuery 3 -->



<script src="<?php echo e(asset("/public/bower_components/jquery/dist/jquery.min.js")); ?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(asset("/public/bower_components/bootstrap/dist/js/bootstrap.min.js")); ?>"></script>

<!-- FastClick -->
<script src="<?php echo e(asset("/public/bower_components/fastclick/lib/fastclick.js")); ?>"></script>

<!-- AdminLTE App -->
<script src="<?php echo e(asset("/public/bower_components/admin-lte/dist/js/adminlte.min.js")); ?>"></script>

<!-- Sparkline -->
<script src="<?php echo e(asset("/public/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js")); ?>"></script>

<!-- jvectormap  -->




<!-- SlimScroll -->

<!-- ChartJS -->

<!-- AdminLTE dashboard demo (This is only for demo purposes) -->

<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset("/public/bower_components/admin-lte/dist/js/demo.js")); ?>"></script>
<script src="<?php echo e(asset("/public/bower_components/bootstrap-tagsinput-latest/dist/bootstrap-tagsinput.js")); ?>"></script>

<script src="<?php echo e(asset("/public/js/jquery.timepicker.min.js")); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html><?php /**PATH /home4/menuburst/public_html/dashboard/backendless/resources/views/after/admin/common/footer.blade.php ENDPATH**/ ?>
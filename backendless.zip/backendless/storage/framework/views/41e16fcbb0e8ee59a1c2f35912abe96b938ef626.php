<?php $__env->startSection('content'); ?>
<style type="text/css">
  .login-page, .register-page {
    background: #00A1AF;
}
.btn,.btn:focus,.btn:hover{
    background-color: #F89C24;
    border-color: #F89C24;
    min-width:100px;
}
.login-logo a{
  color:#fff;
}
.login-box {
    width: 406px;
}
</style>

<div class="login-box">
  <div class="login-logo">
    <a href="../../index2.html"><b>WELCOME TO MENUBURST MANAGEMENT</b></a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign in to start your session</p>

    <form method="POST" action="<?php echo e(route('login')); ?>">
      <?php echo csrf_field(); ?>

      <div class="form-group has-feedback">
        <input type="email" name="email" class="form-control" placeholder="Email">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" name="password" class="form-control" placeholder="Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

    <!-- /.social-auth-links -->

    
    

  </div>
  <!-- /.login-box-body -->
</div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('before.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/menuburst/public_html/dashboard/backendless/resources/views/login.blade.php ENDPATH**/ ?>
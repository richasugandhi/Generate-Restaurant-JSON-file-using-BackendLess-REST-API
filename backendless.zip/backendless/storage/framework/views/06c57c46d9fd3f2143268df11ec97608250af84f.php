<?php $__env->startSection('content'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('after.restaurant.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/menuburst/public_html/dashboard/backendless/resources/views/restaurant/dashboard.blade.php ENDPATH**/ ?>
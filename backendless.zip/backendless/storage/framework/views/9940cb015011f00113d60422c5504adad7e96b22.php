<?php echo $__env->make('before.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





    <?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('before.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\backendless\resources\views/before/layout.blade.php ENDPATH**/ ?>
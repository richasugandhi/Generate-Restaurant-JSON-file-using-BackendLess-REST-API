<?php $__env->startSection('content'); ?>

<!-- /.register-box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('after.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\backendless\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
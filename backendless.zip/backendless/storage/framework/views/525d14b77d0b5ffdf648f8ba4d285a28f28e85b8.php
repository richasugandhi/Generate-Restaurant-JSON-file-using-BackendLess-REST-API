<?php $__env->startSection('content'); ?>

<style>
    .has-error {
        color: red;
    }
</style>
<!-- /.register-box -->
<section class="content">
	<div class="row">
		 <div class="col-md-12">
		 	<div class="box-header with-border">
				<h3 class="box-title">Edit Restaurant</h3>
			</div>
			<div>
				<?php if(session()->has('error')): ?>
				    <div class="alert alert-success">
				        <?php echo e(session()->get('error')); ?>

				    </div>
				<?php endif; ?>
			</div>
			<!-- form start -->
            <form class="form-horizontal" action="<?php echo e(route('admin.updaterestaurant')); ?>" method="POST">
                <?php echo csrf_field(); ?>
              <div class="box-body">
              	<input type="hidden" name="resturant_object_id" value="<?php echo e(isset($restaurantDetails->objectId) ? $restaurantDetails->objectId : ''); ?>">
              	<div class="row">
              	    <div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Name</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="name" id="name"  placeholder="name" value="<?php echo e(isset($restaurantDetails->name) ? $restaurantDetails->name : ''); ?>" />
		                    <?php if($errors->has('name')): ?>
		                        <p class="has-error"><?php echo e($errors->first('name')); ?></p>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Street</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="street" id="street" placeholder="Street" value="<?php echo e(isset($restaurantDetails->street) ? $restaurantDetails->street : ''); ?>" />
		                    <?php if($errors->has('street')): ?>
		                        <p class="has-error"><?php echo e($errors->first('street')); ?></p>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">City</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="city" id="city" placeholder="City" value="<?php echo e(isset($restaurantDetails->city) ? $restaurantDetails->city : ''); ?>">
		                    <?php if($errors->has('city')): ?>
		                        <p class="has-error"><?php echo e($errors->first('city')); ?></p>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Province</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="prov" id="prov" placeholder="Prov" value="<?php echo e(isset($restaurantDetails->prov) ? $restaurantDetails->prov : ''); ?>">
		                    <?php if($errors->has('prov')): ?>
		                        <p class="has-error"><?php echo e($errors->first('prov')); ?></p>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Postal Code</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="postal" id="postal" placeholder="Postal" value="<?php echo e(isset($restaurantDetails->postal) ? $restaurantDetails->postal : ''); ?>">
		                    <?php if($errors->has('postal')): ?>
		                        <p class="has-error"><?php echo e($errors->first('postal')); ?></p>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">website</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="website" id="website" placeholder="Website" value="<?php echo e(isset($restaurantDetails->website) ? $restaurantDetails->website : ''); ?>">
		                    <?php if($errors->has('website')): ?>
		                        <p class="has-error"><?php echo e($errors->first('website')); ?></p>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Phone</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="phone" id="phone" placeholder="phone" value="<?php echo e(isset($restaurantDetails->phone) ? $restaurantDetails->phone : ''); ?>">
		                    <?php if($errors->has('phone')): ?>
		                        <p class="has-error"><?php echo e($errors->first('phone')); ?></p>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">GlutenFree</label>
		                  <div class="col-sm-10">
		                    <?php if(isset($restaurantDetails->glutenFree)): ?>
		                       <select class="form-control" name="glutenFree" id="glutenFree" placeholder="GlutenFree">
		                           <option value="Yes" <?php echo e(($restaurantDetails->glutenFree == 'Yes') ? 'selected' : ''); ?>>Yes</option>
		                           <option value="Semi" <?php echo e(($restaurantDetails->glutenFree == 'Semi') ? 'selected' : ''); ?>>Semi</option>
		                           <option value="No" <?php echo e(($restaurantDetails->glutenFree == 'No') ? 'selected' : ''); ?>>No</option>
		                       </select>
		                    <?php else: ?>
		                        <select class="form-control" name="glutenFree" id="glutenFree" placeholder="GlutenFree">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Vegan</label>
		                  <div class="col-sm-10">
		                    <?php if(isset($restaurantDetails->vegan)): ?>
		                       <select class="form-control" name="vegan" id="vegan" placeholder="Vegan">
		                           <option value="Yes" <?php echo e(($restaurantDetails->vegan == 'Yes') ? 'selected' : ''); ?>>Yes</option>
		                           <option value="Semi" <?php echo e(($restaurantDetails->vegan == 'Semi') ? 'selected' : ''); ?>>Semi</option>
		                           <option value="No" <?php echo e(($restaurantDetails->vegan == 'No') ? 'selected' : ''); ?>>No</option>
		                       </select>
		                    <?php else: ?>
		                        <select class="form-control" name="vegan" id="vegan" placeholder="Vegan">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Vegetarian</label>
		                  <div class="col-sm-10">
		                    <?php if(isset($restaurantDetails->vegetarian)): ?>
		                       <select class="form-control" name="vegetarian" id="vegetarian" placeholder="Vegetarian">
		                           <option value="Yes" <?php echo e(($restaurantDetails->vegetarian == 'Yes') ? 'selected' : ''); ?>>Yes</option>
		                           <option value="Semi" <?php echo e(($restaurantDetails->vegetarian == 'Semi') ? 'selected' : ''); ?>>Semi</option>
		                           <option value="No" <?php echo e(($restaurantDetails->vegetarian == 'No') ? 'selected' : ''); ?>>No</option>
		                       </select>
		                    <?php else: ?>
		                        <select class="form-control" name="vegetarian" id="vegetarian" placeholder="Vegetarian">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Spicy</label>
		                  <div class="col-sm-10">
		                    <?php if(isset($restaurantDetails->spicy)): ?>
		                       <select class="form-control" name="spicy" id="spicy" placeholder="Spicy">
		                           <option value="Yes" <?php echo e(($restaurantDetails->spicy == 'Yes') ? 'selected' : ''); ?>>Yes</option>
		                           <option value="Semi" <?php echo e(($restaurantDetails->spicy == 'Semi') ? 'selected' : ''); ?>>Semi</option>
		                           <option value="No" <?php echo e(($restaurantDetails->spicy == 'No') ? 'selected' : ''); ?>>No</option>
		                       </select>
		                    <?php else: ?>
		                        <select class="form-control" name="spicy" id="spicy" placeholder="Spicy">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Halal</label>
		                  <div class="col-sm-10">
		                    <?php if(isset($restaurantDetails->halal)): ?>
		                       <select class="form-control" name="halal" id="halal" placeholder="Halal">
		                           <option value="Yes" <?php echo e(($restaurantDetails->halal == 'Yes') ? 'selected' : ''); ?>>Yes</option>
		                           <option value="Semi" <?php echo e(($restaurantDetails->halal == 'Semi') ? 'selected' : ''); ?>>Semi</option>
		                           <option value="No" <?php echo e(($restaurantDetails->halal == 'No') ? 'selected' : ''); ?>>No</option>
		                       </select>
		                    <?php else: ?>
		                        <select class="form-control" name="halal" id="halal" placeholder="Halal">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Kosher</label>
		                  <div class="col-sm-10">
		                    <?php if(isset($restaurantDetails->kosher)): ?>
		                       <select class="form-control" name="kosher" id="kosher" placeholder="Kosher">
		                           <option value="Yes" <?php echo e(($restaurantDetails->kosher == 'Yes') ? 'selected' : ''); ?>>Yes</option>
		                           <option value="Semi" <?php echo e(($restaurantDetails->kosher == 'Semi') ? 'selected' : ''); ?>>Semi</option>
		                           <option value="No" <?php echo e(($restaurantDetails->kosher == 'No') ? 'selected' : ''); ?>>No</option>
		                       </select>
		                    <?php else: ?>
		                        <select class="form-control" name="kosher" id="kosher" placeholder="Kosher">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Occeanwise</label>
		                  <div class="col-sm-10">
		                    <?php if(isset($restaurantDetails->occeanwise)): ?>
		                       <select class="form-control" name="occeanwise" id="occeanwise" placeholder="Occeanwise">
		                           <option value="Yes" <?php echo e(($restaurantDetails->occeanwise == 'Yes') ? 'selected' : ''); ?>>Yes</option>
		                           <option value="Semi" <?php echo e(($restaurantDetails->occeanwise == 'Semi') ? 'selected' : ''); ?>>Semi</option>
		                           <option value="No" <?php echo e(($restaurantDetails->occeanwise == 'No') ? 'selected' : ''); ?>>No</option>
		                       </select>
		                    <?php else: ?>
		                        <select class="form-control" name="occeanwise" id="occeanwise" placeholder="Occeanwise">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    <?php endif; ?>
		                  </div>
		                </div>
					</div>
					
					<!--<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Sideright</label>
		                  <div class="col-sm-10">
		                  	<?php if(isset($restaurantDetails->sideright)): ?>
								<select class="form-control" name="sideright" id="sideright" placeholder="Sideright">
			                  		<option value="TRUE" <?php echo e(($restaurantDetails->sideright == TRUE) ? 'selected' : ''); ?>>1</option>
			                  		<option value="FALSE" <?php echo e(($restaurantDetails->sideright == FALSE) ? 'selected' : ''); ?>>0</option>
			                  	</select>
		                  	<?php else: ?>
								<select class="form-control" name="sideright" id="sideright" placeholder="Sideright">
			                  		<option value="TRUE">1</option>
			                  		<option value="FALSE">0</option>
			                  	</select>
		                  	<?php endif; ?>
		                  </div>
		                </div>
					</div>-->
					
				</div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <a href="<?php echo e(route('/')); ?>">Cancel</a>
                <button type="submit" class="btn btn-info pull-right">Update</button>
              </div>
              <!-- /.box-footer -->
            </form>
		 </div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('after.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/menuburst/public_html/dashboard/backendless/resources/views/admin/editrestaurant.blade.php ENDPATH**/ ?>
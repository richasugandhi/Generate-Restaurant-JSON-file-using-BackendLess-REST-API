<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'LoginController@index')->name('/');
Route::get('/registration', 'LoginController@registrationForm');

Route::post('/login', 'LoginController@login')->name('login');
Route::post('/registration', 'LoginController@registration')->name('registration');

Route::get('/dashboard', 'WelcomeController@index')->name('dashboard')->middleware('checkRole');
Route::get('/admin', 'AdminController@index')->name('admin.dashboard')->middleware('checkRole');


Route::get('/hqaddresturant', 'WelcomeController@hqaddresturant')->name('hq.hqaddresturant');
Route::get('/hqmodifyrestaurant', 'WelcomeController@hqmodifyrestaurant')->name('hq.hqmodifyrestaurant');
Route::post('/hqsubmitrestaurant', 'WelcomeController@hqsubmitrestaurant')->name('hq.hqsubmitrestaurant');
Route::post('/hqmodifysubmitrestaurant', 'WelcomeController@hqmodifysubmitrestaurant')->name('hq.hqmodifysubmitrestaurant');


Route::post('/hq/slidehtml', 'WelcomeController@slidehtml')->name('hq.slidehtml');
Route::post('/hq/itemhtml', 'WelcomeController@itemhtml')->name('hq.itemhtml');
Route::post('/hq/addonhtml', 'WelcomeController@addonhtml')->name('hq.addonhtml');
Route::post('/hq/variationhtml', 'WelcomeController@variationhtml')->name('hq.variationhtml');
Route::post('/hq/toppinghtml', 'WelcomeController@toppinghtml')->name('hq.toppinghtml');


Route::get('/editrestaurant', 'AdminController@editrestaurant')->name('admin.editrestaurant');
Route::post('/updaterestaurant', 'AdminController@updaterestaurant')->name('admin.updaterestaurant');

Route::get('/addrestaurant', 'AdminController@addrestaurant')->name('admin.addrestaurant');
Route::get('/modifyrestaurant', 'AdminController@modifyrestaurant')->name('admin.modifyrestaurant');
Route::post('/submitrestaurant', 'AdminController@submitrestaurant')->name('admin.submitrestaurant');
Route::post('/modifysubmitrestaurant', 'AdminController@modifysubmitrestaurant')->name('admin.modifysubmitrestaurant');

Route::post('/slidehtml', 'AdminController@slidehtml')->name('admin.slidehtml');
Route::post('/itemhtml', 'AdminController@itemhtml')->name('admin.itemhtml');
Route::post('/addonhtml', 'AdminController@addonhtml')->name('admin.addonhtml');
Route::post('/variationhtml', 'AdminController@variationhtml')->name('admin.variationhtml');
Route::post('/toppinghtml', 'AdminController@toppinghtml')->name('admin.toppinghtml');

Route::get('/logout', 'AdminController@logout')->name('admin.logout');
Route::get('/hqlogout', 'WelcomeController@hqlogout')->name('hq.hqlogout');
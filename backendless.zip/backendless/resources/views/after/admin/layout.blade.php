@include('after.admin.common.header')

@include('after.admin.common.sidebar')

{{--@include('before.common.navigation')--}}
  <div class="content-wrapper">
    @yield('content')
</div>

@include('after.admin.common.footer')
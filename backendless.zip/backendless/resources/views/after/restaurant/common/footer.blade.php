</div>

<script src="{{ asset("/public/bower_components/jquery/dist/jquery.min.js") }}"></script>
<!-- Bootstrap 3.3.7 -->
<script src="{{ asset("/public/bower_components/bootstrap/dist/js/bootstrap.min.js") }}"></script>

<!-- FastClick -->
<script src="{{ asset("/public/bower_components/fastclick/lib/fastclick.js") }}"></script>

<!-- AdminLTE App -->
<script src="{{ asset("/public/bower_components/admin-lte/dist/js/adminlte.min.js") }}"></script>

<!-- Sparkline -->
<script src="{{ asset("/public/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js") }}"></script>

<script src="{{ asset("/public/bower_components/admin-lte/dist/js/demo.js") }}"></script>
<script src="{{ asset("/public/bower_components/bootstrap-tagsinput-latest/dist/bootstrap-tagsinput.js") }}"></script>

<script src="{{ asset("/public/js/jquery.timepicker.min.js") }}"></script>
@stack('scripts')

</body>
</html>
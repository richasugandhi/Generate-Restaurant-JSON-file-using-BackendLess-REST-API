@include('after.restaurant.common.header')

@include('after.restaurant.common.sidebar')

{{--@include('before.common.navigation')--}}
  <div class="content-wrapper">
    @yield('content')
</div>

@include('after.restaurant.common.footer')
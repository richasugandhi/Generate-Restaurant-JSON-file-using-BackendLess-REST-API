@extends('after.admin.layout')

@section('content')

<!-- /.register-box -->
<section class="content">
	<div class="row">
		 <div class="col-md-12">
		 	<div class="box-header with-border">
				<h3 class="box-title">Add Restaurant</h3>
			</div>
			<form class="form-horizontal" method="POST" id="regForm" action="{{ route('admin.submitrestaurant') }}">
  {{ csrf_field() }}
<h1>Resturant Menus:</h1>

<!-- One "tab" for each step in the form: -->
<div class="tab" id="tab1">Menu Details:
  <div class='row menudetails-default-content'>
  	<div class="menudetailsform">
  		<div class='col-md-6'>
  			<label for="" class="menu_name_lb_name">Select Name</label>
  			<select class="menu_name" name='menu_name[0]'>
  				<option value="0" attr-val="Lunch & Dinner Menu">Lunch & Dinner Menu</option>
  				<option value="1" attr-val="Desserts Menu">Desserts Menu</option>
  				<option value="2" attr-val="Kids Menu">Kids Menu</option>
  			</select>
  			<!--<input type="checkbox" name='menu_name[]' value="1" attr-val="Lunch & Dinner Menu" />Lunch & Dinner Menu
  			<input type="checkbox" name='menu_name[]' value="2" attr-val="Desserts Menu" />Desserts Menu
  			<input type="checkbox" name='menu_name[]' value="3" attr-val="Kids Menu" />Kids Menu-->
		</div>
		<div class='col-md-6'>
			<label for="" class="menu_name_lb_day">Select Day</label>
			<input type="checkbox" name='day[0][]' value="1" attr-val="sunday" />Sunday
  			<input type="checkbox" name='day[0][]' value="2" attr-val="Monday" />Monday
  			<input type="checkbox" name='day[0][]' value="3" attr-val="Tuesday" />Tuesday
  			<input type="checkbox" name='day[0][]' value="4" attr-val="Wenesday" />Wenesday
  			<input type="checkbox" name='day[0][]' value="5" attr-val="Thuresday" />Thuresday
  			<input type="checkbox" name='day[0][]' value="6" attr-val="Friday" />Friday
			<input type="checkbox" name='day[0][]' value="7" attr-val="Saturday" />Saturday
		</div>
  	</div>
  </div>
	<div class="menudetails-content"></div>
	<label class="menudetails">Add More</label>
</div>

<div class="tab">Item Details:
	<div class="selectmenudetail-div">
		<label class="label-menudetail">Menu Name</label>
		<select name="item_menudetail[]" class="menudetail-select" id="menudetail">
			
		</select>
	    <label class="menuitem">Add Item</label>
	</div>
  <div class='row item-default-content'>
  	<!--<div class="itemform">
  		<div class='col-md-6'>
			<input type='text' class='form-control name' name='name[0][]' id='name' placeholder='name'>
		</div>
		<div class='col-md-6'>
			<input type='text' class='form-control' name='category[0][]' id='category' placeholder='category'>
		</div>
  	</div>-->
  </div>
	<div class="item-content"></div>
</div>

<div class="tab">Sides:
	<div class="customslide"></div>
	<!--<div class="selectsideitem-div">
		<label class="label-menudetail">Menu Name</label>
		<select name="" class="common-menudetail-select" id="side-menudetail-select">
			
		</select>
		<label class="label-sideitem">Items</label>
		<select name="" class="commonitem sideitem" id="sideitem">
			<option value="0">1</option>
		</select>
		<label class="sideitem-lb">Add Sides</label>
	</div>-->
	<div class='row item-sides-default-content'>
		<!--<div class="sideform">
			<div class='col-md-6'>
				<label for="" class="side_standard">standard</label>
				<select class='form-control' name='side_standard[0][]' id='standard'>
					<option value="true">true</option>
					<option value="false">false</option>
				</select>
			</div>
			<div class='col-md-6'>
				<label for="" class="side_corn">Msg</label>
				<select class='form-control' name='side_corn[0][]' id='side_corn'>
					<option value="Y">Y</option>
					<option value="N">N</option>
					<option value="NA">NA</option>
				</select>
			</div>
		</div>-->
	</div>
	<div class="item-side-content"></div>
</div>

<div class="tab">Addons:
	<div class="customaddon"></div>
	<!--<div class="selectaddonitem-div">
		<label class="label-menudetail">Menu Name</label>
		<select name="" class="common-menudetail-select" id="addon-menudetail-select">
			
		</select>

		<label class="label-addonitem">Items</label>
		<select name="" class="commonitem addonitem" id="addonitem">
			<option value="0">1</option>
		</select>
		<label class="addonitem-lb">Add Addons</label>
	</div>-->
	<div class='row addon-sides-default-content'>
		<!--<div class="addonform">
			<div class='col-md-6'>
				<input type='text' class='form-control' name='addon_name[0][]' id='addon_name' placeholder='addon_name'>
			</div>
			<div class='col-md-6'>
				<input type='text' class='form-control' name='addon_category[0][]' id='addon_category' placeholder='addon_category'>
			</div>
		</div>-->
	</div>
	<div class="item-addon-content"></div>
</div>

<div class="tab">Variations:
	<div class="customvariations"></div>
	<!--<div class="selectvariationitem-div">
		<label class="label-menudetail">Menu Name</label>
		<select name="" class="common-menudetail-select" id="variation-menudetail-select">
			
		</select>
		<label class="label-variationitem">Items</label>
		<select name="" class="commonitem variationitem" id="variationitem">
			<option value="0">1</option>
		</select>
		<label class="variationitem-lb">Add Variations</label>
	</div>-->
  <div class='row variation-sides-default-content'>
		<!--<div class="variationform">
			<div class='col-md-6'>
				<input type='text' class='form-control' name='variation_name[0][]' id='variation_name' placeholder='variation_name'>
			</div>
			<div class='col-md-6'>
				<input type='text' class='form-control' name='variation_category[0][]' id='variation_category' placeholder='variation_category'>
			</div>
		</div>-->
	</div>
	<div class="item-variation-content"></div>
</div>

<div class="tab">Topping:
	<div class="customtopping"></div>
	<!--<div class="selecttoppingitem-div">
		<label class="label-menudetail">Menu Name</label>
		<select name="" class="common-menudetail-select" id="topping-menudetail-select">
			
		</select>
		<label class="label-toppingitem">Items</label>
		<select name="" class="commonitem toppingitem" id="toppingitem">
			<option value="0">1</option>
		</select>
		<label class="toppingitem-lb">Add Topping</label>
	</div>
  	<div class='row topping-sides-default-content'>
		<div class="toppingform">
			<div class='col-md-6'>
				<input type='text' class='form-control' name='topping_name[0][]' id='topping_name' placeholder='topping_name'>
			</div>
			<div class='col-md-6'>
				<input type='text' class='form-control' name='topping_category[0][]' id='topping_category' placeholder='topping_category'>
			</div>
		</div>
	</div>-->
	<div class="item-topping-content"></div>
</div>

<div style="overflow:auto;float:left;">
  <div style="float:right;">
    <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
    <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
  </div>
</div>

<!-- Circles which indicates the steps of the form: -->
<div style="text-align:center;margin-top:40px;">
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
</div>

</form>
		 </div>
	</div>	
</section>
@endsection

@push('scripts')
<script type="text/javascript">
	$(document).ready(function() {
		$('.menudetails').click(function() {
			var menudetails = '';
			var numdiv = $('.menudetailsform').length;
			if(numdiv > 1) {
				var num = numdiv; 
				var menuHtml = "<div class='menudetailsform'><div class='col-md-6'><label class='menu_name_lb_name'>Select Name</label><select name='menu_name["+num+"]' class='menu_name'><option value='0' attr-val='Lunch & Dinner Menu'>Lunch & Dinner Menu</option><option value='1' attr-val='Desserts Menu'>Desserts Menu</option><option value='2' attr-val='Kids Menu'>Kids Menu</option></select></div><div class='col-md-6'><label class='menu_name-lb-day'>Select Day</label><input type='checkbox' name='day["+num+"][]' value='1' attr-val='sunday' />Sunday<input type='checkbox' name='day["+num+"][]' value='2' attr-val='Monday' />Monday<input type='checkbox' name='day["+num+"][]' value='3' attr-val='Tuesday' />Tuesday<input type='checkbox' name='day["+num+"][]' value='4' attr-val='Wenesday' />Wenesday<input type='checkbox' name='day["+num+"][]' value='5' attr-val='Thuresday' />Thuresday<input type='checkbox' name='day["+num+"][]' value='6' attr-val='Friday' />Friday<input type='checkbox' name='day["+num+"][]' value='7' attr-val='Saturday' />Saturday</div></div>";
			} else {
				var menuHtml = "<div class='menudetailsform'><div class='col-md-6'><label class='menu_name_lb_name'>Select Name</label><select class='menu_name' name='menu_name[1]'><option value='0' attr-val='Lunch & Dinner Menu'>Lunch & Dinner Menu</option><option value='1' attr-val='Desserts Menu'>Desserts Menu</option><option value='2' attr-val='Kids Menu'>Kids Menu</option></select></div><div class='col-md-6'><label class='menu_name-lb-day'>Select Day</label><input type='checkbox' name='day[1][]' value='1' attr-val='sunday' />Sunday<input type='checkbox' name='day[1][]' value='2' attr-val='Monday' />Monday<input type='checkbox' name='day[1][]' value='3' attr-val='Tuesday' />Tuesday<input type='checkbox' name='day[1][]' value='4' attr-val='Wenesday' />Wenesday<input type='checkbox' name='day[1][]' value='5' attr-val='Thuresday' />Thuresday<input type='checkbox' name='day[1][]' value='6' attr-val='Friday' />Friday<input type='checkbox' name='day[1][]' value='7' attr-val='Saturday' />Saturday</div></div>";
			}
			$('.menudetails-content').append(menuHtml);
		});

		$('.menuitem').click(function() {
			var menuName = $('.menudetail-select').val();
			var menuAttr = $('.menudetail-select option:selected').attr('attr-val');
			var menuHtml = "<h5>"+menuName+"</h5><div attrItemcount='"+menuName+"' class='itemform itemform_"+menuName+"' id='itemform_"+menuName+"'><div class='col-md-6'><input type='text' class='form-control name' name='name["+menuName+"][]' id='name' placeholder='name'></div><div class='col-md-6'><input type='text' class='form-control' name='category["+menuName+"][]' id='category' placeholder='category'></div></div></hr>";

			$('.item-content').append(menuHtml);


			var numdiv = $('.itemform_'+menuName).length;

			var IsExistsOpt = false;
			var itemoption;
			for(var i = 0; i<numdiv; i++) {
				var opval = i+1;

				$('#itemopt_'+menuName+' option').each(function(){
					var id = $(this).attr('id');
					if(id = 'itemopt_'+menuName) {
						if($('#itemopt_'+menuName).val() != 'undefined') {
							if ($('#itemopt_'+menuName).val() == i) {
							   IsExistsOpt = true;
							}
						}
					}


				});

				if(!IsExistsOpt) {
					itemoption += '<option value="'+i+'">'+opval+'</option>';
				}
				//console.log(itemoption);
			}


			var IsExists = false;
			$('.additemform').each(function(){
			    if ($(this).attr('id') == 'additemform_'+menuName) 
			        IsExists = true;   
			});
			if(!IsExists) {
				var customItemhtml = "<div class='additemform' id='additemform_"+menuName+"'><label id='side_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='itemopt' id='itemopt_"+menuName+"'></select><label class='specific-sideitem-lb' attrval="+menuName+">Add Sides</label><div class='slilde_content_"+menuName+"' id='slilde_content_"+menuName+"'></div></div>";
				$('.customslide').append(customItemhtml);


				var customAddonhtml = "<div class='addaddonform' id='addaddonform_"+menuName+"'><label id='addon_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='addonopt' id='addonopt_"+menuName+"'></select><label class='specific-addonitem-lb' attrval="+menuName+">Add Addon</label><div class='addon_content_"+menuName+"' id='addon_content_"+menuName+"'></div></div>";
				$('.customaddon').append(customAddonhtml);


				var customVariationhtml = "<div class='addvariationform' id='addvariationform_"+menuName+"'><label id='variation_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='variationopt' id='variationopt_"+menuName+"'></select><label class='specific-variationitem-lb' attrval="+menuName+">Add Variation</label><div class='variation_content_"+menuName+"' id='variation_content_"+menuName+"'></div></div>";
				$('.customvariations').append(customVariationhtml);

				var customToppinghtml = "<div class='addtoppingform' id='addtoppingform_"+menuName+"'><label id='topping_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='toppingopt' id='toppingopt_"+menuName+"'></select><label class='specific-toppingitem-lb' attrval="+menuName+">Add Topping</label><div class='topping_content_"+menuName+"' id='topping_content_"+menuName+"'></div></div>";
				$('.customtopping').append(customToppinghtml);

			} else {
				$('#additemform_'+menuName).find('.itemopt').append(itemoption)
			}


			var t;
			var r = $('.itemform_'+menuName).length;
			for(var d = 0; d<r; d++) {
				var o = d+1;
				   t += '<option value="'+d+'">'+o+'</option>';
			}
			$('#itemopt_'+menuName).append(t);
			$('#addonopt_'+menuName).append(t);
			$('#variationopt_'+menuName).append(t);
			$('#toppingopt_'+menuName).append(t);


			var optionValues =[];
			$('#itemopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValues) >-1){
			      $(this).remove()
			   }else{
			      optionValues.push(this.value);
			   }
			});

			var optionValuesA =[];
			$('#addonopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValuesA) >-1){
			      $(this).remove()
			   }else{
			      optionValuesA.push(this.value);
			   }
			});

			var optionValuesV =[];
			$('#variationopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValuesV) >-1){
			      $(this).remove()
			   }else{
			      optionValuesV.push(this.value);
			   }
			});

			
			var optionValuesT =[];
			$('#toppingopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValuesT) >-1){
			      $(this).remove()
			   }else{
			      optionValuesT.push(this.value);
			   }
			});

			/*var IsExists = false;
			$('.common-menudetail-select option').each(function(){
			    if (this.value == menuName) 
			        IsExists = true;   
			});
			if(!IsExists) {
				$('.common-menudetail-select').append('<option name="" value="'+menuName+'" attr-val="'+menuAttr+'">'+menuAttr+'</option>');
			}

			if(itemoption != 'undefined') {
				$('.commonitem').html('');
				$('.commonitem').append(itemoption);
			}*/
		});

		$('body').on('click', '.specific-sideitem-lb', function() {
			var menuId = $(this).attr('attrval');
			var itemId = $('#itemopt_'+menuId).val();
			var sidehtml = "<h5>Menu"+menuId+" AND Item "+itemId+"</h5><div class='sideform'><div class='col-md-6'><label class='side_standard'>standard</label><select class='form-control' name='side_standard["+menuId+"]["+itemId+"][]' id='standard'><option value='true'>true</option><option value='false'>false</option></select></div><div class='col-md-6'><label class='side_corn'>Msg</label><select class='form-control' name='side_corn["+menuId+"]["+itemId+"][]' id='side_corn'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div></div></hr>";

			$('.slilde_content_'+menuId).append(sidehtml);
		});


		/*$('.sideitem-lb').click(function() {
			var itemval = $('#sideitem').val();
			var menuId = $('#side-menudetail-select').val();
			alert(itemval);
			var sidehtml = "<div class='sideform'><div class='col-md-6'><label class='side_standard'>standard</label><select class='form-control' name='side_standard["+menuId+"]["+itemval+"][]' id='standard'><option value='true'>true</option><option value='false'>false</option></select></div><div class='col-md-6'><label class='side_corn'>Msg</label><select class='form-control' name='side_corn["+menuId+"]["+itemval+"][]' id='side_corn'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div></div>";
			$('.item-side-content').append(sidehtml);
		});*/

		/*$('.addonitem-lb').click(function() {
			var itemval = $('#addonitem').val();
			var menuId = $('#addon-menudetail-select').val();

			var addonhtml = "<div class='addonform'><div class='col-md-6'><input type='text' class='form-control' name='addon_name["+menuId+"]["+itemval+"][]' id='addon_name' placeholder='addon_name'></div><div class='col-md-6'><input type='text' class='form-control' name='addon_category["+menuId+"]["+itemval+"][]' id='addon_category' placeholder='addon_category'></div></div>";
			$('.item-addon-content').append(addonhtml);
		});*/



		$('body').on('click', '.specific-addonitem-lb', function() {
			var menuId = $(this).attr('attrval');
			var itemId = $('#addonopt_'+menuId).val();
			var addonhtml = "<h5>Menu"+menuId+" AND Item "+itemId+"</h5><div class='addonform'><div class='col-md-6'><input type='text' class='form-control' name='addon_name["+menuId+"]["+itemId+"][]' id='addon_name' placeholder='addon_name'></div><div class='col-md-6'><input type='text' class='form-control' name='addon_category["+menuId+"]["+itemId+"][]' id='addon_category' placeholder='addon_category'></div></div></hr>";

			$('.addon_content_'+menuId).append(addonhtml);
		});


		/*$('.variationitem-lb').click(function() {
			var itemval = $('#variationitem').val();
			var menuId = $('#variation-menudetail-select').val();
			var variationhtml = "<div class='variationform'><div class='col-md-6'><input type='text' class='form-control' name='variation_name["+menuId+"]["+itemval+"][]' id='variation_name' placeholder='variation_name'></div><div class='col-md-6'><input type='text' class='form-control' name='variation_category["+menuId+"]["+itemval+"][]' id='variation_category' placeholder='variation_category'></div></div>";
			$('.item-variation-content').append(variationhtml);
		});*/


		$('body').on('click', '.specific-variationitem-lb', function() {
			var menuId = $(this).attr('attrval');
			var itemId = $('#variationopt_'+menuId).val();
			var variationhtml = "<h5>Menu"+menuId+" AND Item "+itemId+"</h5><div class='variationform'><div class='col-md-6'><input type='text' class='form-control' name='variation_name["+menuId+"]["+itemId+"][]' id='variation_name' placeholder='variation_name'></div><div class='col-md-6'><input type='text' class='form-control' name='variation_category["+menuId+"]["+itemId+"][]' id='variation_category' placeholder='variation_category'></div></div></hr>";

			$('.variation_content_'+menuId).append(variationhtml);
		});

		/*$('.toppingitem-lb').click(function() {
			var itemval = $('#toppingitem').val();
			var menuId = $('#toppoing-menudetail-select').val();
			var toppinghtml = "<div class='toppingform'><div class='col-md-6'><input type='text' class='form-control' name='topping_name["+menuId+"]["+itemval+"][]' id='topping_name' placeholder='topping_name'></div><div class='col-md-6'><input type='text' class='form-control' name='topping_category["+menuId+"]["+itemval+"][]' id='topping_category' placeholder='topping_category'></div></div>";
			$('.item-topping-content').append(toppinghtml);
		});*/


		$('body').on('click', '.specific-toppingitem-lb', function() {
			var menuId = $(this).attr('attrval');
			var itemId = $('#toppingopt_'+menuId).val();
			var toppinghtml = "<h5>Menu"+menuId+" AND Item "+itemId+"</h5><div class='toppingform'><div class='col-md-6'><input type='text' class='form-control' name='topping_name["+menuId+"]["+itemId+"][]' id='topping_name' placeholder='topping_name'></div><div class='col-md-6'><input type='text' class='form-control' name='topping_category["+menuId+"]["+itemId+"][]' id='topping_category' placeholder='topping_category'></div></div></hr>";

			$('.topping_content_'+menuId).append(toppinghtml);
		});

	});
</script>
<script type="text/javascript">
	var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form ...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  // ... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  // ... and run a function that displays the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
 // if (n == 1 && !validateForm()) return false;
 if(currentTab == 0) { selectMenu();}
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form... :
  if (currentTab >= x.length) {
    //...the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function selectMenu() {
	var menuName = '';
	$.each($(".menu_name option:selected"), function(){
		alert($(this).val()); 
	    menuName += '<option name="" value="'+$(this).val()+'" attr-val="'+$(this).attr('attr-val')+'">'+$(this).attr('attr-val')+'</option>';           
        //countries.push($(this).val());
    });
    $('.menudetail-select').append(menuName);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false:
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class to the current step:
  x[n].className += " active";
}
</script>
@endpush
@extends('after.admin.layout')

@section('content')

<!-- /.register-box -->
<section class="content">
	<div class="row">
		 <div class="col-md-12">
		 	<div class="box-header with-border">
				<h3 class="box-title">Modify Restaurant</h3>
			</div>
			<form class="form-horizontal allcp-form" method="POST" id="regForm" action="{{ route('admin.modifysubmitrestaurant') }}" enctype="multipart/form-data">
  {{ csrf_field() }}
<h1 class="text-center">Resturant Menus</h1>

<!-- One "tab" for each step in the form: -->
<div class="tab" id="tab1">Menu Details <label class="menudetails btn btn-danger pull-right">Add More</label>
	<hr>
  <div class='row menudetails-default-content'>
  	<input type="hidden" name="hide_menu_id" class="hide_menu_id" />
  	
  	@if(isset($menuName) && !empty($menuName)) 
		@foreach($menuName as $menuKey=>$menuNames)
		    <div class="menudetailsform clearfix" id="menudetailsform_{{$menuKey}}">
  		<div class='col-md-3 main-menu-dropdown-div'>
  			<label for="" class="menu_name_lb_name">Select Name</label>
  			<input type="text" class="menu_name" name='menu_name[{{$menuKey}}]' id='menu-name-{{$menuKey}}' placeholder="Menu Name" value="{{$menuNames['menu_name']}}" attr-key='{{$menuKey}}' menukey="{{$menuKey}}">
  			<span id="menu-name-error-{{$menuKey}}"></span>
		</div>
		<div class='col-md-3'>
			<label for="" class="menu_image_lb_name">Upload Menu Image</label>
			<input type="file" class="menu_image" name="menu_image[{{$menuKey}}][]" multiple id='menu-image-{{$menuKey}}'>
		</div>
		<div class='col-md-3'>
			<label for="" class="">Start Time</label>
			<input class="form-control start_time" type="text" name="start_time[{{$menuKey}}]" value="{{$menuNames['start_time']}}" placeholder='Start Time' />
		</div>
		<div class="col-md-3">
			<label>End Time</label>
			<input class="form-control end_time" type="text" name="end_time[{{$menuKey}}]" value="{{$menuNames['end_time']}}" placeholder='End Time' />
		</div>
		<div class='col-md-12'><hr>
			<label class="block mt15 switch switch-primary">
				<input type="checkbox" <?php if($menuNames['monday'] == 'true') { echo 'checked'; } else {'';} ?> name='day[{{$menuKey}}][]' value="1" attr-val="Monday" />
				<label class="switch_btn" data-on="YES" data-off="NO"></label><br>Monday
			</label>
			<label class="block mt15 switch switch-primary">
				<input type="checkbox" <?php if($menuNames['Tuesday'] == 'true') { echo 'checked'; } else {'';} ?> name='day[{{$menuKey}}][]' value="2" attr-val="Tuesday" />
				<label class="switch_btn" data-on="YES" data-off="NO"></label><br>Tuesday
			</label>
			<label class="block mt15 switch switch-primary">
				<br>
				<input type="checkbox" <?php if($menuNames['Wenesday'] == 'true') { echo 'checked'; } else {'';} ?> name='day[{{$menuKey}}][]' value="3" attr-val="Wenesday" />
				<label class="switch_btn" data-on="YES" data-off="NO"></label><br>Wenesday
			</label>
			<label class="block mt15 switch switch-primary">
				<input type="checkbox" <?php if($menuNames['Thurday'] == 'true') { echo 'checked'; } else {'';} ?> name='day[{{$menuKey}}][]' value="4" attr-val="Thuresday" />
				<label class="switch_btn" data-on="YES" data-off="NO"></label><br>Thuresday
			</label>
			<label class="block mt15 switch switch-primary">
				<input type="checkbox" <?php if($menuNames['Friday'] == 'true') { echo 'checked'; } else {'';} ?> name='day[{{$menuKey}}][]' value="5" attr-val="Friday" />
				<label class="switch_btn" data-on="YES" data-off="NO"></label><br>Friday
			</label>
			<label class="block mt15 switch switch-primary">
				<input type="checkbox" <?php if($menuNames['Saturday'] == 'true') { echo 'checked'; } else {'';} ?> name='day[{{$menuKey}}][]' value="6" attr-val="Saturday" />
				<label class="switch_btn" data-on="YES" data-off="NO"></label><br>Saturday
			</label>
			<label class="block mt15 switch switch-primary">
				<input type="checkbox" <?php if($menuNames['Sunday'] == 'true') { echo 'checked'; } else {'';} ?> name='day[{{$menuKey}}][]' value="7" attr-val="sunday" />
				<label class="switch_btn" data-on="YES" data-off="NO"></label><br>Sunday
			</label>
		</div>
		<div class='col-md-12'>
		    <label class="menu_remove btn btn-danger pull-right" id="menu_remove_{{$menuKey}}" attrmenucount='{{$menuKey}}'>Remove</label>
		</div>
  	</div>
		@endforeach
	@endif

  	
  </div>
	<div class="row menudetails-content"></div><hr>
</div>

<div class="tab">Item Details:<label class="menuitem btn btn-danger pull-right">Add Item</label><hr>
	<div class="bg-color clearfix">
	<div class="selectmenudetail-div clearfix">
		<div class="col-md-4">
			<label class="label-menudetail">Menu Name</label>
			<select name="item_menudetail[]" class="menudetail-select form-control" id="menudetail"></select>
		</div>
	</div>
	<hr class='clearfix' width='100%'>
  <div class='item-default-content clearfix'></div>
  <p class="item-p">Loading</p>
	<div class="item-content clearfix"></div>
	</div>
</div>

<div class="tab">Sides: <span class="side_btn"></span>
	<hr class='clearfix' width="100%">
	<div class="bg-color clearfix">
	    <div class="clearfix">
            <div class="customslide col-md-4"></div>
        	<div class="customslide-item-select col-md-4"></div>
        	<div class='item-sides-default-content col-md-4'></div>
        </div>
        <hr width="100%" class="clearfix"> 
    	<p class="sides-p">Loading</p>
    	<div class="item-side-content"></div>
	</div>
	
</div>

<div class="tab">Addons:<span class="addon_btn"></span>
	<hr class='clearfix' width="100%">
	<div class="bg-color clearfix">
	    <div class="clearfix">
	        <div class="customaddon col-md-4"></div>
	        <div class="customaddon-item-select col-md-4"></div>
	        <div class='item-addon-default-content col-md-4'></div>
	    </div>
	    <hr width="100%" class="clearfix">
    	<p class="addon-p">Loading</p>
    	<div class="item-addon-content"></div>
	</div>
</div>

<div class="tab">Variations:<span class="variation_btn"></span>
	<hr class='clearfix' width="100%">
	<div class="bg-color clearfix">
	    <div class="clearfix">
	        <div class="customvariation col-md-4"></div>
	        <div class="customvariation-item-select col-md-4"></div>
	        <div class='item-variation-default-content col-md-4'></div>
	    </div>
	    <hr width="100%" class="clearfix">
    	<p class="variation-p">Loading</p>
    	<div class="item-variation-content"></div>
	</div>
</div>

<div class="tab">Topping:<span class="topping_btn"></span>
	<hr class='clearfix' width="100%">
	<div class="bg-color clearfix">
	    <div class="clearfix">
	        <div class="customtopping col-md-4"></div>
	        <div class="customtopping-item-select col-md-4"></div>
	        <div class='item-topping-default-content col-md-4'></div>
	    </div>
	    <hr width="100%" class="clearfix">
    	<p class="topping-p">Loading</p>
    	<div class="item-topping-content"></div>
    </div>
</div>
<div class='clearfix'><hr></div>
  <div class="btn-contain"							>
    <!--<button class="btn btn-primary pull-left" type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>-->
    <button class="btn btn-primary pull-right nextBtn" type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
  </div>

<!-- Circles which indicates the steps of the form: -->
<div style="text-align:center;margin-top:40px;">
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
</div>

</form>
		 </div>
	</div>	
</section>
@endsection

@push('scripts')


<!--<script src="assets/js/jquery.timepicker.min.js"></script>-->
<script type="text/javascript">
	$(document).ready(function() {
		$('.menudetails').click(function() {

			var menuId = [];
			$('.menu_name').each(function(){
				var id = $(this).attr('id');
				menuId.push($("#"+id).val());
			});

		    var optionList ='';
			var countId = 0;
			$('.menudetailsform > .main-menu-dropdown-div > .menu_name').each(function() {
			    var val = $(this).val();
				optionList += '<option value="'+this.value+'" attr-val="'+val+'">'+val+'</option>';
			   	 countId++;
			});
			

			var menudetails = '';
			var numdiv = $('.menudetailsform').length;
			
			if(numdiv > 1) {
				var num = numdiv; 
			
				var menuHtml = "<div class='menudetailsform clearfix' id='menudetailsform_"+num+"'><div class='col-md-3'> <label class='menu_name_lb_name'>Select Name</label><input type='text' name='menu_name["+num+"]' class='menu_name' id='menu-name-"+num+"' attr-key='"+num+"' menukey='"+num+"' /><span id='menu-name-error-1'></span></div><div class='col-md-3'><label class='menu_image_lb_name'>Upload Menu Image</label><input type='file' class='menu_image' name='menu_image["+num+"][]' multiple id='menu-image-"+num+"'></div><div class='col-md-3'> <label class=''>Start Time</label> <input type='text' class='form-control start_time' name='start_time["+num+"]' placeholder='Start Time' /></div><div class='col-md-3'> <label class=''>End Time</label> <input type='text' class='form-control end_time' name='end_time["+num+"]' placeholder='End Time' /></div><div class='col-md-12'><hr> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day["+num+"][]' value='1' attr-val='Monday' /> <label class='switch_btn' data-on='YES' data-off='NO'></label> <br>Monday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day["+num+"][]' value='2' attr-val='Tuesday' /> <label class='switch_btn' data-on='YES' data-off='NO'></label> <br>Tuesday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day["+num+"][]' value='3' attr-val='Wenesday' /> <label class='switch_btn' data-on='YES' data-off='NO'></label><br>Wenesday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day["+num+"][]' value='4' attr-val='Thuresday' /><label class='switch_btn' data-on='YES' data-off='NO'></label><br>Thuresday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day["+num+"][]' value='5' attr-val='Friday' /><label class='switch_btn' data-on='YES' data-off='NO'></label><br>Friday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day["+num+"][]' value='6' attr-val='Saturday' /><label class='switch_btn' data-on='YES' data-off='NO'></label><br>Saturday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day["+num+"][]' value='7' attr-val='sunday' /><label class='switch_btn' data-on='YES' data-off='NO'></label><br>Sunday</div> </label><hr></div><div class='col-md-12'><label class='menu_remove btn btn-danger pull-right' id='menu_remove_"+num+"' attrmenucount='"+num+"'>Remove</label></hr></div>";
			} else {
			    
				var menuHtml = "<div class='menudetailsform clearfix' id='menudetailsform_1'><div class='col-md-3'> <label class='menu_name_lb_name'>Select Name</label><input type='text' name='menu_name[1]' class='menu_name' id='menu-name-1' attr-key='1' menukey='1' /><span id='menu-name-error-1'></span></div><div class='col-md-3'><label class='menu_image_lb_name'>Upload Menu Image</label><input type='file' class='menu_image' name='menu_image[1][]' multiple id='menu-image-1'></div><div class='col-md-3'> <label class=''>Start Time</label> <input type='text' class='form-control start_time' name='start_time[1]' placeholder='Start Time' /></div><div class='col-md-3'> <label class=''>End Time</label> <input type='text' class='form-control end_time' name='end_time[1]' placeholder='End Time' /></div><div class='col-md-12'><hr> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day[1][]' value='1' attr-val='Monday' /> <label class='switch_btn' data-on='YES' data-off='NO'></label> <br>Monday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day[1][]' value='2' attr-val='Tuesday' /> <label class='switch_btn' data-on='YES' data-off='NO'></label> <br>Tuesday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day[1][]' value='3' attr-val='Wenesday' /> <label class='switch_btn' data-on='YES' data-off='NO'></label> <br>Wenesday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day[1][]' value='4' attr-val='Thuresday' /> <label class='switch_btn' data-on='YES' data-off='NO'></label> <br>Thuresday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day[1][]' value='5' attr-val='Friday' /> <label class='switch_btn' data-on='YES' data-off='NO'></label> <br>Friday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day[1][]' value='6' attr-val='Saturday' /> <label class='switch_btn' data-on='YES' data-off='NO'></label> <br>Saturday</label> <label class='block mt15 switch switch-primary'> <input type='checkbox' name='day[1][]' value='7' attr-val='sunday' /> <label class='switch_btn' data-on='YES' data-off='NO'></label> <br>Sunday</div> </label><hr></div><div class='col-md-12'><label class='menu_remove btn btn-danger pull-right' id='menu_remove_1' attrmenucount='1'>Remove</label></hr></div>";
			}
			$('.menudetails-content').append(menuHtml);
		});
		
		$('body').on('click', '.menu_remove', function() {
			var attrId = $(this).attr('attrmenucount');
			$('#menudetailsform_'+attrId).remove();
		});
		
		$('body').on('click', '.item_remove', function() {
		   $(this).closest('.item-content-div').remove(); 
		});
		
		$('body').on('click', '.sides_remove', function() {
		   $(this).closest('.item-content-div').remove(); 
		});
		
		$('body').on('click', '.addon_remove', function() {
		   $(this).closest('.item-content-div').remove(); 
		});
		
		$('body').on('click', '.variation_remove', function() {
		   $(this).closest('.item-content-div').remove(); 
		});
		
		$('body').on('click', '.topping_remove', function() {
		   $(this).closest('.item-content-div').remove(); 
		});
		
        
        
        $(document).on('click', '.start_time', function(){
           $(this).timepicker({
              changeMonth: true,
              changeYear: true
           }).focus();
           $(this).removeClass('start_time'); 
        });
        
        $(document).on('click', '.end_time', function(){
           $(this).timepicker({
              changeMonth: true,
              changeYear: true
           }).focus();
           $(this).removeClass('end_time'); 
        });


		$('.menuitem').click(function() {
			var menuName = $('.menudetail-select option:selected').val();
			var menuAttr = $('.menudetail-select option:selected').attr('attr-val');
			var menuKey = $('.menudetail-select option:selected').attr('attr-key');
			
			var commonDivId = 'item_content_div_'+menuName;
			
    		if($('#'+commonDivId).length > 0) {
    			
    			if($('#'+commonDivId+ ' > .item-content-div').length > 0) {
    				var lastItemKey = $('#'+commonDivId+ ' > .item-content-div').last().attr('attr-item-key');
    				var newItemkey = parseInt(lastItemKey) + parseInt(1);
    			} else {
    				var newItemkey = 0
    			}
    
    		} else {
    			var newItemkey = parseInt(0);
    		}
		
			var menuHtml = "<div class='item-content-div clearfix' attr-item-key='"+newItemkey+"' attr-menu-key='"+menuKey+"'><h5 class='menu_head'>"+menuName+"</h5><div attrItemcount='"+menuName+"' class='itemform itemform_"+menuName+"' id='itemform_"+menuName+"'><div class='col-md-4 form-group'> <label>Name</label> <input type='text' class='form-control name item-menu-text itemnametext_"+menuName+"_"+newItemkey+" name_"+menuName+"' name='name["+menuKey+"]["+newItemkey+"][]' id='name' placeholder='name'></div><div class='col-md-4 form-group'> <label>Category</label> <input type='text' class='form-control' class='form-control' name='category["+menuKey+"]["+newItemkey+"][]' id='category' placeholder='category'></div><div class='col-md-4 form-group'> <label>Price</label> <input type='text' class='form-control' class='form-control' name='price["+menuKey+"]["+newItemkey+"][]' id='price' placeholder='price'></div><hr class='clearfix' width='100%'><div class='col-md-2 form-group'><label>Gluten Free</label> <select class='form-control' name='gluten_free["+menuKey+"]["+newItemkey+"][]' id='gluten_free'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Kosher</label><select class='form-control' name='kosher["+menuKey+"]["+newItemkey+"][]' id='kosher'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Halal</label> <select class='form-control' name='halal["+menuKey+"]["+newItemkey+"][]' id='halal'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Vegan</label> <select class='form-control' name='vegan["+menuKey+"]["+newItemkey+"][]' id='vegan'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Vegetarian</label> <select class='form-control' name='vegetarian["+menuKey+"]["+newItemkey+"][]' id='vegetarian'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Spicy</label><select class='form-control' name='spicy["+menuKey+"]["+newItemkey+"][]' id='spicy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Ocean Wise</label> <select class='form-control' name='ocean_wise["+menuKey+"]["+newItemkey+"][]' id='ocean_wise'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Msg</label> <select class='form-control' name='msg["+menuKey+"]["+newItemkey+"][]' id='msg'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Corn</label><select class='form-control' name='corn["+menuKey+"]["+newItemkey+"][]' id='corn'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Peanuts</label> <select class='form-control' name='peanuts["+menuKey+"]["+newItemkey+"][]' id='peanuts'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Treenuts</label> <select class='form-control' name='treenuts["+menuKey+"]["+newItemkey+"][]' id='treenuts'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Sulfites</label> <select class='form-control' name='sulfites["+menuKey+"]["+newItemkey+"][]' id='sulfites'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Mustard</label> <select class='form-control' name='mustard["+menuKey+"]["+newItemkey+"][]' id='mustard'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Wheat</label> <select class='form-control' name='wheat["+menuKey+"]["+newItemkey+"][]' id='wheat'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Soy</label> <select class='form-control' name='soy["+menuKey+"]["+newItemkey+"][]' id='soy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Seafood</label> <select class='form-control' name='seafood["+menuKey+"]["+newItemkey+"][]' id='seafood'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Garlic</label> <select class='form-control' name='garlic["+menuKey+"]["+newItemkey+"][]' id='garlic'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Eggs</label> <select class='form-control' name='eggs["+menuKey+"]["+newItemkey+"][]' id='eggs'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Tartrazine</label> <select class='form-control' name='tartrazine["+menuKey+"]["+newItemkey+"][]' id='tartrazine'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Onions</label> <select class='form-control' name='onions["+menuKey+"]["+newItemkey+"][]' id='onions'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Animal Fats Oils</label> <select class='form-control' name='animal_fats_oils["+menuKey+"]["+newItemkey+"][]' id='animal_fats_oils'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Shellfish</label> <select class='form-control' name='shellfish["+menuKey+"]["+newItemkey+"][]' id='shellfish'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Fish</label> <select class='form-control' name='fish["+menuKey+"]["+newItemkey+"][]' id='fish'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label>Sesama</label> <select class='form-control' name='sesama["+menuKey+"]["+newItemkey+"][]' id='sesama'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label>Dairy</label> <select class='form-control' name='dairy["+menuKey+"]["+newItemkey+"][]' id='dairy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><hr class='clearfix' width='100%'><div class='col-md-2 form-group'><label>Saturated Fats</label> <input type='text' class='form-control' class='form-control' name='saturated_fats["+menuKey+"]["+newItemkey+"][]' id='saturated_fats' placeholder='saturated_fats'></div><div class='col-md-2 form-group'><label>Vitamin A</label> <input type='text' class='form-control' class='form-control' name='vitamin_a["+menuKey+"]["+newItemkey+"][]' id='vitamin_a' placeholder='vitamin_a'></div><div class='col-md-2 form-group'><label>Carbs</label> <input type='text' class='form-control' class='form-control' name='carbs["+menuKey+"]["+newItemkey+"][]' id='carbs' placeholder='carbs'></div><div class='col-md-2 form-group'><label></label> <input type='text' class='form-control' class='form-control' name='vitamin_c["+menuKey+"]["+newItemkey+"][]' id='vitamin_c' placeholder='vitamin_c'></div><div class='col-md-2 form-group'><label>Protein</label> <input type='text' class='form-control' class='form-control' name='protein["+menuKey+"]["+newItemkey+"][]' id='protein' placeholder='protein'></div><div class='col-md-2 form-group'><label>Fat</label> <input type='text' class='form-control' class='form-control' name='fat["+menuKey+"]["+newItemkey+"][]' id='fat' placeholder='fat'></div><div class='col-md-2 form-group'><label>Cholesterol</label> <input type='text' class='form-control' class='form-control' name='cholesterol["+menuKey+"]["+newItemkey+"][]' id='cholesterol' placeholder='cholesterol'></div><div class='col-md-2 form-group'><label>Fiber</label> <input type='text' class='form-control' class='form-control' name='fiber["+menuKey+"]["+newItemkey+"][]' id='fiber' placeholder='fiber'></div><div class='col-md-2 form-group'><label>Protien</label> <input type='text' class='form-control' class='form-control' name='protein["+menuKey+"]["+newItemkey+"][]' id='protein' placeholder='protein'></div><div class='col-md-2 form-group'><label>Calcium</label> <input type='text' class='form-control' class='form-control' name='calcium["+menuKey+"]["+newItemkey+"][]' id='calcium' placeholder='calcium'></div><div class='col-md-2 form-group'><label>Calories</label> <input type='text' class='form-control' class='form-control' name='calories["+menuKey+"]["+newItemkey+"][]' id='calories' placeholder='calories'></div><div class='col-md-2 form-group'><label>Sodium</label> <input type='text' class='form-control' class='form-control' name='sodium["+menuKey+"]["+newItemkey+"][]' id='sodium' placeholder='sodium'></div><div class='col-md-2 form-group'><label>Trans Fat</label> <input type='text' class='form-control' class='form-control' name='trans_fat["+menuKey+"]["+newItemkey+"][]' id='trans_fat' placeholder='trans_fat'></div><div class='col-md-2 form-group'><label>Iron</label> <input type='text' class='form-control' class='form-control' name='iron["+menuKey+"]["+newItemkey+"][]' id='iron' placeholder='iron'></div><div class='col-md-2 form-group'><label>Sugar</label> <input type='text' class='form-control' class='form-control' name='sugar["+menuKey+"]["+newItemkey+"][]' id='sugar' placeholder='sugar'></div><div class='col-md-12'><label class='item_remove btn btn-danger pull-right'>Remove</label></div></div></hr> </br>";
    
            var divId = 'item_content_div_'+menuName;
            var itemDiv = $('.item-content').find('#'+divId).html();

            if(typeof itemDiv === 'undefined') {
                //console.log('itemDiv');
                $('.item-content').append('<div class="item-content-div-cls" attr-menu="'+menuName+'" id="'+divId+'" attr-menu-key="'+menuKey+'"></div>');
            }
            $('#'+divId).append(menuHtml);
			//$('.item-content').append(menuHtml);


			var numdiv = $('.itemform_'+menuName).length;

			var IsExistsOpt = false;
			var itemoption;
			for(var i = 0; i<numdiv; i++) {
				var opval = i+1;

				$('#itemopt_'+menuName+' option').each(function(){
					var id = $(this).attr('id');
					if(id = 'itemopt_'+menuName) {
						if($('#itemopt_'+menuName).val() != 'undefined') {
							if ($('#itemopt_'+menuName).val() == i) {
							   IsExistsOpt = true;
							}
						}
					}
				});

				if(!IsExistsOpt) {
					itemoption += '<option value="'+i+'">'+opval+'</option>';
				}
				//console.log(itemoption);
			}


			var IsExists = false;
			$('.additemform').each(function(){
			    if ($(this).attr('id') == 'additemform_'+menuName) 
			        IsExists = true;   
			});
			if(!IsExists) {
				var customItemhtml = "<div class='additemform clearfix' id='additemform_"+menuName+"'><div class='col-md-4'><label id='side_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='itemopt form-control' id='itemopt_"+menuName+"'></select></div><div class='clearfix'></div><label class='specific-sideitem-lb btn btn-danger pull-right' attrval="+menuName+">Add Sides</label><hr width='100%'><div class='w-100 slilde_content_"+menuName+"' id='slilde_content_"+menuName+"'></div></div>";
				/*$('.side_btn').html("<label class='specific-sideitem-lb btn btn-danger pull-right' attrval="+menuName+">Add Sides</label>");*/
				//$('.customslide').append(customItemhtml);


				var customAddonhtml = "<div class='addaddonform clearfix' id='addaddonform_"+menuName+"'><div class='col-md-4'><label id='addon_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='addonopt form-control' id='addonopt_"+menuName+"'></select></div><div class='clearfix'></div><label class='specific-addonitem-lb btn btn-danger pull-right' attrval="+menuName+">Add Addon</label><hr width='100%'><div class='w-100 addon_content_"+menuName+"' id='addon_content_"+menuName+"'></div></div>";
				/*$('.addon_btn').html("<label class='specific-addonitem-lb btn btn-danger pull-right' attrval="+menuName+">Add Addon</label>");*/
				//$('.customaddon').append(customAddonhtml);


				var customVariationhtml = "<div class='addvariationform clearfix' id='addvariationform_"+menuName+"'><div class='col-md-4'><label id='variation_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='variationopt form-control' id='variationopt_"+menuName+"'></select></div><div class='clearfix'></div><label class='specific-variationitem-lb btn btn-danger pull-right' attrval="+menuName+">Add Variation</label><hr width='100%'><div class='w-100 variation_content_"+menuName+"' id='variation_content_"+menuName+"'></div></div>";
				/*$('.variation_btn').html("<label class='specific-variationitem-lb btn btn-danger pull-right' attrval="+menuName+">Add Variation</label>");*/
				//$('.customvariations').append(customVariationhtml);

				var customToppinghtml = "<div class='addtoppingform clearfix' id='addtoppingform_"+menuName+"'><div class='col-md-4'><label id='topping_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='toppingopt form-control' id='toppingopt_"+menuName+"'></select></div><div class='clearfix'></div><label class='specific-toppingitem-lb btn btn-danger pull-right' attrval="+menuName+">Add Topping</label><hr width='100%'><div class='w-100 topping_content_"+menuName+"' id='topping_content_"+menuName+"'></div></div>";
				/*$('.topping_btn').html("<label class='specific-toppingitem-lb btn btn-danger pull-right' attrval="+menuName+">Add Topping</label>");*/
				//$('.customtopping').append(customToppinghtml);

			} else {
				$('#additemform_'+menuName).find('.itemopt').append(itemoption)
			}


			var t;
			var r = $('.itemform_'+menuName).length;
			for(var d = 0; d<r; d++) {
				var o = d+1;
				   t += '<option value="'+d+'">'+o+'</option>';
			}
			$('#itemopt_'+menuName).append(t);
			$('#addonopt_'+menuName).append(t);
			$('#variationopt_'+menuName).append(t);
			$('#toppingopt_'+menuName).append(t);


			var optionValues =[];
			$('#itemopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValues) >-1){
			      $(this).remove()
			   }else{
			      optionValues.push(this.value);
			   }
			});

			var optionValuesA =[];
			$('#addonopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValuesA) >-1){
			      $(this).remove()
			   }else{
			      optionValuesA.push(this.value);
			   }
			});

			var optionValuesV =[];
			$('#variationopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValuesV) >-1){
			      $(this).remove()
			   }else{
			      optionValuesV.push(this.value);
			   }
			});

			
			var optionValuesT =[];
			$('#toppingopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValuesT) >-1){
			      $(this).remove()
			   }else{
			      optionValuesT.push(this.value);
			   }
			});

		});

		$('body').on('click', '.specific-sideitem-lb', function() {
			var menuId = $(this).attr('attr-menu');
			var itemId = $(this).attr('attr-item');
			var menyKey = $(this).attr('attr-menu-key');
			
			
			var sidehtml = "<div class='side-content-div-cls' attr-menu='"+menuId+"' attr-item='"+itemId+"' attr-menu-key='"+menyKey+"' attr-slide='' id=''><div class='item-content-div clearfix'><h5 class='menu_head'>Menu"+menuId+" AND Item "+itemId+"</h5><div class='sideform'><div class='col-md-3 form-group'><label class='side_standard'>standard</label> <select class='form-control' name='side_standard["+menyKey+"]["+itemId+"][]' id='standard'><option value='true'>true</option><option value='false'>false</option> </select></div><div class='col-md-3 form-group'><label >Name</label> <input type='text' class='form-control' class='form-control name' name='side_name["+menyKey+"]["+itemId+"][]' id='name' placeholder='name'></div><div class='col-md-3 form-group'><label >Category</label> <input type='text' class='form-control' class='form-control' name='side_category["+menyKey+"]["+itemId+"][]' id='category' placeholder='category'></div><div class='col-md-3 form-group'><label >Price</label> <input type='text' class='form-control' class='form-control' name='side_price["+menyKey+"]["+itemId+"][]' id='price' placeholder='price'></div><div class='clearfix'></div><hr class='clearfix' width='100%'><div class='col-md-2 form-group'><label >Glutten</label> <select class='form-control' name='side_gluten_free["+menyKey+"]["+itemId+"][]' id='gluten_free'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option></select></div><div class='col-md-2 form-group'><label >Kosher</label> <select class='form-control' name='side_kosher["+menyKey+"]["+itemId+"][]' id='kosher'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Halal</label> <select class='form-control' name='side_halal["+menyKey+"]["+itemId+"][]' id='halal'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Vegan</label> <select class='form-control' name='side_vegan["+menyKey+"]["+itemId+"][]' id='vegan'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Vegetarian</label> <select class='form-control' name='side_vegetarian["+menyKey+"]["+itemId+"][]' id='vegetarian'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Spicy</label> <select class='form-control' name='side_spicy["+menyKey+"]["+itemId+"][]' id='spicy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Ocean</label> <select class='form-control' name='side_ocean_wise["+menyKey+"]["+itemId+"][]' id='ocean_wise'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Msg</label> <select class='form-control' name='side_msg["+menyKey+"]["+itemId+"][]' id='msg'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Corn</label> <select class='form-control' name='side_corn["+menyKey+"]["+itemId+"][]' id='corn'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Peanuts</label> <select class='form-control' name='side_peanuts["+menyKey+"]["+itemId+"][]' id='peanuts'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Treenuts</label> <select class='form-control' name='side_treenuts["+menyKey+"]["+itemId+"][]' id='treenuts'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Sulfites</label> <select class='form-control' name='side_sulfites["+menyKey+"]["+itemId+"][]' id='sulfites'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Mustard</label> <select class='form-control' name='side_mustard["+menyKey+"]["+itemId+"][]' id='mustard'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Wheat</label> <select class='form-control' name='side_wheat["+menyKey+"]["+itemId+"][]' id='wheat'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Soy</label> <select class='form-control' name='side_soy["+menyKey+"]["+itemId+"][]' id='soy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Seafood</label> <select class='form-control' name='side_seafood["+menyKey+"]["+itemId+"][]' id='seafood'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Garlic</label> <select class='form-control' name='side_garlic["+menyKey+"]["+itemId+"][]' id='garlic'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Eggs</label> <select class='form-control' name='side_eggs["+menyKey+"]["+itemId+"][]' id='eggs'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Tarazine</label> <select class='form-control' name='side_tartrazine["+menyKey+"]["+itemId+"][]' id='tartrazine'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Onions</label> <select class='form-control' name='side_onions["+menyKey+"]["+itemId+"][]' id='onions'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Animal Fats</label> <select class='form-control' name='side_animal_fats_oils["+menyKey+"]["+itemId+"][]' id='animal_fats_oils'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >ShellFish</label> <select class='form-control' name='side_shellfish["+menyKey+"]["+itemId+"][]' id='shellfish'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Fish</label> <select class='form-control' name='side_fish["+menyKey+"]["+itemId+"][]' id='fish'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Sesama</label> <select class='form-control' name='side_sesama["+menyKey+"]["+itemId+"][]' id='sesama'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Dairy</label> <select class='form-control' name='side_dairy["+menyKey+"]["+itemId+"][]' id='dairy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='clearfix'></div><hr class='clearfix' width='100%'><div class='col-md-2 form-group'><label >Saturated Fats</label> <input type='text' class='form-control' class='form-control' name='side_saturated_fats["+menyKey+"]["+itemId+"][]' id='saturated_fats' placeholder='saturated_fats'></div><div class='col-md-2 form-group'><label >Vitamin A</label> <input type='text' class='form-control' class='form-control' name='side_vitamin_a["+menyKey+"]["+itemId+"][]' id='vitamin_a' placeholder='vitamin_a'></div><div class='col-md-2 form-group'><label >Carbs</label> <input type='text' class='form-control' class='form-control' name='side_carbs["+menyKey+"]["+itemId+"][]' id='carbs' placeholder='carbs'></div><div class='col-md-2 form-group'><label >Vitamin C</label> <input type='text' class='form-control' class='form-control' name='side_vitamin_c["+menyKey+"]["+itemId+"][]' id='vitamin_c' placeholder='vitamin_c'></div><div class='col-md-2 form-group'><label >Protien</label> <input type='text' class='form-control' class='form-control' name='side_protein["+menyKey+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-2 form-group'><label >Fat</label> <input type='text' class='form-control' class='form-control' name='side_fat["+menyKey+"]["+itemId+"][]' id='fat' placeholder='fat'></div><div class='col-md-2 form-group'><label >Cholesterol</label> <input type='text' class='form-control' class='form-control' name='side_cholesterol["+menyKey+"]["+itemId+"][]' id='cholesterol' placeholder='cholesterol'></div><div class='col-md-2 form-group'><label >Fiber</label> <input type='text' class='form-control' class='form-control' name='side_fiber["+menyKey+"]["+itemId+"][]' id='fiber' placeholder='fiber'></div><div class='col-md-2 form-group'><label >Protien</label> <input type='text' class='form-control' class='form-control' name='side_protein["+menyKey+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-2 form-group'><label >Calcium</label> <input type='text' class='form-control' class='form-control' name='side_calcium["+menyKey+"]["+itemId+"][]' id='calcium' placeholder='calcium'></div><div class='col-md-2 form-group'><label >Calories</label> <input type='text' class='form-control' class='form-control' name='side_calories["+menyKey+"]["+itemId+"][]' id='calories' placeholder='calories'></div><div class='col-md-2 form-group'><label >Sodium</label> <input type='text' class='form-control' class='form-control' name='side_sodium["+menyKey+"]["+itemId+"][]' id='sodium' placeholder='sodium'></div><div class='col-md-2 form-group'><label >Trans Fat</label> <input type='text' class='form-control' class='form-control' name='side_trans_fat["+menyKey+"]["+itemId+"][]' id='trans_fat' placeholder='trans_fat'></div><div class='col-md-2 form-group'><label >Iron</label> <input type='text' class='form-control' class='form-control' name='side_iron["+menyKey+"]["+itemId+"][]' id='iron' placeholder='iron'></div><div class='col-md-2 form-group'><label >Sugar</label> <input type='text' class='form-control' class='form-control' name='side_sugar["+menyKey+"]["+itemId+"][]' id='sugar' placeholder='sugar'></div><div class='col-md-12'><label class='sides_remove btn btn-danger pull-right'>Remove</label></div></div></hr> </br></div></div>";

			if($('#menu_side_content_div_'+menuId).length == 0) {
				$('.item-side-content').append('<div class="menu-side-content-div-cls" attr-menu="'+menuId+'" id="menu_side_content_div_'+menuId+'" attr-menu-key="'+menyKey+'"></div>');
			}

			if($('#menu_item2_side_content_cls_'+menuId+'_'+itemId).length == 0) {
			  $('#menu_side_content_div_'+menuId).append('<div class="menu-item2-side-content-cls" id="menu_item2_side_content_cls_'+menuId+'_'+itemId+'" attr-menu-key="'+menyKey+'" attr-item-key="'+itemId+'"></div>');
			}
			$('#menu_item2_side_content_cls_'+menuId+'_'+itemId).append(sidehtml);
		});


		$('body').on('click', '.specific-addonitem-lb', function() {
			var menuId = $(this).attr('attr-menu');
			var itemId = $(this).attr('attr-item');
			var menyKey = $(this).attr('attr-menu-key');
			
			var addonhtml = "<div class='addon-content-div-cls' attr-menu='"+menuId+"' attr-item='"+itemId+"' attr-menu-key='"+menyKey+"' attr-slide='' id=''><div class='item-content-div clearfix'><h5 class='menu_head'>Menu"+menuId+" AND Item "+itemId+"</h5><div class='addonform'><div class='col-md-4 form-group'><label >Name</label> <input type='text' class='form-control' class='form-control name' name='addon_name["+menyKey+"]["+itemId+"][]' id='name' placeholder='name'></div><div class='col-md-4 form-group'><label >Category</label> <input type='text' class='form-control' class='form-control' name='addon_category["+menyKey+"]["+itemId+"][]' id='category' placeholder='category'></div><div class='col-md-4 form-group'><label >Price</label> <input type='text' class='form-control' class='form-control' name='addon_price["+menyKey+"]["+itemId+"][]' id='price' placeholder='price'></div><div class='clearfix'></div><hr class='clearfix' width='100%'><div class='col-md-2 form-group'><label >Glutten</label> <select class='form-control' name='addon_gluten_free["+menyKey+"]["+itemId+"][]' id='gluten_free'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Kosher</label> <select class='form-control' name='addon_kosher["+menyKey+"]["+itemId+"][]' id='kosher'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Halal</label> <select class='form-control' name='addon_halal["+menyKey+"]["+itemId+"][]' id='halal'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Vegan</label> <select class='form-control' name='addon_vegan["+menyKey+"]["+itemId+"][]' id='vegan'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Vegetarian</label> <select class='form-control' name='addon_vegetarian["+menyKey+"]["+itemId+"][]' id='vegetarian'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Spicy</label> <select class='form-control' name='addon_spicy["+menyKey+"]["+itemId+"][]' id='spicy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Ocean</label> <select class='form-control' name='addon_ocean_wise["+menyKey+"]["+itemId+"][]' id='ocean_wise'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Msg</label> <select class='form-control' name='addon_msg["+menyKey+"]["+itemId+"][]' id='msg'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Corn</label> <select class='form-control' name='addon_corn["+menyKey+"]["+itemId+"][]' id='corn'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Peanuts</label> <select class='form-control' name='addon_peanuts["+menyKey+"]["+itemId+"][]' id='peanuts'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Treenuts</label> <select class='form-control' name='addon_treenuts["+menyKey+"]["+itemId+"][]' id='treenuts'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Sulfites</label> <select class='form-control' name='addon_sulfites["+menyKey+"]["+itemId+"][]' id='sulfites'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Mustard</label> <select class='form-control' name='addon_mustard["+menyKey+"]["+itemId+"][]' id='mustard'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Wheat</label> <select class='form-control' name='addon_wheat["+menyKey+"]["+itemId+"][]' id='wheat'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Soy</label> <select class='form-control' name='addon_soy["+menyKey+"]["+itemId+"][]' id='soy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Seafood</label> <select class='form-control' name='addon_seafood["+menyKey+"]["+itemId+"][]' id='seafood'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Garlic</label> <select class='form-control' name='addon_garlic["+menyKey+"]["+itemId+"][]' id='garlic'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Eggs</label> <select class='form-control' name='addon_eggs["+menyKey+"]["+itemId+"][]' id='eggs'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Tarazine</label> <select class='form-control' name='addon_tartrazine["+menyKey+"]["+itemId+"][]' id='tartrazine'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Onions</label> <select class='form-control' name='addon_onions["+menyKey+"]["+itemId+"][]' id='onions'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Animal Fats</label> <select class='form-control' name='addon_animal_fats_oils["+menyKey+"]["+itemId+"][]' id='animal_fats_oils'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >ShellFish</label> <select class='form-control' name='addon_shellfish["+menyKey+"]["+itemId+"][]' id='shellfish'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Fish</label> <select class='form-control' name='addon_fish["+menyKey+"]["+itemId+"][]' id='fish'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Sesama</label> <select class='form-control' name='addon_sesama["+menyKey+"]["+itemId+"][]' id='sesama'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Dairy</label> <select class='form-control' name='addon_dairy["+menyKey+"]["+itemId+"][]' id='dairy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='clearfix'></div><hr class='clearfix' width='100%'><div class='col-md-2 form-group'><label >Saturated Fats</label> <input type='text' class='form-control' class='form-control' name='addon_saturated_fats["+menyKey+"]["+itemId+"][]' id='saturated_fats' placeholder='saturated_fats'></div><div class='col-md-2 form-group'><label >Vitamin A</label> <input type='text' class='form-control' class='form-control' name='addon_vitamin_a["+menyKey+"]["+itemId+"][]' id='vitamin_a' placeholder='vitamin_a'></div><div class='col-md-2 form-group'><label >Carbs</label> <input type='text' class='form-control' class='form-control' name='addon_carbs["+menyKey+"]["+itemId+"][]' id='carbs' placeholder='carbs'></div><div class='col-md-2 form-group'><label >Vitamin C</label> <input type='text' class='form-control' class='form-control' name='addon_vitamin_c["+menyKey+"]["+itemId+"][]' id='vitamin_c' placeholder='vitamin_c'></div><div class='col-md-2 form-group'><label >Protien</label> <input type='text' class='form-control' class='form-control' name='addon_protein["+menyKey+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-2 form-group'><label >Fat</label> <input type='text' class='form-control' class='form-control' name='addon_fat["+menyKey+"]["+itemId+"][]' id='fat' placeholder='fat'></div><div class='col-md-2 form-group'><label >Cholesterol</label> <input type='text' class='form-control' class='form-control' name='addon_cholesterol["+menyKey+"]["+itemId+"][]' id='cholesterol' placeholder='cholesterol'></div><div class='col-md-2 form-group'><label >Fiber</label> <input type='text' class='form-control' class='form-control' name='addon_fiber["+menyKey+"]["+itemId+"][]' id='fiber' placeholder='fiber'></div><div class='col-md-2 form-group'><label >Protien</label> <input type='text' class='form-control' class='form-control' name='addon_protein["+menyKey+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-2 form-group'><label >Calcium</label> <input type='text' class='form-control' class='form-control' name='addon_calcium["+menyKey+"]["+itemId+"][]' id='calcium' placeholder='calcium'></div><div class='col-md-2 form-group'><label >Calories</label> <input type='text' class='form-control' class='form-control' name='addon_calories["+menyKey+"]["+itemId+"][]' id='calories' placeholder='calories'></div><div class='col-md-2 form-group'><label >Sodium</label> <input type='text' class='form-control' class='form-control' name='addon_sodium["+menyKey+"]["+itemId+"][]' id='sodium' placeholder='sodium'></div><div class='col-md-2 form-group'><label >Trans Fat</label> <input type='text' class='form-control' class='form-control' name='addon_trans_fat["+menyKey+"]["+itemId+"][]' id='trans_fat' placeholder='trans_fat'></div><div class='col-md-2 form-group'><label >Iron</label> <input type='text' class='form-control' class='form-control' name='addon_iron["+menyKey+"]["+itemId+"][]' id='iron' placeholder='iron'></div><div class='col-md-2 form-group'><label >Sugar</label> <input type='text' class='form-control' class='form-control' name='addon_sugar["+menyKey+"]["+itemId+"][]' id='sugar' placeholder='sugar'></div><div class='col-md-12'><label class='addon_remove btn btn-danger pull-right'>Remove</label></div></div></hr></div></div>";

			//$('.addon_content_'+menuId).append(addonhtml);
			
			if($('#menu_addon_content_div_'+menuId).length == 0) {
				$('.item-addon-content').append('<div class="menu-addon-content-div-cls" attr-menu="'+menuId+'" id="menu_addon_content_div_'+menuId+'" attr-menu-key="'+menyKey+'"></div>');
			}

			if($('#menu_item2_addon_content_cls_'+menuId+'_'+itemId).length == 0) {
				$('#menu_addon_content_div_'+menuId).append('<div class="menu-item2-addon-content-cls" id="menu_item2_addon_content_cls_'+menuId+'_'+itemId+'" attr-menu-key="'+menyKey+'" attr-item-key="'+itemId+'"></div>');
			}
			$('#menu_item2_addon_content_cls_'+menuId+'_'+itemId).append(addonhtml);
		});


		$('body').on('click', '.specific-variationitem-lb', function() {
			var menuId = $(this).attr('attr-menu');
			var itemId = $(this).attr('attr-item');
			var menyKey = $(this).attr('attr-menu-key');

			var variationhtml = "<div class='variation-content-div-cls' attr-menu='"+menuId+"' attr-item='"+itemId+"' attr-menu-key='"+menyKey+"' attr-slide='' id=''><div class='item-content-div clearfix'><h5 class='menu_head'>Menu"+menuId+" AND Item "+itemId+"</h5><div class='variationform'><div class='col-md-4 form-group'><label >Name</label> <input type='text' class='form-control' class='form-control name' name='variation_name["+menyKey+"]["+itemId+"][]' id='name' placeholder='name'></div><div class='col-md-4 form-group'><label >Category</label> <input type='text' class='form-control' class='form-control' name='variation_category["+menyKey+"]["+itemId+"][]' id='category' placeholder='category'></div><div class='col-md-4 form-group'><label >Price</label> <input type='text' class='form-control' class='form-control' name='variation_price["+menyKey+"]["+itemId+"][]' id='price' placeholder='price'></div><div class='clearfix'></div><hr class='clearfix'><div class='col-md-2 form-group'><label >Glutten</label> <select class='form-control' name='variation_gluten_free["+menyKey+"]["+itemId+"][]' id='gluten_free'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Kosher</label> <select class='form-control' name='variation_kosher["+menyKey+"]["+itemId+"][]' id='kosher'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Halal</label> <select class='form-control' name='variation_halal["+menyKey+"]["+itemId+"][]' id='halal'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Vegan</label> <select class='form-control' name='variation_vegan["+menyKey+"]["+itemId+"][]' id='vegan'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Vegetarian</label> <select class='form-control' name='variation_vegetarian["+menyKey+"]["+itemId+"][]' id='vegetarian'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Spicy</label> <select class='form-control' name='variation_spicy["+menyKey+"]["+itemId+"][]' id='spicy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Ocean</label> <select class='form-control' name='variation_ocean_wise["+menyKey+"]["+itemId+"][]' id='ocean_wise'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Msg</label> <select class='form-control' name='variation_msg["+menyKey+"]["+itemId+"][]' id='msg'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Corn</label> <select class='form-control' name='variation_corn["+menyKey+"]["+itemId+"][]' id='corn'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Peanuts</label> <select class='form-control' name='variation_peanuts["+menyKey+"]["+itemId+"][]' id='peanuts'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Treenuts</label> <select class='form-control' name='variation_treenuts["+menyKey+"]["+itemId+"][]' id='treenuts'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Sulfites</label> <select class='form-control' name='variation_sulfites["+menyKey+"]["+itemId+"][]' id='sulfites'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Mustard</label> <select class='form-control' name='variation_mustard["+menyKey+"]["+itemId+"][]' id='mustard'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Wheat</label> <select class='form-control' name='variation_wheat["+menyKey+"]["+itemId+"][]' id='wheat'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Soy</label> <select class='form-control' name='variation_soy["+menyKey+"]["+itemId+"][]' id='soy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Seafood</label> <select class='form-control' name='variation_seafood["+menyKey+"]["+itemId+"][]' id='seafood'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Garlic</label> <select class='form-control' name='variation_garlic["+menyKey+"]["+itemId+"][]' id='garlic'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Eggs</label> <select class='form-control' name='variation_eggs["+menyKey+"]["+itemId+"][]' id='eggs'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Tarazine</label> <select class='form-control' name='variation_tartrazine["+menyKey+"]["+itemId+"][]' id='tartrazine'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Onions</label> <select class='form-control' name='variation_onions["+menyKey+"]["+itemId+"][]' id='onions'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Animal Fats</label> <select class='form-control' name='variation_animal_fats_oils["+menyKey+"]["+itemId+"][]' id='animal_fats_oils'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >ShellFish</label> <select class='form-control' name='variation_shellfish["+menyKey+"]["+itemId+"][]' id='shellfish'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Fish</label> <select class='form-control' name='variation_fish["+menyKey+"]["+itemId+"][]' id='fish'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Sesama</label> <select class='form-control' name='variation_sesama["+menyKey+"]["+itemId+"][]' id='sesama'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Dairy</label> <select class='form-control' name='variation_dairy["+menyKey+"]["+itemId+"][]' id='dairy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='clearfix'></div><hr class='clearfix'><div class='col-md-2 form-group'><label >Saturated Fats</label> <input type='text' class='form-control' class='form-control' name='variation_saturated_fats["+menyKey+"]["+itemId+"][]' id='saturated_fats' placeholder='saturated_fats'></div><div class='col-md-2 form-group'><label >Vitamins</label> <input type='text' class='form-control' class='form-control' name='variation_vitamin_a["+menyKey+"]["+itemId+"][]' id='vitamin_a' placeholder='vitamin_a'></div><div class='col-md-2 form-group'><label >Carbs</label> <input type='text' class='form-control' class='form-control' name='variation_carbs["+menyKey+"]["+itemId+"][]' id='carbs' placeholder='carbs'></div><div class='col-md-2 form-group'><label >Vitamin C</label> <input type='text' class='form-control' class='form-control' name='variation_vitamin_c["+menyKey+"]["+itemId+"][]' id='vitamin_c' placeholder='vitamin_c'></div><div class='col-md-2 form-group'><label >Protien</label> <input type='text' class='form-control' class='form-control' name='variation_protein["+menyKey+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-2 form-group'><label >Fat</label> <input type='text' class='form-control' class='form-control' name='variation_fat["+menyKey+"]["+itemId+"][]' id='fat' placeholder='fat'></div><div class='col-md-2 form-group'><label >Cholesterol</label> <input type='text' class='form-control' class='form-control' name='variation_cholesterol["+menyKey+"]["+itemId+"][]' id='cholesterol' placeholder='cholesterol'></div><div class='col-md-2 form-group'><label >Fiber</label> <input type='text' class='form-control' class='form-control' name='variation_fiber["+menyKey+"]["+itemId+"][]' id='fiber' placeholder='fiber'></div><div class='col-md-2 form-group'><label >Protien</label> <input type='text' class='form-control' class='form-control' name='variation_protein["+menyKey+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-2 form-group'><label >Calcium</label> <input type='text' class='form-control' class='form-control' name='variation_calcium["+menyKey+"]["+itemId+"][]' id='calcium' placeholder='calcium'></div><div class='col-md-2 form-group'><label >Calories</label> <input type='text' class='form-control' class='form-control' name='variation_calories["+menyKey+"]["+itemId+"][]' id='calories' placeholder='calories'></div><div class='col-md-2 form-group'><label >Sodium</label> <input type='text' class='form-control' class='form-control' name='variation_sodium["+menyKey+"]["+itemId+"][]' id='sodium' placeholder='sodium'></div><div class='col-md-2 form-group'><label >Trans Fat</label> <input type='text' class='form-control' class='form-control' name='variation_trans_fat["+menyKey+"]["+itemId+"][]' id='trans_fat' placeholder='trans_fat'></div><div class='col-md-2 form-group'><label >Iron</label> <input type='text' class='form-control' class='form-control' name='variation_iron["+menyKey+"]["+itemId+"][]' id='iron' placeholder='iron'></div><div class='col-md-2 form-group'><label >Sugar</label> <input type='text' class='form-control' class='form-control' name='variation_sugar["+menyKey+"]["+itemId+"][]' id='sugar' placeholder='sugar'></div><div class='col-md-12'><label class='variation_remove btn btn-danger pull-right'>Remove</label></div></div></hr></div></div>";

			//$('.variation_content_'+menuId).append(variationhtml);
			
			if($('#menu_variation_content_div_'+menuId).length == 0) {
				$('.item-variation-content').append('<div class="menu-variation-content-div-cls" attr-menu="'+menuId+'" id="menu_variation_content_div_'+menuId+'" attr-menu-key="'+menyKey+'"></div>');
			}

			if($('#menu_item2_variation_content_cls_'+menuId+'_'+itemId).length == 0) {
				$('#menu_variation_content_div_'+menuId).append('<div class="menu-item2-variation-content-cls" id="menu_item2_variation_content_cls_'+menuId+'_'+itemId+'" attr-menu-key="'+menyKey+'" attr-item-key="'+itemId+'"></div>');
			}
			$('#menu_item2_variation_content_cls_'+menuId+'_'+itemId).append(variationhtml);
		});


		$('body').on('click', '.specific-toppingitem-lb', function() {
			var menuId = $(this).attr('attr-menu');
			var itemId = $(this).attr('attr-item');
			var menyKey = $(this).attr('attr-menu-key');
			
			
			var toppinghtml = "<div class='topping-content-div-cls' attr-menu='"+menuId+"' attr-item='"+itemId+"' attr-menu-key='"+menyKey+"' attr-slide='' id=''><div class='item-content-div clearfix'><h5 class='menu_head'>Menu"+menuId+" AND Item "+itemId+"</h5><div class='toppingform'><div class='col-md-4 form-group'><label >Name</label> <input type='text' class='form-control' class='form-control name' name='topping_name["+menyKey+"]["+itemId+"][]' id='name' placeholder='name'></div><div class='col-md-4 form-group'><label >Category</label> <input type='text' class='form-control' class='form-control' name='topping_category["+menyKey+"]["+itemId+"][]' id='category' placeholder='category'></div><div class='col-md-4 form-group'><label >Price</label> <input type='text' class='form-control' class='form-control' name='topping_price["+menyKey+"]["+itemId+"][]' id='price' placeholder='price'></div><div class='clearfix'></div><hr class='clearfix'><div class='col-md-2 form-group'><label >Glutten</label> <select class='form-control' name='topping_gluten_free["+menyKey+"]["+itemId+"][]' id='gluten_free'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Kosher</label> <select class='form-control' name='topping_kosher["+menyKey+"]["+itemId+"][]' id='kosher'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Halal</label> <select class='form-control' name='topping_halal["+menyKey+"]["+itemId+"][]' id='halal'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Vegan</label> <select class='form-control' name='topping_vegan["+menyKey+"]["+itemId+"][]' id='vegan'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Vegetarian</label> <select class='form-control' name='topping_vegetarian["+menyKey+"]["+itemId+"][]' id='vegetarian'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Spicy</label> <select class='form-control' name='topping_spicy["+menyKey+"]["+itemId+"][]' id='spicy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Ocean</label> <select class='form-control' name='topping_ocean_wise["+menyKey+"]["+itemId+"][]' id='ocean_wise'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Msg</label> <select class='form-control' name='topping_msg["+menyKey+"]["+itemId+"][]' id='msg'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Corn</label> <select class='form-control' name='topping_corn["+menyKey+"]["+itemId+"][]' id='corn'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Peanuts</label> <select class='form-control' name='topping_peanuts["+menyKey+"]["+itemId+"][]' id='peanuts'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Treenuts</label> <select class='form-control' name='topping_treenuts["+menyKey+"]["+itemId+"][]' id='treenuts'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Sulfites</label> <select class='form-control' name='topping_sulfites["+menyKey+"]["+itemId+"][]' id='sulfites'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Mustard</label> <select class='form-control' name='topping_mustard["+menyKey+"]["+itemId+"][]' id='mustard'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Wheat</label> <select class='form-control' name='topping_wheat["+menyKey+"]["+itemId+"][]' id='wheat'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Soy</label> <select class='form-control' name='topping_soy["+menyKey+"]["+itemId+"][]' id='soy'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Seafood</label> <select class='form-control' name='topping_seafood["+menyKey+"]["+itemId+"][]' id='seafood'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Garlic</label> <select class='form-control' name='topping_garlic["+menyKey+"]["+itemId+"][]' id='garlic'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Eggs</label> <select class='form-control' name='topping_eggs["+menyKey+"]["+itemId+"][]' id='eggs'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Tarazine</label> <select class='form-control' name='topping_tartrazine["+menyKey+"]["+itemId+"][]' id='tartrazine'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Onions</label> <select class='form-control' name='topping_onions["+menyKey+"]["+itemId+"][]' id='onions'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Animal Fats</label> <select class='form-control' name='topping_animal_fats_oils["+menyKey+"]["+itemId+"][]' id='animal_fats_oils'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >ShellFish</label> <select class='form-control' name='topping_shellfish["+menyKey+"]["+itemId+"][]' id='shellfish'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Fish</label> <select class='form-control' name='topping_fish["+menyKey+"]["+itemId+"][]' id='fish'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Sesama</label> <select class='form-control' name='topping_sesama["+menyKey+"]["+itemId+"][]' id='sesama'><option value='NA'>NA</option><option value='Y'>Y</option><option value='N'>N</option> </select></div><div class='col-md-2 form-group'><label >Dairy</label> <select class='form-control' name='topping_dairy["+menyKey+"]["+itemId+"][]' id='dairy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option> </select></div><div class='clearfix'></div><hr class='clearfix'><div class='col-md-2 form-group'><label >Saturated Fats</label> <input type='text' class='form-control' class='form-control' name='topping_saturated_fats["+menyKey+"]["+itemId+"][]' id='saturated_fats' placeholder='saturated_fats'></div><div class='col-md-2 form-group'><label >Vitamins</label> <input type='text' class='form-control' class='form-control' name='topping_vitamin_a["+menyKey+"]["+itemId+"][]' id='vitamin_a' placeholder='vitamin_a'></div><div class='col-md-2 form-group'><label >Carbs</label> <input type='text' class='form-control' class='form-control' name='topping_carbs["+menyKey+"]["+itemId+"][]' id='carbs' placeholder='carbs'></div><div class='col-md-2 form-group'><label >Vitamin C</label> <input type='text' class='form-control' class='form-control' name='topping_vitamin_c["+menyKey+"]["+itemId+"][]' id='vitamin_c' placeholder='vitamin_c'></div><div class='col-md-2 form-group'><label >Protien</label> <input type='text' class='form-control' class='form-control' name='topping_protein["+menyKey+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-2 form-group'><label >Fat</label> <input type='text' class='form-control' class='form-control' name='topping_fat["+menyKey+"]["+itemId+"][]' id='fat' placeholder='fat'></div><div class='col-md-2 form-group'><label >Cholesterol</label> <input type='text' class='form-control' class='form-control' name='topping_cholesterol["+menyKey+"]["+itemId+"][]' id='cholesterol' placeholder='cholesterol'></div><div class='col-md-2 form-group'><label >Fiber</label> <input type='text' class='form-control' class='form-control' name='topping_fiber["+menyKey+"]["+itemId+"][]' id='fiber' placeholder='fiber'></div><div class='col-md-2 form-group'><label >Protien</label> <input type='text' class='form-control' class='form-control' name='topping_protein["+menyKey+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-2 form-group'><label >Calcium</label> <input type='text' class='form-control' class='form-control' name='topping_calcium["+menyKey+"]["+itemId+"][]' id='calcium' placeholder='calcium'></div><div class='col-md-2 form-group'><label >Calories</label> <input type='text' class='form-control' class='form-control' name='topping_calories["+menyKey+"]["+itemId+"][]' id='calories' placeholder='calories'></div><div class='col-md-2 form-group'><label >Sodium</label> <input type='text' class='form-control' class='form-control' name='topping_sodium["+menyKey+"]["+itemId+"][]' id='sodium' placeholder='sodium'></div><div class='col-md-2 form-group'><label >Trans Fat</label> <input type='text' class='form-control' class='form-control' name='topping_trans_fat["+menyKey+"]["+itemId+"][]' id='trans_fat' placeholder='trans_fat'></div><div class='col-md-2 form-group'><label >Iron</label> <input type='text' class='form-control' class='form-control' name='topping_iron["+menyKey+"]["+itemId+"][]' id='iron' placeholder='iron'></div><div class='col-md-2 form-group'><label >Sugar</label> <input type='text' class='form-control' class='form-control' name='topping_sugar["+menyKey+"]["+itemId+"][]' id='sugar' placeholder='sugar'></div><div class='col-md-12'><label class='topping_remove btn btn-danger pull-right'>Remove</label></div></div></hr></div></div>";

			//$('.topping_content_'+menuId).append(toppinghtml);
			
			if($('#menu_topping_content_div_'+menuId).length == 0) {
				$('.item-topping-content').append('<div class="menu-topping-content-div-cls" attr-menu="'+menuId+'" id="menu_topping_content_div_'+menuId+'" attr-menu-key="'+menyKey+'"></div>');
			}

			if($('#menu_item2_topping_content_cls_'+menuId+'_'+itemId).length == 0) {
				$('#menu_topping_content_div_'+menuId).append('<div class="menu-item2-topping-content-cls" id="menu_item2_addon_content_cls_'+menuId+'_'+itemId+'" attr-menu-key="'+menyKey+'" attr-item-key="'+itemId+'"></div>');
			}
			$('#menu_item2_topping_content_cls_'+menuId+'_'+itemId).append(toppinghtml);
		});
		
		$('body').on('keyup', '.menu_name', function() {
		    var textval = $(this).val();
			var menuID = $(this).attr('id');
			var menuKey = $(this).attr('attr-key');
			var regex = /^[a-zA-Z ]*$/;
			if(textval == '') {
				$('#nextBtn').attr('disabled','disabled');
				$('#menu-name-error-'+menuKey).text('Please enter menu name');
				valid = false;
			} else if(!regex.test(textval)) {
				$('#nextBtn').attr('disabled','disabled');
				$('#menu-name-error-'+menuKey).text('Please enter alphabates');
				valid = false;
			} else {
				//$('#'+menuID).after('p').remove();
				$('#nextBtn').removeAttr('disabled');
				$('#menu-name-error-'+menuKey).text('');
				valid = true;
			}
		});

	});
</script>
<style>
    .item-p, .sides-p, .addon-p, .variation-p, .topping-p {
        display: none;
    }
</style>
<script type="text/javascript">
	var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form ...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  // ... and fix the Previous/Next buttons:
  /*if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }*/
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  // ... and run a function that displays the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
 // if (n == 1 && !validateForm()) return false;
 
 //alert(currentTab);
 if(currentTab == 0 && !validateForMenuNameField()) return false;
 
 if(currentTab == 0) { selectMenu();}
 
 if(currentTab == 1) { selectItem(); }
 
 if(currentTab == 2) { selectSlide(); }
 
 if(currentTab == 3) { selectAddon(); }
 
 if(currentTab == 4) { selectVariation(); }
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form... :
  if (currentTab >= x.length) {
    //...the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function selectMenu() {
	var menuName = '';
	$.each($(".menu_name"), function(index){
		console.log(index);
		var menuString = $(this).val();
		var attrkey = $(this).attr('menukey');
		var value = menuString.replace(' ', '_');
	    menuName += '<option name="" value="'+value+'" attr-val="'+$(this).val()+'" attr-key="'+attrkey+'">'+$(this).val()+'</option>';

	    itemHtmlBasedOnMenu(menuString);
    });
    $('.menudetail-select').append(menuName);
}

function itemHtmlBasedOnMenu(menuString) {
	 $.ajax({
		type: 'POST',
		url: 'itemhtml',
		data: {"_token": "{{ csrf_token() }}", "menuName": menuString},
		beforeSend: function() {
		    $('.item-p').css('display','block');
		    $('.nextBtn').prop('disabled',true);
		},
		success: function(data) {
			$('.item-content').append(data);
		},
		complete: function(data) {
			var firstMenuName = $('#menudetail option:first').val();
   			itemMenuDivHideShow(firstMenuName);
   			$('.item-p').css('display','none');
   			$('.nextBtn').removeAttr('disabled');
		}
	});
}

function itemMenuDivHideShow(menuString) {
	$('.item-content-div-cls').hide();
	$('.menudetail-select option').each(function(){
	    if (this.value == menuString)  {
	    	$('#item_content_div_'+menuString).show();
	    }
	});
}

$('body').on('change', '#menudetail', function() {
	var menuNameVal = $(this).val();
	itemMenuDivHideShow(menuNameVal);
	//itemHtmlBasedOnMenu(menuNameVal);
});

function itemMenu(menuName) {
	var html = null;
	$.ajax({
		type: 'POST',
		url: 'itemhtml',
		data: {"_token": "{{ csrf_token() }}", "menuName": menuName},
		success: function(data) {
			html = data;
		}
	});
	return html;
}

function slideMenu(menuName) {
	var html = null;
	$.ajax({
		type: 'POST',
		url: 'slidehtml',
		data: {"_token": "{{ csrf_token() }}", "menuName": menuName},
		beforeSend: function() {
        	$('.sides-p').css('display','block');
        },
		success: function(data) {
			html = data;
		}
	});
	return html;
}

function selectItem()
{
    console.log('testest');
    var sideMenuName='';
	$('.item-content-div-cls').each(function() {
		var menuval = $(this).attr('attr-menu');
		var menuKey = $(this).attr('attr-menu-key');
		var menuvalAttr = menuval.replace('_', ' ');
		sideMenuName += '<option value="'+menuval+'" attr-val="'+menuval+'" attr-menu-key="'+menuKey+'">'+menuvalAttr+'</option>';
	});
    
    /* Start Custom slide */
	$('.customslide').html('<select class="customside-menu-dropdown aa form-control" id="customside_menu_dropdown">'+sideMenuName+'</select>');
	var firstMenuNameOfSide = $('#customside_menu_dropdown option:first').val();
	var firstMenuNameOfSideKey = $('#customside_menu_dropdown option:first').attr('attr-menu-key');
	/* End Custom slide */
	
	
	var countMenuItem = $("#item_content_div_"+firstMenuNameOfSide+" > div").length;
	var commonDivIdSide = 'item_content_div_'+firstMenuNameOfSide;
	
	var sideItemOption='';
	var itemExits='';
	if($('#'+commonDivIdSide).length > 0) {
	    
	    if($("#item_content_div_"+firstMenuNameOfSide+" > .item-content-div").length > 0) {
	        
	        $("#item_content_div_"+firstMenuNameOfSide+" > .item-content-div").each(function() {
    			var itemkey = $(this).attr('attr-item-key');
    			var itemMenuTxt = $(this).find('.menu_head').text();
    			var itemNameField = $('.itemnametext_'+itemMenuTxt+'_'+itemkey).val();
    			
    			var plusOneI = parseInt(itemkey) + parseInt(1);
    			sideItemOption += '<option value="'+itemkey+'">'+itemNameField+'</option>';
    		});
    		itemExits = true;
	    } else {
	        itemExits = false;
	    }
	} else {
		sideItemOption += '<option value="0">1</option>';
		itemExits = true;
	}
	
	if(itemExits == true) {
	    $('.customslide-item-select').html('<select class="customslide-item-dropdown bb form-control aa" id="customslide_item_dropdown">'+sideItemOption+'</select>');
	    
	    $('.customaddon-item-select').html('<select class="customaddon-item-dropdown bb form-control" id="customaddon_item_dropdown">'+sideItemOption+'</select>');
	} 
	
	$('.item-content-div-cls').each(function() {
		var menuName = $(this).attr('attr-menu');
		var menuNameAttr = menuName.replace('_', ' ');

		var menuKey = [];
		$("#item_content_div_"+menuName+" > .item-content-div").each(function() {
			var itemkey = $(this).attr('attr-item-key');
			menuKey.push(itemkey);
		});
		sideHtmlBasedOnMenuWithItem(menuName, menuKey);
	});

	var firstItemNameOfSide = $('#customslide_item_dropdown option:first').val();

	$('.item-sides-default-content').html('<label class="specific-sideitem-lb btn btn-danger pull-right" attr-menu="'+firstMenuNameOfSide+'" attr-item="'+firstItemNameOfSide+'" attr-menu-key="'+firstMenuNameOfSideKey+'">Add Sides</label>');
	
	if(itemExits == false) {
	    $('.customslide-item-select').hide();
	    $('.specific-sideitem-lb').hide();
	} else {
	    $('.customslide-item-select').show();
	    $('.specific-sideitem-lb').show();
	}
	sideMenuDivHideShow(firstMenuNameOfSide, firstItemNameOfSide);
}

function sideHtmlBasedOnMenuWithItem(menuName, itemName) {
	$.ajax({
		type: 'POST',
		url: 'slidehtml',
		data: {"_token": "{{ csrf_token() }}", "menuName": menuName, "itemName":itemName},
		beforeSend: function() {
        	$('.sides-p').css('display','block');
        	$('.nextBtn').prop('disabled',true);
        },
		success: function(data) {
			if(data != '') {
				$('.item-side-content').append(data);
			} else {
				$('.item-side-content').append('');
			}
		},
		complete: function(data) {
			var firstItemNameOfSide = $('#customslide_item_dropdown option:first').val();
			var firstMenuNameOfSide = $('#customside_menu_dropdown option:first').val();
			sideMenuDivHideShow(firstMenuNameOfSide, firstItemNameOfSide);
			$('.sides-p').css('display','none');
			$('.nextBtn').removeAttr('disabled');
		}
	});
}

function sideMenuDivHideShow(menuString, itemName) {
	$('.menu-side-content-div-cls').hide();
	$('.menu-item2-side-content-cls').hide();

	$('.customside-menu-dropdown option').each(function(){
		if (this.value == menuString)  {
			$('#menu_side_content_div_'+menuString).show();
		}
	});

	$('#menu_item2_side_content_cls_'+menuString+'_'+itemName).show();
}

function selectSlide()
{
    var addonMenuName='';
	$('.item-content-div-cls').each(function() {
		var menuval = $(this).attr('attr-menu');
		var menuKey = $(this).attr('attr-menu-key');
		var menuvalAttr = menuval.replace('_', ' ');
		addonMenuName += '<option value="'+menuval+'" attr-val="'+menuval+'" attr-menu-key="'+menuKey+'">'+menuvalAttr+'</option>';
	});
	
    /* Start Custom Addon */
	$('.customaddon').html('<select class="customaddon-menu-dropdown aa form-control" id="customaddon_menu_dropdown">'+addonMenuName+'</select>');
	var firstMenuNameOfAddon = $('#customaddon_menu_dropdown option:first').val();
	var firstMenuNameOfAddonKey = $('#customaddon_menu_dropdown option:first').attr('attr-menu-key');
	/* Start Custom Addon */
	
	
	var countMenuItem = $("#item_content_div_"+firstMenuNameOfAddon+" > div").length;
	var commonDivIdAddon = 'item_content_div_'+firstMenuNameOfAddon;
	
	var addonItemOption='';
	var itemExits='';
	if($('#'+commonDivIdAddon).length > 0) {
	    
	    if($("#item_content_div_"+firstMenuNameOfAddon+" > .item-content-div").length > 0) {
	        
	        $("#item_content_div_"+firstMenuNameOfAddon+" > .item-content-div").each(function() {
    			var itemkey = $(this).attr('attr-item-key');
    			var itemMenuTxt = $(this).find('.menu_head').text();
                var itemNameField = $('.itemnametext_'+itemMenuTxt+'_'+itemkey).val();
                
    			var plusOneI = parseInt(itemkey) + parseInt(1);
    			addonItemOption += '<option value="'+itemkey+'">'+itemNameField+'</option>';
    		});
    		itemExits = true;
	    } else {
	        itemExits = false;
	    }
	} else {
		addonItemOption += '<option value="0">1</option>';
		itemExits = true;
	}
	
	if(itemExits == true) {
	    $('.customaddon-item-select').html('<select class="customaddon-item-dropdown bb form-control" id="customaddon_item_dropdown">'+addonItemOption+'</select>');
	} 
	
	$('.item-content-div-cls').each(function() {
		var menuName = $(this).attr('attr-menu');
		var menuNameAttr = menuName.replace('_', ' ');

		var menuKey = [];
		$("#item_content_div_"+menuName+" > .item-content-div").each(function() {
			var itemkey = $(this).attr('attr-item-key');
			menuKey.push(itemkey);
		});
		addonHtmlBasedOnMenuWithItem(menuName, menuKey);
	});

	var firstItemNameOfAddon = $('#customaddon_item_dropdown option:first').val();

	$('.item-addon-default-content').html('<label class="specific-addonitem-lb btn btn-danger pull-right" attr-menu="'+firstMenuNameOfAddon+'" attr-item="'+firstItemNameOfAddon+'" attr-menu-key="'+firstMenuNameOfAddonKey+'">Add Addon</label>');
	
	if(itemExits == false) {
	    $('.customaddon-item-select').hide();
	    $('.specific-addonitem-lb').hide();
	} else {
	    $('.customaddon-item-select').show();
	    $('.specific-addonitem-lb').show();
	}
	addonMenuDivHideShow(firstMenuNameOfAddon, firstItemNameOfAddon);
}

function addonHtmlBasedOnMenuWithItem(menuName, itemName) {
    $.ajax({
        type: 'POST',
		url: 'addonhtml',
		data: {"_token": "{{ csrf_token() }}", "menuName": menuName, "itemName":itemName},
		beforeSend: function() {
        	$('.addon-p').css('display','block');
        	$('.nextBtn').prop('disabled',true);
        },
        success: function(data) {
            if(data != '') {
				$('.item-addon-content').append(data);
			} else {
				$('.item-addon-content').append('');
			}
        },
        complete: function(data) {
            var firstItemNameOfAddon = $('#customaddon_item_dropdown option:first').val();
			var firstMenuNameOfAddon = $('#customaddon_menu_dropdown option:first').val();
			addonMenuDivHideShow(firstMenuNameOfAddon, firstItemNameOfAddon);
			$('.addon-p').css('display','none');
			$('.nextBtn').removeAttr('disabled');
        }
    });
}

function addonMenuDivHideShow(menuString, itemName) {
	$('.menu-addon-content-div-cls').hide();
	$('.menu-item2-addon-content-cls').hide();

	$('.customaddon-menu-dropdown option').each(function(){
		if (this.value == menuString)  {
			$('#menu_addon_content_div_'+menuString).show();
		}
	});

	$('#menu_item2_addon_content_cls_'+menuString+'_'+itemName).show();
}

function selectAddon()
{
    var variationMenuName='';
	$('.item-content-div-cls').each(function() {
		var menuval = $(this).attr('attr-menu');
		var menuKey = $(this).attr('attr-menu-key');
		var menuvalAttr = menuval.replace('_', ' ');
		variationMenuName += '<option value="'+menuval+'" attr-val="'+menuval+'" attr-menu-key="'+menuKey+'">'+menuvalAttr+'</option>';
	});
	
	/* Start Custom Variation */
	$('.customvariation').html('<select class="customvariation-menu-dropdown aa form-control" id="customvariation_menu_dropdown">'+variationMenuName+'</select>');
	var firstMenuNameOfVariation = $('#customvariation_menu_dropdown option:first').val();
	var firstMenuNameOfVariationKey = $('#customvariation_menu_dropdown option:first').attr('attr-menu-key');
	/* Start Custom Variation */
	
	
    var countMenuItem = $("#item_content_div_"+firstMenuNameOfVariation+" > div").length;
	var commonDivIdVariation = 'item_content_div_'+firstMenuNameOfVariation;
	
	var variationItemOption='';
	var itemExits='';
	if($('#'+commonDivIdVariation).length > 0) {
	    
	    if($("#item_content_div_"+firstMenuNameOfVariation+" > .item-content-div").length > 0) {
	        
	        $("#item_content_div_"+firstMenuNameOfVariation+" > .item-content-div").each(function() {
    			var itemkey = $(this).attr('attr-item-key');
    			var itemMenuTxt = $(this).find('.menu_head').text();
                var itemNameField = $('.itemnametext_'+itemMenuTxt+'_'+itemkey).val();

    			var plusOneI = parseInt(itemkey) + parseInt(1);
    			variationItemOption += '<option value="'+itemkey+'">'+itemNameField+'</option>';
    		});
    		itemExits = true;
	    } else {
	        itemExits = false;
	    }
	} else {
		variationItemOption += '<option value="0">1</option>';
		itemExits = true;
	}

    if(itemExits == true) {
	    $('.customvariation-item-select').html('<select class="customvariation-item-dropdown bb form-control" id="customvariation_item_dropdown">'+variationItemOption+'</select>');
	} 
	
	$('.item-content-div-cls').each(function() {
		var menuName = $(this).attr('attr-menu');
		var menuNameAttr = menuName.replace('_', ' ');

		var menuKey = [];
		$("#item_content_div_"+menuName+" > .item-content-div").each(function() {
			var itemkey = $(this).attr('attr-item-key');
			menuKey.push(itemkey);
		});
		variationHtmlBasedOnMenuWithItem(menuName, menuKey);
	});

	var firstItemNameOfVariation = $('#customvariation_item_dropdown option:first').val();

	$('.item-variation-default-content').html('<label class="specific-variationitem-lb btn btn-danger pull-right" attr-menu="'+firstMenuNameOfVariation+'" attr-item="'+firstItemNameOfVariation+'" attr-menu-key="'+firstMenuNameOfVariationKey+'">Add Variation</label>');
	
	if(itemExits == false) {
	    $('.customvariation-item-select').hide();
	    $('.specific-variationitem-lb').hide();
	} else {
	    $('.customvariation-item-select').show();
	    $('.specific-variationitem-lb').show();
	}
	variationMenuDivHideShow(firstMenuNameOfVariation, firstItemNameOfVariation);
}

function variationHtmlBasedOnMenuWithItem(menuName, itemName) {
    $.ajax({
        type: 'POST',
		url: 'variationhtml',
		data: {"_token": "{{ csrf_token() }}", "menuName": menuName, "itemName":itemName},
		beforeSend: function() {
        	$('.variation-p').css('display','block');
        	$('.nextBtn').prop('disabled',true);
        },
        success: function(data) {
            if(data != '') {
				$('.item-variation-content').append(data);
			} else {
				$('.item-variation-content').append('');
			}
        },
        complete: function(data) {
            var firstItemNameOfVariation = $('#customvariation_item_dropdown option:first').val();
			var firstMenuNameOfVariation = $('#customvariation_menu_dropdown option:first').val();
			variationMenuDivHideShow(firstMenuNameOfVariation, firstItemNameOfVariation);
			$('.variation-p').css('display','none');
			$('.nextBtn').removeAttr('disabled');
        }
    });
}

function variationMenuDivHideShow(menuString, itemName) {
	$('.menu-variation-content-div-cls').hide();
	$('.menu-item2-variation-content-cls').hide();

	$('.customvariation-menu-dropdown option').each(function(){
		if (this.value == menuString)  {
			$('#menu_variation_content_div_'+menuString).show();
		}
	});

	$('#menu_item2_variation_content_cls_'+menuString+'_'+itemName).show();
}

function selectVariation()
{
   var toppingMenuName='';
	$('.item-content-div-cls').each(function() {
		var menuval = $(this).attr('attr-menu');
		var menuKey = $(this).attr('attr-menu-key');
		var menuvalAttr = menuval.replace('_', ' ');
		toppingMenuName += '<option value="'+menuval+'" attr-val="'+menuval+'" attr-menu-key="'+menuKey+'">'+menuvalAttr+'</option>';
	});
	
	/* Start Custom Topping */
	$('.customtopping').html('<select class="customtopping-menu-dropdown aa form-control" id="customtopping_menu_dropdown">'+toppingMenuName+'</select>');
	var firstMenuNameOfTopping = $('#customtopping_menu_dropdown option:first').val();
	var firstMenuNameOfToppingKey = $('#customtopping_menu_dropdown option:first').attr('attr-menu-key');
	/* Start Custom Topping */
	
	
    var countMenuItem = $("#item_content_div_"+firstMenuNameOfTopping+" > div").length;
	var commonDivIdTopping = 'item_content_div_'+firstMenuNameOfTopping;
	
	var toppingItemOption='';
	var itemExits='';
	if($('#'+commonDivIdTopping).length > 0) {
	    
	    if($("#item_content_div_"+firstMenuNameOfTopping+" > .item-content-div").length > 0) {
	        
	        $("#item_content_div_"+firstMenuNameOfTopping+" > .item-content-div").each(function() {
    			var itemkey = $(this).attr('attr-item-key');
    			var itemMenuTxt = $(this).find('.menu_head').text();
                var itemNameField = $('.itemnametext_'+itemMenuTxt+'_'+itemkey).val();

    			var plusOneI = parseInt(itemkey) + parseInt(1);
    			toppingItemOption += '<option value="'+itemkey+'">'+itemNameField+'</option>';
    		});
    		itemExits = true;
	    } else {
	        itemExits = false;
	    }
	} else {
		toppingItemOption += '<option value="0">1</option>';
		itemExits = true;
	}

    if(itemExits == true) {
	    $('.customtopping-item-select').html('<select class="customtopping-item-dropdown bb form-control" id="customtopping_item_dropdown">'+toppingItemOption+'</select>');
	} 
	
	$('.item-content-div-cls').each(function() {
		var menuName = $(this).attr('attr-menu');
		var menuNameAttr = menuName.replace('_', ' ');

		var menuKey = [];
		$("#item_content_div_"+menuName+" > .item-content-div").each(function() {
			var itemkey = $(this).attr('attr-item-key');
			menuKey.push(itemkey);
		});
		toppingHtmlBasedOnMenuWithItem(menuName, menuKey);
	});

	var firstItemNameOfTopping = $('#customtopping_item_dropdown option:first').val();

	$('.item-topping-default-content').html('<label class="specific-toppingitem-lb btn btn-danger pull-right" attr-menu="'+firstMenuNameOfTopping+'" attr-item="'+firstItemNameOfTopping+'" attr-menu-key="'+firstMenuNameOfToppingKey+'">Add Topping</label>');
	
	if(itemExits == false) {
	    $('.customtopping-item-select').hide();
	    $('.specific-toppingitem-lb').hide();
	} else {
	    $('.customtopping-item-select').show();
	    $('.specific-toppingitem-lb').show();
	}
	toppingMenuDivHideShow(firstMenuNameOfTopping, firstItemNameOfTopping); 
}

function toppingHtmlBasedOnMenuWithItem(menuName, itemName) {
    $.ajax({
        type: 'POST',
		url: 'toppinghtml',
		data: {"_token": "{{ csrf_token() }}", "menuName": menuName, "itemName":itemName},
		beforeSend: function() {
        	$('.topping-p').css('display','block');
        	$('.nextBtn').prop('disabled',true);
        },
        success: function(data) {
            if(data != '') {
				$('.item-topping-content').append(data);
			} else {
				$('.item-topping-content').append('');
			}
        },
        complete: function(data) {
            var firstItemNameOfTopping = $('#customtopping_item_dropdown option:first').val();
			var firstMenuNameOfTopping = $('#customtopping_menu_dropdown option:first').val();
		    toppingMenuDivHideShow(firstMenuNameOfTopping, firstItemNameOfTopping);
			$('.topping-p').css('display','none');
			$('.nextBtn').removeAttr('disabled');
        }
    });
}

function toppingMenuDivHideShow(menuString, itemName) {
	$('.menu-topping-content-div-cls').hide();
	$('.menu-item2-topping-content-cls').hide();

	$('.customtopping-menu-dropdown option').each(function(){
		if (this.value == menuString)  {
			$('#menu_topping_content_div_'+menuString).show();
		}
	});

	$('#menu_item2_topping_content_cls_'+menuString+'_'+itemName).show();
}


$('body').on('change', '.customside-menu-dropdown', function() {
	var sideMenu = $(this).val();
	var sideMenuKey = $('.customside-menu-dropdown option:selected').attr('attr-menu-key');
    
    var commonDivIdSide = 'item_content_div_'+sideMenu;
    
	var sideItemOption='';
	var itemExits='';
	if($('#'+commonDivIdSide).length > 0) {
	    if($("#item_content_div_"+sideMenu+" > .item-content-div").length > 0) {
	        
	        $("#item_content_div_"+sideMenu+" > .item-content-div").each(function() {
        		var itemkey = $(this).attr('attr-item-key');
        		var itemMenuTxt = $(this).find('.menu_head').text();
        		var itemNameField = $('.itemnametext_'+itemMenuTxt+'_'+itemkey).val();
        		
        		var plusOneI = parseInt(itemkey) + parseInt(1);
        		sideItemOption += '<option value="'+itemkey+'">'+itemNameField+'</option>';
        	});
	        itemExits = true;
	    } else {
	        itemExits = false;
	    }
	} else {
	    sideItemOption += '<option value="0">1</option>';
	    itemExits = true;
	}

	$('.customslide-item-select').html('');
	$('.customslide-item-select').append('<select class="customslide-item-dropdown cc form-control" id="customslide_item_dropdown">'+sideItemOption+'</select>');

	var firstItemNameOfSide = $('#customslide_item_dropdown').val();
	sideMenuDivHideShow(sideMenu, firstItemNameOfSide);
	$('.specific-sideitem-lb').attr('attr-menu', sideMenu).attr('attr-item', firstItemNameOfSide).attr('attr-menu-key', sideMenuKey);
	
	console.log(itemExits);
	if(itemExits == false) {
	    $('.customslide-item-select').hide();
	    $('.specific-sideitem-lb').hide();
	} else {
	    $('.customslide-item-select').show();
	    $('.specific-sideitem-lb').show();
	}
});


$('body').on('change', '.customslide-item-dropdown', function() {
	var itemSide = $(this).val();
	var menuSide = $('.customside-menu-dropdown').val();
	var menukey = $('.customside-menu-dropdown option:selected').attr('attr-menu-key');
	console.log(menuSide+'===='+itemSide);
	sideMenuDivHideShow(menuSide, itemSide);

	$('.specific-sideitem-lb').attr('attr-menu', menuSide).attr('attr-item', itemSide).attr('attr-menu-key', menukey);
});


$('body').on('change', '.customaddon-menu-dropdown', function() {
	var addonMenu = $(this).val();
	var addonMenuKey = $('.customaddon-menu-dropdown option:selected').attr('attr-menu-key');
    
    var commonDivIdAddon = 'item_content_div_'+addonMenu;
    
	var addonItemOption='';
	var itemExits='';
	if($('#'+commonDivIdAddon).length > 0) {
	    if($("#item_content_div_"+addonMenu+" > .item-content-div").length > 0) {
	        $("#item_content_div_"+addonMenu+" > .item-content-div").each(function() {
        		var itemkey = $(this).attr('attr-item-key');
        		var itemMenuTxt = $(this).find('.menu_head').text();
                var itemNameField = $('.itemnametext_'+itemMenuTxt+'_'+itemkey).val();

        		var plusOneI = parseInt(itemkey) + parseInt(1);
        		addonItemOption += '<option value="'+itemkey+'">'+itemNameField+'</option>';
        	});
	        itemExits = true;
	    } else {
	        itemExits = false;
	    }
	} else {
	    addonItemOption += '<option value="0">1</option>';
	    itemExits = true;
	}

	$('.customaddon-item-select').html('');
	$('.customaddon-item-select').append('<select class="customaddon-item-dropdown cc form-control" id="customaddon_item_dropdown">'+addonItemOption+'</select>');

	var firstItemNameOfAddon = $('#customaddon_item_dropdown').val();
	addonMenuDivHideShow(addonMenu, firstItemNameOfAddon);
	$('.specific-addonitem-lb').attr('attr-menu', addonMenu).attr('attr-item', firstItemNameOfAddon).attr('attr-menu-key', addonMenuKey);
	
	if(itemExits == false) {
	    $('.customaddon-item-select').hide();
	    $('.specific-addonitem-lb').hide();
	} else {
	    $('.customaddon-item-select').show();
	    $('.specific-addonitem-lb').show();
	}
});


$('body').on('change', '.customaddon-item-dropdown', function() {
	var itemAddon = $(this).val();
	var menuAddon = $('.customaddon-menu-dropdown').val();
	var menukey = $('.customaddon-menu-dropdown option:selected').attr('attr-menu-key');
	//console.log(menuSide+'===='+itemSide);
	addonMenuDivHideShow(menuAddon, itemAddon);

	$('.specific-addonitem-lb').attr('attr-menu', menuAddon).attr('attr-item', itemAddon).attr('attr-menu-key', menukey);
});


$('body').on('change', '.customvariation-menu-dropdown', function() {
	var variationMenu = $(this).val();
	var variationMenuKey = $('.customvariation-menu-dropdown option:selected').attr('attr-menu-key');
    
    var commonDivIdVariation = 'item_content_div_'+variationMenu;
    
	var variationItemOption='';
	var itemExits='';
	if($('#'+commonDivIdVariation).length > 0) {
	    if($("#item_content_div_"+variationMenu+" > .item-content-div").length > 0) {
	        $("#item_content_div_"+variationMenu+" > .item-content-div").each(function() {
        		var itemkey = $(this).attr('attr-item-key');
        		var itemMenuTxt = $(this).find('.menu_head').text();
                var itemNameField = $('.itemnametext_'+itemMenuTxt+'_'+itemkey).val();

        		var plusOneI = parseInt(itemkey) + parseInt(1);
        		variationItemOption += '<option value="'+itemkey+'">'+itemNameField+'</option>';
        	});
	        itemExits = true;
	    } else {
	        itemExits = false;
	    }
	} else {
	    variationItemOption += '<option value="0">1</option>';
	    itemExits = true;
	}

	$('.customvariation-item-select').html('');
	$('.customvariation-item-select').append('<select class="customvariation-item-dropdown cc form-control" id="customvariation_item_dropdown">'+variationItemOption+'</select>');

	var firstItemNameOfVariation = $('#customvariation_item_dropdown').val();
	variationMenuDivHideShow(variationMenu, firstItemNameOfVariation);
	$('.specific-variationitem-lb').attr('attr-menu', variationMenu).attr('attr-item', firstItemNameOfVariation).attr('attr-menu-key', variationMenuKey);
	
	if(itemExits == false) {
	    $('.customvariation-item-select').hide();
	    $('.specific-variationitem-lb').hide();
	} else {
	    $('.customvariation-item-select').show();
	    $('.specific-variationitem-lb').show();
	}
});


$('body').on('change', '.customvariation-item-dropdown', function() {
	var itemVariation = $(this).val();
	var menuVariation = $('.customvariation-menu-dropdown').val();
	var menukey = $('.customvariation-menu-dropdown option:selected').attr('attr-menu-key');
	//console.log(menuSide+'===='+itemSide);
	variationMenuDivHideShow(menuVariation, itemVariation);

	$('.specific-variationitem-lb').attr('attr-menu', menuVariation).attr('attr-item', itemVariation).attr('attr-menu-key', menukey);
});


$('body').on('change', '.customtopping-menu-dropdown', function() {
	var toppingMenu = $(this).val();
	var toppingMenuKey = $('.customtopping-menu-dropdown option:selected').attr('attr-menu-key');
    
    var commonDivIdTopping = 'item_content_div_'+toppingMenu;
    
	var toppingItemOption='';
	var itemExits='';
	if($('#'+commonDivIdTopping).length > 0) {
	    if($("#item_content_div_"+toppingMenu+" > .item-content-div").length > 0) {
	        $("#item_content_div_"+toppingMenu+" > .item-content-div").each(function() {
        		var itemkey = $(this).attr('attr-item-key');
        		var itemMenuTxt = $(this).find('.menu_head').text();
                var itemNameField = $('.itemnametext_'+itemMenuTxt+'_'+itemkey).val();

        		var plusOneI = parseInt(itemkey) + parseInt(1);
        		toppingItemOption += '<option value="'+itemkey+'">'+itemNameField+'</option>';
        	});
	        itemExits = true;
	    } else {
	        itemExits = false;
	    }
	} else {
	    toppingItemOption += '<option value="0">1</option>';
	    itemExits = true;
	}

	$('.customtopping-item-select').html('');
	$('.customtopping-item-select').append('<select class="customtopping-item-dropdown cc form-control" id="customtopping_item_dropdown">'+toppingItemOption+'</select>');

	var firstItemNameOfTopping = $('#customtopping_item_dropdown').val();
	toppingMenuDivHideShow(toppingMenu, firstItemNameOfTopping);
	$('.specific-toppingitem-lb').attr('attr-menu', toppingMenu).attr('attr-item', firstItemNameOfTopping).attr('attr-menu-key', toppingMenuKey);
	
	if(itemExits == false) {
	    $('.customtopping-item-select').hide();
	    $('.specific-toppingitem-lb').hide();
	} else {
	    $('.customtopping-item-select').show();
	    $('.specific-toppingitem-lb').show();
	}
});


$('body').on('change', '.customtopping-item-dropdown', function() {
	var itemTopping = $(this).val();
	var menuTopping = $('.customtopping-menu-dropdown').val();
	var menukey = $('.customtopping-menu-dropdown option:selected').attr('attr-menu-key');
	//console.log(menuSide+'===='+itemSide);
	toppingMenuDivHideShow(menuTopping, itemTopping);

	$('.specific-toppingitem-lb').attr('attr-menu', menuTopping).attr('attr-item', itemTopping).attr('attr-menu-key', menukey);
});


function validateForMenuNameField() {
	var valid = true;
	$('.menu_name').each(function() {
		var textval = $(this).val();
		var menuKey = $(this).attr('attr-key');
		var menuID = $(this).attr('id');
		var regex = /^[a-zA-Z ]*$/;
		if(textval == '') {
			$('#nextBtn').attr('disabled','disabled');
			$('#menu-name-error-'+menuKey).text('Please enter menu name');
			/*$('#'+menuID).after("<p style='color: red;'>Please enter menu name</p>");*/
			valid = false;
		} else if(!regex.test(textval)) {
			$('#nextBtn').attr('disabled','disabled');
			$('#menu-name-error-'+menuKey).text('Please enter alphabates');
			/*$('#'+menuID).after("<p style='color: red;'>Please enter alphabates</p>");*/
			valid = false;
		} else {
			$('#nextBtn').removeAttr('disabled');
			$('#menu-name-error-'+menuKey).text('');
			valid = true;
		}
	});

	if(!valid) {
		$('#nextBtn').attr('disabled','');
	}
	return valid;
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false:
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class to the current step:
  x[n].className += " active";
}
</script>
<script type="text/javascript">
	$(document).on('click','.switch_btn',function(argument) {
		$(this).prev('input').trigger('click');
	})
</script>

<script type="text/javascript">
  $('.start_time').timepicker();
  $('.end_time').timepicker();
  
  function menuTime() {
      $('.start_time').timepicker();
      $('.end_time').timepicker();
  }
</script>

@endpush
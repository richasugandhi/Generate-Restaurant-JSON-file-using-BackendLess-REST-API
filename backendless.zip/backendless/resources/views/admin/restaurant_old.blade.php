@extends('after.admin.layout')

@section('content')

<!-- /.register-box -->
<section class="content">
	<div class="row">
		 <div class="col-md-12">
		 	<div class="box-header with-border">
				<h3 class="box-title">Add Restaurant</h3>
			</div>
			<form class="form-horizontal" method="POST" id="regForm" action="{{ route('admin.submitrestaurant') }}" enctype="multipart/form-data">
  {{ csrf_field() }}
<h1>Resturant Menus:</h1>

<!-- One "tab" for each step in the form: -->
<div class="tab" id="tab1">Menu Details:
  <div class='row menudetails-default-content'>
  	<input type="hidden" name="hide_menu_id" class="hide_menu_id" />

  	<div class="menudetailsform" id="menudetailsform_0">
  		<div class='col-md-3 main-menu-dropdown-div'>
  			<label for="" class="menu_name_lb_name">Select Name</label>
  			<input type="text" class="menu_name" name='menu_name[0]' id='menu-name-0'>
  			<!--<select class="menu_name" name='menu_name[0]' id='menu-name-0'>
  				<option value="0" attr-val="Lunch & Dinner Menu">Lunch & Dinner Menu</option>
  				<option value="1" attr-val="Desserts Menu">Desserts Menu</option>
  				<option value="2" attr-val="Kids Menu">Kids Menu</option>
  			</select>-->
		</div>
		<div class='col-md-3'>
			<label for="" class="menu_image_lb_name">Upload Menu Image</label>
			<input type="file" class="menu_image" name="menu_image[0]" id='menu-image-0'>
		</div>
		<div class='col-md-3'>
			<label for="" class="">Time</label>
			<input type="text" name="start_time[0]" placeholder='Start Time' />
			<input type="text" name="end_time[0]" placeholder='End Time' />
		</div>
		<div class='col-md-3'>
			<label for="" class="menu_name_lb_day">Select Day</label>
  			<input type="checkbox" name='day[0][]' value="1" attr-val="Monday" />Monday
  			<input type="checkbox" name='day[0][]' value="2" attr-val="Tuesday" />Tuesday
  			<input type="checkbox" name='day[0][]' value="3" attr-val="Wenesday" />Wenesday
  			<input type="checkbox" name='day[0][]' value="4" attr-val="Thuresday" />Thuresday
  			<input type="checkbox" name='day[0][]' value="5" attr-val="Friday" />Friday
			<input type="checkbox" name='day[0][]' value="6" attr-val="Saturday" />Saturday
			<input type="checkbox" name='day[0][]' value="7" attr-val="sunday" />Sunday
		</div>
  	</div>
  </div>
	<div class="menudetails-content"></div>
	<label class="menudetails">Add More</label>
</div>

<div class="tab">Item Details:
	<div class="selectmenudetail-div">
		<label class="label-menudetail">Menu Name</label>
		<select name="item_menudetail[]" class="menudetail-select" id="menudetail">
			
		</select>
	    <label class="menuitem">Add Item</label>
	</div>
  <div class='row item-default-content'>
  </div>
	<div class="item-content"></div>
</div>

<div class="tab">Sides:
	<div class="customslide"></div>
	<div class='row item-sides-default-content'>
	</div>
	<div class="item-side-content"></div>
</div>

<div class="tab">Addons:
	<div class="customaddon"></div>
	<div class='row addon-sides-default-content'>
	</div>
	<div class="item-addon-content"></div>
</div>

<div class="tab">Variations:
	<div class="customvariations"></div>
  <div class='row variation-sides-default-content'>
	</div>
	<div class="item-variation-content"></div>
</div>

<div class="tab">Topping:
	<div class="customtopping"></div>
	<div class="item-topping-content"></div>
</div>

<div style="overflow:auto;float:left;">
  <div style="float:right;">
    <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
    <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
  </div>
</div>

<!-- Circles which indicates the steps of the form: -->
<div style="text-align:center;margin-top:40px;">
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
  <span class="step"></span>
</div>

</form>
		 </div>
	</div>	
</section>
@endsection

@push('scripts')
<script type="text/javascript">
	$(document).ready(function() {
		$('.menudetails').click(function() {

			var menuId = [];
			$('.menu_name').each(function(){
				var id = $(this).attr('id');
				menuId.push($("#"+id).val());
			});


			var optionList ='';
			var countId = 0;
			$('.menudetailsform > .main-menu-dropdown-div > .menu_name').each(function() {
			    var val = $(this).val();
				optionList += '<option value="'+this.value+'" attr-val="'+val+'">'+val+'</option>';
			   	 countId++;

			  /*if($.inArray(this.value, menuId) >-1){
			      
			   } else{
			   	var attrval = $(this).attr('attr-val');
			   	optionList += '<option value="'+this.value+'" attr-val="'+attrval+'">'+attrval+'</option>';
			   	 countId++;
			   }*/
			});

			/*if(countId == 1) {
				$('.menudetails').hide();
			}*/
			
			

			var menudetails = '';
			var numdiv = $('.menudetailsform').length;
			if(numdiv > 1) {
				var num = numdiv; 
				var menuHtml = "<div class='menudetailsform' id='menudetailsform_"+num+"'><div class='col-md-3'><label class='menu_name_lb_name'>Select Name</label><input type='text' name='menu_name["+num+"]' class='menu_name' id='menu-name-"+num+"' /></div><div class='col-md-3'><label class='menu_image_lb_name'>Upload Menu Image</label><input type='file' class='menu_image' name='menu_image["+num+"]' id='menu-image-"+num+"'></div><div class='col-md-3'><label class=''>Time</label><input type='text' name='start_time["+num+"]' placeholder='Start Time' /><input type='text' name='end_time["+num+"]' placeholder='End Time' /></div><div class='col-md-3'><label class='menu_name-lb-day'>Select Day</label><input type='checkbox' name='day["+num+"][]' value='1' attr-val='Monday' />Monday<input type='checkbox' name='day["+num+"][]' value='2' attr-val='Tuesday' />Tuesday<input type='checkbox' name='day["+num+"][]' value='3' attr-val='Wenesday' />Wenesday<input type='checkbox' name='day["+num+"][]' value='4' attr-val='Thuresday' />Thuresday<input type='checkbox' name='day["+num+"][]' value='5' attr-val='Friday' />Friday<input type='checkbox' name='day["+num+"][]' value='6' attr-val='Saturday' />Saturday<input type='checkbox' name='day["+num+"][]' value='7' attr-val='sunday' />Sunday</div></div>";
			} else {
				var menuHtml = "<div class='menudetailsform' id='menudetailsform_1'><div class='col-md-3'><label class='menu_name_lb_name'>Select Name</label><input type='text' name='menu_name[1]' class='menu_name' id='menu-name-1' /></div><div class='col-md-3'><label class='menu_image_lb_name'>Upload Menu Image</label><input type='file' class='menu_image' name='menu_image[1]' id='menu-image-1'></div><div class='col-md-3'><label class=''>Time</label><input type='text' name='start_time[1]' placeholder='Start Time' /><input type='text' name='end_time[1]' placeholder='End Time' /></div><div class='col-md-3'><label class='menu_name-lb-day'>Select Day</label><input type='checkbox' name='day[1][]' value='1' attr-val='Monday' />Monday<input type='checkbox' name='day[1][]' value='2' attr-val='Tuesday' />Tuesday<input type='checkbox' name='day[1][]' value='3' attr-val='Wenesday' />Wenesday<input type='checkbox' name='day[1][]' value='4' attr-val='Thuresday' />Thuresday<input type='checkbox' name='day[1][]' value='5' attr-val='Friday' />Friday<input type='checkbox' name='day[1][]' value='6' attr-val='Saturday' />Saturday<input type='checkbox' name='day[1][]' value='7' attr-val='sunday' />Sunday</div></div>";
			}
			$('.menudetails-content').append(menuHtml);
		});

		$('.menuitem').click(function() {
			var menuName = $('.menudetail-select').val();
			var menuAttr = $('.menudetail-select option:selected').attr('attr-val');
			var menuHtml = "<h5>"+menuName+"</h5><div attrItemcount='"+menuName+"' class='itemform itemform_"+menuName+"' id='itemform_"+menuName+"'><div class='col-md-3'><input type='text' class='form-control name' name='name["+menuName+"][]' id='name' placeholder='name'></div><div class='col-md-3'><input type='text' class='form-control' name='category["+menuName+"][]' id='category' placeholder='category'></div><div class='col-md-3'><input type='text' class='form-control' name='price["+menuName+"][]' id='price' placeholder='price'></div><div class='col-md-3'><select class='form-control' name='gluten_free["+menuName+"][]' id='gluten_free'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='kosher["+menuName+"][]' id='kosher'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='halal["+menuName+"][]' id='halal'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='vegan["+menuName+"][]' id='vegan'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='vegetarian["+menuName+"][]' id='vegetarian'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='spicy["+menuName+"][]' id='spicy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='ocean_wise["+menuName+"][]' id='ocean_wise'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='msg["+menuName+"][]' id='msg'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='corn["+menuName+"][]' id='corn'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='peanuts["+menuName+"][]' id='peanuts'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='treenuts["+menuName+"][]' id='treenuts'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='sulfites["+menuName+"][]' id='sulfites'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='mustard["+menuName+"][]' id='mustard'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='wheat["+menuName+"][]' id='wheat'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='soy["+menuName+"][]' id='soy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='seafood["+menuName+"][]' id='seafood'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='garlic["+menuName+"][]' id='garlic'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='eggs["+menuName+"][]' id='eggs'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='tartrazine["+menuName+"][]' id='tartrazine'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='onions["+menuName+"][]' id='onions'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='animal_fats_oils["+menuName+"][]' id='animal_fats_oils'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='shellfish["+menuName+"][]' id='shellfish'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='fish["+menuName+"][]' id='fish'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='sesama["+menuName+"][]' id='sesama'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='dairy["+menuName+"][]' id='dairy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><input type='text' class='form-control' name='saturated_fats["+menuName+"][]' id='saturated_fats' placeholder='saturated_fats'></div><div class='col-md-3'><input type='text' class='form-control' name='vitamin_a["+menuName+"][]' id='vitamin_a' placeholder='vitamin_a'></div><div class='col-md-3'><input type='text' class='form-control' name='carbs["+menuName+"][]' id='carbs' placeholder='carbs'></div><div class='col-md-3'><input type='text' class='form-control' name='vitamin_c["+menuName+"][]' id='vitamin_c' placeholder='vitamin_c'></div><div class='col-md-3'><input type='text' class='form-control' name='protein["+menuName+"][]' id='protein' placeholder='protein'></div><div class='col-md-3'><input type='text' class='form-control' name='fat["+menuName+"][]' id='fat' placeholder='fat'></div><div class='col-md-3'><input type='text' class='form-control' name='cholesterol["+menuName+"][]' id='cholesterol' placeholder='cholesterol'></div><div class='col-md-3'><input type='text' class='form-control' name='fiber["+menuName+"][]' id='fiber' placeholder='fiber'></div><div class='col-md-3'><input type='text' class='form-control' name='protein["+menuName+"][]' id='protein' placeholder='protein'></div><div class='col-md-3'><input type='text' class='form-control' name='calcium["+menuName+"][]' id='calcium' placeholder='calcium'></div><div class='col-md-3'><input type='text' class='form-control' name='calories["+menuName+"][]' id='calories' placeholder='calories'></div><div class='col-md-3'><input type='text' class='form-control' name='sodium["+menuName+"][]' id='sodium' placeholder='sodium'></div><div class='col-md-3'><input type='text' class='form-control' name='trans_fat["+menuName+"][]' id='trans_fat' placeholder='trans_fat'></div><div class='col-md-3'><input type='text' class='form-control' name='iron["+menuName+"][]' id='iron' placeholder='iron'></div><div class='col-md-3'><input type='text' class='form-control' name='sugar["+menuName+"][]' id='sugar' placeholder='sugar'></div></div></hr></br>";

			$('.item-content').append(menuHtml);


			var numdiv = $('.itemform_'+menuName).length;

			var IsExistsOpt = false;
			var itemoption;
			for(var i = 0; i<numdiv; i++) {
				var opval = i+1;

				$('#itemopt_'+menuName+' option').each(function(){
					var id = $(this).attr('id');
					if(id = 'itemopt_'+menuName) {
						if($('#itemopt_'+menuName).val() != 'undefined') {
							if ($('#itemopt_'+menuName).val() == i) {
							   IsExistsOpt = true;
							}
						}
					}


				});

				if(!IsExistsOpt) {
					itemoption += '<option value="'+i+'">'+opval+'</option>';
				}
				//console.log(itemoption);
			}


			var IsExists = false;
			$('.additemform').each(function(){
			    if ($(this).attr('id') == 'additemform_'+menuName) 
			        IsExists = true;   
			});
			if(!IsExists) {
				var customItemhtml = "<div class='additemform' id='additemform_"+menuName+"'><label id='side_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='itemopt' id='itemopt_"+menuName+"'></select><label class='specific-sideitem-lb' attrval="+menuName+">Add Sides</label><div class='slilde_content_"+menuName+"' id='slilde_content_"+menuName+"'></div></div>";
				$('.customslide').append(customItemhtml);


				var customAddonhtml = "<div class='addaddonform' id='addaddonform_"+menuName+"'><label id='addon_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='addonopt' id='addonopt_"+menuName+"'></select><label class='specific-addonitem-lb' attrval="+menuName+">Add Addon</label><div class='addon_content_"+menuName+"' id='addon_content_"+menuName+"'></div></div>";
				$('.customaddon').append(customAddonhtml);


				var customVariationhtml = "<div class='addvariationform' id='addvariationform_"+menuName+"'><label id='variation_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='variationopt' id='variationopt_"+menuName+"'></select><label class='specific-variationitem-lb' attrval="+menuName+">Add Variation</label><div class='variation_content_"+menuName+"' id='variation_content_"+menuName+"'></div></div>";
				$('.customvariations').append(customVariationhtml);

				var customToppinghtml = "<div class='addtoppingform' id='addtoppingform_"+menuName+"'><label id='topping_menu_lb_"+menuName+"'>"+menuAttr+"</label><select class='toppingopt' id='toppingopt_"+menuName+"'></select><label class='specific-toppingitem-lb' attrval="+menuName+">Add Topping</label><div class='topping_content_"+menuName+"' id='topping_content_"+menuName+"'></div></div>";
				$('.customtopping').append(customToppinghtml);

			} else {
				$('#additemform_'+menuName).find('.itemopt').append(itemoption)
			}


			var t;
			var r = $('.itemform_'+menuName).length;
			for(var d = 0; d<r; d++) {
				var o = d+1;
				   t += '<option value="'+d+'">'+o+'</option>';
			}
			$('#itemopt_'+menuName).append(t);
			$('#addonopt_'+menuName).append(t);
			$('#variationopt_'+menuName).append(t);
			$('#toppingopt_'+menuName).append(t);


			var optionValues =[];
			$('#itemopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValues) >-1){
			      $(this).remove()
			   }else{
			      optionValues.push(this.value);
			   }
			});

			var optionValuesA =[];
			$('#addonopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValuesA) >-1){
			      $(this).remove()
			   }else{
			      optionValuesA.push(this.value);
			   }
			});

			var optionValuesV =[];
			$('#variationopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValuesV) >-1){
			      $(this).remove()
			   }else{
			      optionValuesV.push(this.value);
			   }
			});

			
			var optionValuesT =[];
			$('#toppingopt_'+menuName+' option').each(function(){
			   if($.inArray(this.value, optionValuesT) >-1){
			      $(this).remove()
			   }else{
			      optionValuesT.push(this.value);
			   }
			});

			/*var IsExists = false;
			$('.common-menudetail-select option').each(function(){
			    if (this.value == menuName) 
			        IsExists = true;   
			});
			if(!IsExists) {
				$('.common-menudetail-select').append('<option name="" value="'+menuName+'" attr-val="'+menuAttr+'">'+menuAttr+'</option>');
			}

			if(itemoption != 'undefined') {
				$('.commonitem').html('');
				$('.commonitem').append(itemoption);
			}*/
		});

		$('body').on('click', '.specific-sideitem-lb', function() {
			var menuId = $(this).attr('attrval');
			var itemId = $('#itemopt_'+menuId).val();
			var sidehtml = "<h5>Menu"+menuId+" AND Item "+itemId+"</h5><div class='sideform'><div class='col-md-3'><label class='side_standard'>standard</label><select class='form-control' name='side_standard["+menuId+"]["+itemId+"][]' id='standard'><option value='true'>true</option><option value='false'>false</option></select></div><div class='col-md-3'><input type='text' class='form-control name' name='side_name["+menuId+"]["+itemId+"][]' id='name' placeholder='name'></div><div class='col-md-3'><input type='text' class='form-control' name='side_category["+menuId+"]["+itemId+"][]' id='category' placeholder='category'></div><div class='col-md-3'><input type='text' class='form-control' name='side_price["+menuId+"]["+itemId+"][]' id='price' placeholder='price'></div><div class='col-md-3'><select class='form-control' name='side_gluten_free["+menuId+"]["+itemId+"][]' id='gluten_free'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_kosher["+menuId+"]["+itemId+"][]' id='kosher'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_halal["+menuId+"]["+itemId+"][]' id='halal'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_vegan["+menuId+"]["+itemId+"][]' id='vegan'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_vegetarian["+menuId+"]["+itemId+"][]' id='vegetarian'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_spicy["+menuId+"]["+itemId+"][]' id='spicy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_ocean_wise["+menuId+"]["+itemId+"][]' id='ocean_wise'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_msg["+menuId+"]["+itemId+"][]' id='msg'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_corn["+menuId+"]["+itemId+"][]' id='corn'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_peanuts["+menuId+"]["+itemId+"][]' id='peanuts'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_treenuts["+menuId+"]["+itemId+"][]' id='treenuts'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_sulfites["+menuId+"]["+itemId+"][]' id='sulfites'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_mustard["+menuId+"]["+itemId+"][]' id='mustard'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_wheat["+menuId+"]["+itemId+"][]' id='wheat'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_soy["+menuId+"]["+itemId+"][]' id='soy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_seafood["+menuId+"]["+itemId+"][]' id='seafood'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_garlic["+menuId+"]["+itemId+"][]' id='garlic'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_eggs["+menuId+"]["+itemId+"][]' id='eggs'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_tartrazine["+menuId+"]["+itemId+"][]' id='tartrazine'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_onions["+menuId+"]["+itemId+"][]' id='onions'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_animal_fats_oils["+menuId+"]["+itemId+"][]' id='animal_fats_oils'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_shellfish["+menuId+"]["+itemId+"][]' id='shellfish'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_fish["+menuId+"]["+itemId+"][]' id='fish'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_sesama["+menuId+"]["+itemId+"][]' id='sesama'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='side_dairy["+menuId+"]["+itemId+"][]' id='dairy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><input type='text' class='form-control' name='side_saturated_fats["+menuId+"]["+itemId+"][]' id='saturated_fats' placeholder='saturated_fats'></div><div class='col-md-3'><input type='text' class='form-control' name='side_vitamin_a["+menuId+"]["+itemId+"][]' id='vitamin_a' placeholder='vitamin_a'></div><div class='col-md-3'><input type='text' class='form-control' name='side_carbs["+menuId+"]["+itemId+"][]' id='carbs' placeholder='carbs'></div><div class='col-md-3'><input type='text' class='form-control' name='side_vitamin_c["+menuId+"]["+itemId+"][]' id='vitamin_c' placeholder='vitamin_c'></div><div class='col-md-3'><input type='text' class='form-control' name='side_protein["+menuId+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-3'><input type='text' class='form-control' name='side_fat["+menuId+"]["+itemId+"][]' id='fat' placeholder='fat'></div><div class='col-md-3'><input type='text' class='form-control' name='side_cholesterol["+menuId+"]["+itemId+"][]' id='cholesterol' placeholder='cholesterol'></div><div class='col-md-3'><input type='text' class='form-control' name='side_fiber["+menuId+"]["+itemId+"][]' id='fiber' placeholder='fiber'></div><div class='col-md-3'><input type='text' class='form-control' name='side_protein["+menuId+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-3'><input type='text' class='form-control' name='side_calcium["+menuId+"]["+itemId+"][]' id='calcium' placeholder='calcium'></div><div class='col-md-3'><input type='text' class='form-control' name='side_calories["+menuId+"]["+itemId+"][]' id='calories' placeholder='calories'></div><div class='col-md-3'><input type='text' class='form-control' name='side_sodium["+menuId+"]["+itemId+"][]' id='sodium' placeholder='sodium'></div><div class='col-md-3'><input type='text' class='form-control' name='side_trans_fat["+menuId+"]["+itemId+"][]' id='trans_fat' placeholder='trans_fat'></div><div class='col-md-3'><input type='text' class='form-control' name='side_iron["+menuId+"]["+itemId+"][]' id='iron' placeholder='iron'></div><div class='col-md-3'><input type='text' class='form-control' name='side_sugar["+menuId+"]["+itemId+"][]' id='sugar' placeholder='sugar'></div></div></hr></br>";

			$('.slilde_content_'+menuId).append(sidehtml);
		});


		/*$('.sideitem-lb').click(function() {
			var itemval = $('#sideitem').val();
			var menuId = $('#side-menudetail-select').val();
			alert(itemval);
			var sidehtml = "<div class='sideform'><div class='col-md-6'><label class='side_standard'>standard</label><select class='form-control' name='side_standard["+menuId+"]["+itemval+"][]' id='standard'><option value='true'>true</option><option value='false'>false</option></select></div><div class='col-md-6'><label class='side_corn'>Msg</label><select class='form-control' name='side_corn["+menuId+"]["+itemval+"][]' id='side_corn'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div></div>";
			$('.item-side-content').append(sidehtml);
		});*/

		/*$('.addonitem-lb').click(function() {
			var itemval = $('#addonitem').val();
			var menuId = $('#addon-menudetail-select').val();

			var addonhtml = "<div class='addonform'><div class='col-md-6'><input type='text' class='form-control' name='addon_name["+menuId+"]["+itemval+"][]' id='addon_name' placeholder='addon_name'></div><div class='col-md-6'><input type='text' class='form-control' name='addon_category["+menuId+"]["+itemval+"][]' id='addon_category' placeholder='addon_category'></div></div>";
			$('.item-addon-content').append(addonhtml);
		});*/



		$('body').on('click', '.specific-addonitem-lb', function() {
			var menuId = $(this).attr('attrval');
			var itemId = $('#addonopt_'+menuId).val();
			var addonhtml = "<h5>Menu"+menuId+" AND Item "+itemId+"</h5><div class='addonform'><div class='col-md-3'><input type='text' class='form-control name' name='addon_name["+menuId+"]["+itemId+"][]' id='name' placeholder='name'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_category["+menuId+"]["+itemId+"][]' id='category' placeholder='category'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_price["+menuId+"]["+itemId+"][]' id='price' placeholder='price'></div><div class='col-md-3'><select class='form-control' name='addon_gluten_free["+menuId+"]["+itemId+"][]' id='gluten_free'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_kosher["+menuId+"]["+itemId+"][]' id='kosher'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_halal["+menuId+"]["+itemId+"][]' id='halal'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_vegan["+menuId+"]["+itemId+"][]' id='vegan'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_vegetarian["+menuId+"]["+itemId+"][]' id='vegetarian'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_spicy["+menuId+"]["+itemId+"][]' id='spicy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_ocean_wise["+menuId+"]["+itemId+"][]' id='ocean_wise'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_msg["+menuId+"]["+itemId+"][]' id='msg'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_corn["+menuId+"]["+itemId+"][]' id='corn'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_peanuts["+menuId+"]["+itemId+"][]' id='peanuts'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_treenuts["+menuId+"]["+itemId+"][]' id='treenuts'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_sulfites["+menuId+"]["+itemId+"][]' id='sulfites'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_mustard["+menuId+"]["+itemId+"][]' id='mustard'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_wheat["+menuId+"]["+itemId+"][]' id='wheat'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_soy["+menuId+"]["+itemId+"][]' id='soy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_seafood["+menuId+"]["+itemId+"][]' id='seafood'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_garlic["+menuId+"]["+itemId+"][]' id='garlic'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_eggs["+menuId+"]["+itemId+"][]' id='eggs'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_tartrazine["+menuId+"]["+itemId+"][]' id='tartrazine'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_onions["+menuId+"]["+itemId+"][]' id='onions'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_animal_fats_oils["+menuId+"]["+itemId+"][]' id='animal_fats_oils'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_shellfish["+menuId+"]["+itemId+"][]' id='shellfish'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_fish["+menuId+"]["+itemId+"][]' id='fish'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_sesama["+menuId+"]["+itemId+"][]' id='sesama'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='addon_dairy["+menuId+"]["+itemId+"][]' id='dairy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><input type='text' class='form-control' name='addon_saturated_fats["+menuId+"]["+itemId+"][]' id='saturated_fats' placeholder='saturated_fats'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_vitamin_a["+menuId+"]["+itemId+"][]' id='vitamin_a' placeholder='vitamin_a'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_carbs["+menuId+"]["+itemId+"][]' id='carbs' placeholder='carbs'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_vitamin_c["+menuId+"]["+itemId+"][]' id='vitamin_c' placeholder='vitamin_c'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_protein["+menuId+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_fat["+menuId+"]["+itemId+"][]' id='fat' placeholder='fat'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_cholesterol["+menuId+"]["+itemId+"][]' id='cholesterol' placeholder='cholesterol'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_fiber["+menuId+"]["+itemId+"][]' id='fiber' placeholder='fiber'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_protein["+menuId+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_calcium["+menuId+"]["+itemId+"][]' id='calcium' placeholder='calcium'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_calories["+menuId+"]["+itemId+"][]' id='calories' placeholder='calories'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_sodium["+menuId+"]["+itemId+"][]' id='sodium' placeholder='sodium'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_trans_fat["+menuId+"]["+itemId+"][]' id='trans_fat' placeholder='trans_fat'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_iron["+menuId+"]["+itemId+"][]' id='iron' placeholder='iron'></div><div class='col-md-3'><input type='text' class='form-control' name='addon_sugar["+menuId+"]["+itemId+"][]' id='sugar' placeholder='sugar'></div></div></hr>";

			$('.addon_content_'+menuId).append(addonhtml);
		});


		/*$('.variationitem-lb').click(function() {
			var itemval = $('#variationitem').val();
			var menuId = $('#variation-menudetail-select').val();
			var variationhtml = "<div class='variationform'><div class='col-md-6'><input type='text' class='form-control' name='variation_name["+menuId+"]["+itemval+"][]' id='variation_name' placeholder='variation_name'></div><div class='col-md-6'><input type='text' class='form-control' name='variation_category["+menuId+"]["+itemval+"][]' id='variation_category' placeholder='variation_category'></div></div>";
			$('.item-variation-content').append(variationhtml);
		});*/


		$('body').on('click', '.specific-variationitem-lb', function() {
			var menuId = $(this).attr('attrval');
			var itemId = $('#variationopt_'+menuId).val();
			var variationhtml = "<h5>Menu"+menuId+" AND Item "+itemId+"</h5><div class='variationform'><div class='col-md-3'><input type='text' class='form-control name' name='variation_name["+menuId+"]["+itemId+"][]' id='name' placeholder='name'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_category["+menuId+"]["+itemId+"][]' id='category' placeholder='category'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_price["+menuId+"]["+itemId+"][]' id='price' placeholder='price'></div><div class='col-md-3'><select class='form-control' name='variation_gluten_free["+menuId+"]["+itemId+"][]' id='gluten_free'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_kosher["+menuId+"]["+itemId+"][]' id='kosher'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_halal["+menuId+"]["+itemId+"][]' id='halal'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_vegan["+menuId+"]["+itemId+"][]' id='vegan'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_vegetarian["+menuId+"]["+itemId+"][]' id='vegetarian'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_spicy["+menuId+"]["+itemId+"][]' id='spicy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_ocean_wise["+menuId+"]["+itemId+"][]' id='ocean_wise'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_msg["+menuId+"]["+itemId+"][]' id='msg'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_corn["+menuId+"]["+itemId+"][]' id='corn'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_peanuts["+menuId+"]["+itemId+"][]' id='peanuts'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_treenuts["+menuId+"]["+itemId+"][]' id='treenuts'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_sulfites["+menuId+"]["+itemId+"][]' id='sulfites'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_mustard["+menuId+"]["+itemId+"][]' id='mustard'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_wheat["+menuId+"]["+itemId+"][]' id='wheat'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_soy["+menuId+"]["+itemId+"][]' id='soy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_seafood["+menuId+"]["+itemId+"][]' id='seafood'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_garlic["+menuId+"]["+itemId+"][]' id='garlic'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_eggs["+menuId+"]["+itemId+"][]' id='eggs'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_tartrazine["+menuId+"]["+itemId+"][]' id='tartrazine'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_onions["+menuId+"]["+itemId+"][]' id='onions'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_animal_fats_oils["+menuId+"]["+itemId+"][]' id='animal_fats_oils'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_shellfish["+menuId+"]["+itemId+"][]' id='shellfish'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_fish["+menuId+"]["+itemId+"][]' id='fish'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_sesama["+menuId+"]["+itemId+"][]' id='sesama'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='variation_dairy["+menuId+"]["+itemId+"][]' id='dairy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><input type='text' class='form-control' name='variation_saturated_fats["+menuId+"]["+itemId+"][]' id='saturated_fats' placeholder='saturated_fats'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_vitamin_a["+menuId+"]["+itemId+"][]' id='vitamin_a' placeholder='vitamin_a'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_carbs["+menuId+"]["+itemId+"][]' id='carbs' placeholder='carbs'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_vitamin_c["+menuId+"]["+itemId+"][]' id='vitamin_c' placeholder='vitamin_c'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_protein["+menuId+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_fat["+menuId+"]["+itemId+"][]' id='fat' placeholder='fat'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_cholesterol["+menuId+"]["+itemId+"][]' id='cholesterol' placeholder='cholesterol'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_fiber["+menuId+"]["+itemId+"][]' id='fiber' placeholder='fiber'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_protein["+menuId+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_calcium["+menuId+"]["+itemId+"][]' id='calcium' placeholder='calcium'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_calories["+menuId+"]["+itemId+"][]' id='calories' placeholder='calories'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_sodium["+menuId+"]["+itemId+"][]' id='sodium' placeholder='sodium'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_trans_fat["+menuId+"]["+itemId+"][]' id='trans_fat' placeholder='trans_fat'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_iron["+menuId+"]["+itemId+"][]' id='iron' placeholder='iron'></div><div class='col-md-3'><input type='text' class='form-control' name='variation_sugar["+menuId+"]["+itemId+"][]' id='sugar' placeholder='sugar'></div></div></hr>";

			$('.variation_content_'+menuId).append(variationhtml);
		});

		/*$('.toppingitem-lb').click(function() {
			var itemval = $('#toppingitem').val();
			var menuId = $('#toppoing-menudetail-select').val();
			var toppinghtml = "<div class='toppingform'><div class='col-md-6'><input type='text' class='form-control' name='topping_name["+menuId+"]["+itemval+"][]' id='topping_name' placeholder='topping_name'></div><div class='col-md-6'><input type='text' class='form-control' name='topping_category["+menuId+"]["+itemval+"][]' id='topping_category' placeholder='topping_category'></div></div>";
			$('.item-topping-content').append(toppinghtml);
		});*/


		$('body').on('click', '.specific-toppingitem-lb', function() {
			var menuId = $(this).attr('attrval');
			var itemId = $('#toppingopt_'+menuId).val();
			var toppinghtml = "<h5>Menu"+menuId+" AND Item "+itemId+"</h5><div class='toppingform'><div class='col-md-3'><input type='text' class='form-control name' name='topping_name["+menuId+"]["+itemId+"][]' id='name' placeholder='name'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_category["+menuId+"]["+itemId+"][]' id='category' placeholder='category'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_price["+menuId+"]["+itemId+"][]' id='price' placeholder='price'></div><div class='col-md-3'><select class='form-control' name='topping_gluten_free["+menuId+"]["+itemId+"][]' id='gluten_free'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_kosher["+menuId+"]["+itemId+"][]' id='kosher'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_halal["+menuId+"]["+itemId+"][]' id='halal'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_vegan["+menuId+"]["+itemId+"][]' id='vegan'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_vegetarian["+menuId+"]["+itemId+"][]' id='vegetarian'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_spicy["+menuId+"]["+itemId+"][]' id='spicy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_ocean_wise["+menuId+"]["+itemId+"][]' id='ocean_wise'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_msg["+menuId+"]["+itemId+"][]' id='msg'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_corn["+menuId+"]["+itemId+"][]' id='corn'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_peanuts["+menuId+"]["+itemId+"][]' id='peanuts'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_treenuts["+menuId+"]["+itemId+"][]' id='treenuts'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_sulfites["+menuId+"]["+itemId+"][]' id='sulfites'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_mustard["+menuId+"]["+itemId+"][]' id='mustard'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_wheat["+menuId+"]["+itemId+"][]' id='wheat'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_soy["+menuId+"]["+itemId+"][]' id='soy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_seafood["+menuId+"]["+itemId+"][]' id='seafood'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_garlic["+menuId+"]["+itemId+"][]' id='garlic'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_eggs["+menuId+"]["+itemId+"][]' id='eggs'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_tartrazine["+menuId+"]["+itemId+"][]' id='tartrazine'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_onions["+menuId+"]["+itemId+"][]' id='onions'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_animal_fats_oils["+menuId+"]["+itemId+"][]' id='animal_fats_oils'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_shellfish["+menuId+"]["+itemId+"][]' id='shellfish'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_fish["+menuId+"]["+itemId+"][]' id='fish'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_sesama["+menuId+"]["+itemId+"][]' id='sesama'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><select class='form-control' name='topping_dairy["+menuId+"]["+itemId+"][]' id='dairy'><option value='Y'>Y</option><option value='N'>N</option><option value='NA'>NA</option></select></div><div class='col-md-3'><input type='text' class='form-control' name='topping_saturated_fats["+menuId+"]["+itemId+"][]' id='saturated_fats' placeholder='saturated_fats'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_vitamin_a["+menuId+"]["+itemId+"][]' id='vitamin_a' placeholder='vitamin_a'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_carbs["+menuId+"]["+itemId+"][]' id='carbs' placeholder='carbs'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_vitamin_c["+menuId+"]["+itemId+"][]' id='vitamin_c' placeholder='vitamin_c'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_protein["+menuId+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_fat["+menuId+"]["+itemId+"][]' id='fat' placeholder='fat'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_cholesterol["+menuId+"]["+itemId+"][]' id='cholesterol' placeholder='cholesterol'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_fiber["+menuId+"]["+itemId+"][]' id='fiber' placeholder='fiber'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_protein["+menuId+"]["+itemId+"][]' id='protein' placeholder='protein'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_calcium["+menuId+"]["+itemId+"][]' id='calcium' placeholder='calcium'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_calories["+menuId+"]["+itemId+"][]' id='calories' placeholder='calories'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_sodium["+menuId+"]["+itemId+"][]' id='sodium' placeholder='sodium'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_trans_fat["+menuId+"]["+itemId+"][]' id='trans_fat' placeholder='trans_fat'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_iron["+menuId+"]["+itemId+"][]' id='iron' placeholder='iron'></div><div class='col-md-3'><input type='text' class='form-control' name='topping_sugar["+menuId+"]["+itemId+"][]' id='sugar' placeholder='sugar'></div></div></hr>";

			$('.topping_content_'+menuId).append(toppinghtml);
		});

	});
</script>
<script type="text/javascript">
	var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form ...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  // ... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  // ... and run a function that displays the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
 // if (n == 1 && !validateForm()) return false;
 if(currentTab == 0) { selectMenu();}
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form... :
  if (currentTab >= x.length) {
    //...the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function selectMenu() {
	var menuName = '';
	$.each($(".menu_name"), function(){
		/*alert($(this).val()); 
	    menuName += '<option name="" value="'+$(this).val()+'" attr-val="'+$(this).attr('attr-val')+'">'+$(this).attr('attr-val')+'</option>';*/
	    
	    var menuString = $(this).val();
		var value = menuString.replace(' ', '_');
	    menuName += '<option name="" value="'+value+'" attr-val="'+$(this).val()+'">'+$(this).val()+'</option>'; 
    });
    $('.menudetail-select').append(menuName);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false:
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class to the current step:
  x[n].className += " active";
}
</script>
@endpush
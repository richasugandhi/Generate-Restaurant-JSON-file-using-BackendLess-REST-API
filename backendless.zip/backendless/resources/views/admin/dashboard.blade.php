@extends('after.admin.layout')

@section('content')
<style>
    .dashboard-content {
            text-align: center;
        color: #F89C24;
        text-transform: uppercase;
    }
    .dashboard-menu-count {
        font-weight: 700;
    }
</style>

<!-- /.register-box -->
<section class="content">
	<div class="row">
	    <div class="col-md-12">
    		<div>
    			@if(session()->has('success'))
    			    <div class="alert alert-success">
    			        {{ session()->get('success') }}
    			    </div>
    			@endif
    		</div>
    		<div class="dashboard-content">
    		    <h3 class="dashboard-menu-count">You have {{$countMenu}} menus entered .</h3>
    		   {{--<span>X can be 0 or number of menues</span>--}}
    		</div>
		</div>
	</div>
</section>

@endsection
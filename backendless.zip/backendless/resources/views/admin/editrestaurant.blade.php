@extends('after.admin.layout')

@section('content')

<style>
    .has-error {
        color: red;
    }
</style>
<!-- /.register-box -->
<section class="content">
	<div class="row">
		 <div class="col-md-12">
		 	<div class="box-header with-border">
				<h3 class="box-title">Edit Restaurant</h3>
			</div>
			<div>
				@if(session()->has('error'))
				    <div class="alert alert-success">
				        {{ session()->get('error') }}
				    </div>
				@endif
			</div>
			<!-- form start -->
            <form class="form-horizontal" action="{{ route('admin.updaterestaurant') }}" method="POST">
                @csrf
              <div class="box-body">
              	<input type="hidden" name="resturant_object_id" value="{{ isset($restaurantDetails->objectId) ? $restaurantDetails->objectId : ''}}">
              	<div class="row">
              	    <div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Name</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="name" id="name"  placeholder="name" value="{{ isset($restaurantDetails->name) ? $restaurantDetails->name : ''}}" />
		                    @if ($errors->has('name'))
		                        <p class="has-error">{{ $errors->first('name') }}</p>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Street</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="street" id="street" placeholder="Street" value="{{ isset($restaurantDetails->street) ? $restaurantDetails->street : ''}}" />
		                    @if ($errors->has('street'))
		                        <p class="has-error">{{ $errors->first('street') }}</p>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">City</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="city" id="city" placeholder="City" value="{{ isset($restaurantDetails->city) ? $restaurantDetails->city : ''}}">
		                    @if ($errors->has('city'))
		                        <p class="has-error">{{ $errors->first('city') }}</p>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Province</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="prov" id="prov" placeholder="Prov" value="{{ isset($restaurantDetails->prov) ? $restaurantDetails->prov : ''}}">
		                    @if ($errors->has('prov'))
		                        <p class="has-error">{{ $errors->first('prov') }}</p>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Postal Code</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="postal" id="postal" placeholder="Postal" value="{{ isset($restaurantDetails->postal) ? $restaurantDetails->postal : ''}}">
		                    @if ($errors->has('postal'))
		                        <p class="has-error">{{ $errors->first('postal') }}</p>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">website</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="website" id="website" placeholder="Website" value="{{ isset($restaurantDetails->website) ? $restaurantDetails->website : ''}}">
		                    @if ($errors->has('website'))
		                        <p class="has-error">{{ $errors->first('website') }}</p>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Phone</label>
		                  <div class="col-sm-10">
		                    <input type="text" class="form-control" required name="phone" id="phone" placeholder="phone" value="{{ isset($restaurantDetails->phone) ? $restaurantDetails->phone : ''}}">
		                    @if ($errors->has('phone'))
		                        <p class="has-error">{{ $errors->first('phone') }}</p>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">GlutenFree</label>
		                  <div class="col-sm-10">
		                    @isset($restaurantDetails->glutenFree)
		                       <select class="form-control" name="glutenFree" id="glutenFree" placeholder="GlutenFree">
		                           <option value="Yes" {{ ($restaurantDetails->glutenFree == 'Yes') ? 'selected' : ''}}>Yes</option>
		                           <option value="Semi" {{ ($restaurantDetails->glutenFree == 'Semi') ? 'selected' : ''}}>Semi</option>
		                           <option value="No" {{ ($restaurantDetails->glutenFree == 'No') ? 'selected' : ''}}>No</option>
		                       </select>
		                    @else
		                        <select class="form-control" name="glutenFree" id="glutenFree" placeholder="GlutenFree">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Vegan</label>
		                  <div class="col-sm-10">
		                    @isset($restaurantDetails->vegan)
		                       <select class="form-control" name="vegan" id="vegan" placeholder="Vegan">
		                           <option value="Yes" {{ ($restaurantDetails->vegan == 'Yes') ? 'selected' : ''}}>Yes</option>
		                           <option value="Semi" {{ ($restaurantDetails->vegan == 'Semi') ? 'selected' : ''}}>Semi</option>
		                           <option value="No" {{ ($restaurantDetails->vegan == 'No') ? 'selected' : ''}}>No</option>
		                       </select>
		                    @else
		                        <select class="form-control" name="vegan" id="vegan" placeholder="Vegan">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Vegetarian</label>
		                  <div class="col-sm-10">
		                    @isset($restaurantDetails->vegetarian)
		                       <select class="form-control" name="vegetarian" id="vegetarian" placeholder="Vegetarian">
		                           <option value="Yes" {{ ($restaurantDetails->vegetarian == 'Yes') ? 'selected' : ''}}>Yes</option>
		                           <option value="Semi" {{ ($restaurantDetails->vegetarian == 'Semi') ? 'selected' : ''}}>Semi</option>
		                           <option value="No" {{ ($restaurantDetails->vegetarian == 'No') ? 'selected' : ''}}>No</option>
		                       </select>
		                    @else
		                        <select class="form-control" name="vegetarian" id="vegetarian" placeholder="Vegetarian">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Spicy</label>
		                  <div class="col-sm-10">
		                    @isset($restaurantDetails->spicy)
		                       <select class="form-control" name="spicy" id="spicy" placeholder="Spicy">
		                           <option value="Yes" {{ ($restaurantDetails->spicy == 'Yes') ? 'selected' : ''}}>Yes</option>
		                           <option value="Semi" {{ ($restaurantDetails->spicy == 'Semi') ? 'selected' : ''}}>Semi</option>
		                           <option value="No" {{ ($restaurantDetails->spicy == 'No') ? 'selected' : ''}}>No</option>
		                       </select>
		                    @else
		                        <select class="form-control" name="spicy" id="spicy" placeholder="Spicy">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputPassword3" class="col-sm-2 control-label">Halal</label>
		                  <div class="col-sm-10">
		                    @isset($restaurantDetails->halal)
		                       <select class="form-control" name="halal" id="halal" placeholder="Halal">
		                           <option value="Yes" {{ ($restaurantDetails->halal == 'Yes') ? 'selected' : ''}}>Yes</option>
		                           <option value="Semi" {{ ($restaurantDetails->halal == 'Semi') ? 'selected' : ''}}>Semi</option>
		                           <option value="No" {{ ($restaurantDetails->halal == 'No') ? 'selected' : ''}}>No</option>
		                       </select>
		                    @else
		                        <select class="form-control" name="halal" id="halal" placeholder="Halal">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Kosher</label>
		                  <div class="col-sm-10">
		                    @isset($restaurantDetails->kosher)
		                       <select class="form-control" name="kosher" id="kosher" placeholder="Kosher">
		                           <option value="Yes" {{ ($restaurantDetails->kosher == 'Yes') ? 'selected' : ''}}>Yes</option>
		                           <option value="Semi" {{ ($restaurantDetails->kosher == 'Semi') ? 'selected' : ''}}>Semi</option>
		                           <option value="No" {{ ($restaurantDetails->kosher == 'No') ? 'selected' : ''}}>No</option>
		                       </select>
		                    @else
		                        <select class="form-control" name="kosher" id="kosher" placeholder="Kosher">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    @endif
		                  </div>
		                </div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Occeanwise</label>
		                  <div class="col-sm-10">
		                    @isset($restaurantDetails->occeanwise)
		                       <select class="form-control" name="occeanwise" id="occeanwise" placeholder="Occeanwise">
		                           <option value="Yes" {{ ($restaurantDetails->occeanwise == 'Yes') ? 'selected' : ''}}>Yes</option>
		                           <option value="Semi" {{ ($restaurantDetails->occeanwise == 'Semi') ? 'selected' : ''}}>Semi</option>
		                           <option value="No" {{ ($restaurantDetails->occeanwise == 'No') ? 'selected' : ''}}>No</option>
		                       </select>
		                    @else
		                        <select class="form-control" name="occeanwise" id="occeanwise" placeholder="Occeanwise">
		                            <option value="Yes">Yes</option>
		                           <option value="Semi">Semi</option>
		                           <option value="No">No</option>
		                        </select>
		                    @endif
		                  </div>
		                </div>
					</div>
					
					<!--<div class="col-md-6">
						<div class="form-group">
		                  <label for="inputEmail3" class="col-sm-2 control-label">Sideright</label>
		                  <div class="col-sm-10">
		                  	@if(isset($restaurantDetails->sideright))
								<select class="form-control" name="sideright" id="sideright" placeholder="Sideright">
			                  		<option value="TRUE" {{ ($restaurantDetails->sideright == TRUE) ? 'selected' : ''}}>1</option>
			                  		<option value="FALSE" {{ ($restaurantDetails->sideright == FALSE) ? 'selected' : ''}}>0</option>
			                  	</select>
		                  	@else
								<select class="form-control" name="sideright" id="sideright" placeholder="Sideright">
			                  		<option value="TRUE">1</option>
			                  		<option value="FALSE">0</option>
			                  	</select>
		                  	@endif
		                  </div>
		                </div>
					</div>-->
					
				</div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <a href="{{ route('/') }}">Cancel</a>
                <button type="submit" class="btn btn-info pull-right">Update</button>
              </div>
              <!-- /.box-footer -->
            </form>
		 </div>
	</div>
</section>
@endsection
@extends('after.restaurant.layout')

@section('content')


@endsection
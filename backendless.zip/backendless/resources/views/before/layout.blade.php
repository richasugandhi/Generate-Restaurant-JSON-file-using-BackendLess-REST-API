@include('before.common.header')

{{--@include('before.common.sidebar')--}}

{{--@include('before.common.navigation')--}}

    @yield('content')

@include('before.common.footer')
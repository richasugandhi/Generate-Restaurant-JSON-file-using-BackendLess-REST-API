<?php 
return [
	'BACKENDLESS_APP_ID' => 'xxxxxxxxxxxxxxxxxx',
	'BACKENDLESS_REST_API_KEY' => 'yyyyyyyyyyyyyyyyyyyyyy'
];
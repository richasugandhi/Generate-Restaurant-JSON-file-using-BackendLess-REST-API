<?php

if (!function_exists('curlPostFun')) {
	function curlPostFun($url, $postData){
		$jsonData = json_encode($postData);
		$ch = curl_init($url);

		curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$result = curl_exec($ch);
		curl_close($ch);
		return $result;
	}
}


if (!function_exists('curlPutFun')) {
	function curlPutFun($url, $putData){
		$jsonData = json_encode($putData);
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch, CURLOPT_POSTFIELDS,$jsonData);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
	}
}


if (!function_exists('loginUserData')) {
	function loginUserData(){
	    $appId = config('constants.BACKENDLESS_APP_ID');
	    $apiKey = config('constants.BACKENDLESS_REST_API_KEY');
	    
		$value = session()->get('loginUser');
		if(!empty($value)) {
			$url = 'https://api.backendless.com/'.$appId.'/'.$apiKey.'/users/'.$value->objectId.'?props=name,email,objectId,ownerId';

			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			$result = curl_exec($ch);
			return json_decode($result);
		}
	}
}
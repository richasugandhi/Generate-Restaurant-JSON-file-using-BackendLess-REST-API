<?php

namespace App\Http\Middleware;

use Closure;
use Session;

class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {   
        $value = session()->get('loginUser');

        if(isset($value)) {
            if($value->headquarter == '') {
                redirect(route('admin.dashboard'));  
            } else {
                 redirect(route('dashboard'));
            }
        } else {
            return redirect()->route('/');
        }
        return $next($request);
    }
}

<?php

namespace App\Http\Controllers;

use Session;
use Validator;
use Illuminate\Http\Request;

class AdminController extends Controller
{
        private $appId;
        private $apiKey;
	public function __construct()
    { 
        $this->middleware('checkRole');
        $this->appId = config('constants.BACKENDLESS_APP_ID');
        $this->apiKey = config('constants.BACKENDLESS_REST_API_KEY');
    }
    
    public function objectToArray($d) 
    {
        if (is_object($d)) {
            // Gets the properties of the given object
            // with get_object_vars function
            $d = get_object_vars($d);
        }
    
        if (is_array($d)) {
            /*
            * Return array converted to object
            * Using __FUNCTION__ (Magic constant)
            * for recursive call
            */
            return array_map(__FUNCTION__, $d);
        } else {
            // Return array
            return $d;
        }
    }

    public function logout()
    {
        $value = session()->get('loginUser');
        
        $valueArray = json_decode(json_encode($value), True);
        $userToken = $valueArray['user-token'];
        
        $url = 'http://api.backendless.com/'.$this->appId.'/'.$this->apiKey.'/users/logout';
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('user-token:'.$userToken));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
         session()->flush();
        return redirect()->route('/');
    }
    
    public function getJsonFileData()
    {
        $resturantData = $this->getUserResturant();
        if(isset($resturantData->restaurant[0]->JSONfile) && ($resturantData->restaurant[0]->JSONfile != '')) {
            $restaurantDetails = $resturantData->restaurant[0]->JSONfile;
            
            $getFileContent = @file_get_contents($restaurantDetails);
            if($getFileContent === FALSE) {
                $jsonFiles = '';
            } else {
                $jsonFiles = json_decode($getFileContent);
            }
            
        } else { 
            $jsonFiles = '';
        }
        return $jsonFiles;
    }
    
    public function index()
    {
        if(($this->getJsonFileData() != '') && !empty($this->getJsonFileData())) {
            $countMenu = count($this->getJsonFileData());
        } else {
            $countMenu = 0;
        }
    	return view('admin/dashboard', compact('countMenu'));
    }
    
    public function getUserResturant()
    {
        $loginData = loginUserData();
        $objectid = $loginData->objectId;

        $url = 'http://api.backendless.com/'.$this->appId.'/'.$this->apiKey.'/data/Users/'.$objectid.'?loadRelations=restaurant';

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        $resturantData = json_decode($result);
        return $resturantData;
    }
    
    public function getResturantImages($resturantId)
    {
        $url = 'http://api.backendless.com/'.$this->appId.'/'.$this->apiKey.'/data/Restaurants/'.$resturantId.'?loadRelations=menuImages';
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        $resturantImgData = json_decode($result);
        
        $oldImg=[];
        if(isset($resturantImgData) && !empty($resturantImgData)) {
            $menuImages = $resturantImgData->menuImages;
            if(isset($menuImages) && !empty($menuImages)) {
                
                foreach($menuImages as $menuImage) {
                    $oldImg[] = $menuImage->objectId;
                }
            }
            
        }
        return $oldImg;
    }

    public function editrestaurant()
    {
    	$resturantData = $this->getUserResturant();

		if(isset($resturantData) && !empty($resturantData) && isset($resturantData->restaurant) && !empty($resturantData->restaurant)) {

			$restaurantDetails = $resturantData->restaurant[0];
			return view('admin/editrestaurant', compact('restaurantDetails'));
		} else {
			return view('admin/editrestaurant');
		}
    }

    public function updaterestaurant(Request $request)
    {
        $validator = Validator::make($request->all(),
            ['name' => 'required', 'street' => 'required',
            'city' => 'required', 'prov' => 'required', 'postal'=> 'required', 'website' => 'required', 'phone' => 'required', 'glutenFree' => 'required', 'vegetarian' => 'required', 'spicy' => 'required', 'halal' => 'required', 'kosher' => 'required', 'occeanwise' => 'required']
        );
        if ($validator->fails())
        {
            return redirect('editrestaurant')->withErrors($validator);
        } 
        else {
            $resturantObjectId = $request->resturant_object_id;
    	
    	    $url = 'https://api.backendless.com/C41FC229-743D-296A-FF29-480E1EC14D00/9975C2C2-F45E-76F2-FF55-6AAC872E6E00/data/Restaurants/'.$resturantObjectId;
    	    $postData = array(
		        'city' => $request->city,
		        'glutenFree' => $request->glutenFree,
		        'halal' => $request->halal,
		        'kosher' => $request->kosher,
		        'name' => $request->name,
		        'occeanwise' => $request->occeanwise,
		        'phone' => $request->phone,
		        'postal' => $request->postal,
		        'prov' => $request->prov,
		        'sideright' => (bool)$request->sideright,
		        'spicy' => $request->spicy,
		        'street' => $request->street,
		        'vegan' => $request->vegan,
		        'vegetarian' => $request->vegetarian,
		        'website' => $request->website
		    );
		 
        	$jsonData = json_encode($postData);
        	$ch = curl_init($url);
    		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch, CURLOPT_POSTFIELDS,$jsonData);
            $response = curl_exec($ch);
            curl_close($ch);
    
            $decodeJson = json_decode($response);
            if(isset($decodeJson) && isset($decodeJson->objectId)) {
            	return redirect()->route('admin.dashboard')->with('success', 'Successfully Updated !!');
        	} else {
        		return redirect()->route('admin.editrestaurant')->with('error', 'Something Went Wrong Please Try Again !!');
        	}
        }
    }
    
    public function modifyrestaurant()
    {
        $resturantData = $this->getUserResturant();
        if(isset($resturantData->restaurant[0]->JSONfile) && ($resturantData->restaurant[0]->JSONfile != '')) {
            $restaurantDetails = $resturantData->restaurant[0]->JSONfile;
            
            $getFileContent = @file_get_contents($restaurantDetails);

            if($getFileContent === FALSE) {

               return redirect('/addrestaurant');

            } else {
                $jsonFiles = json_decode($getFileContent);
            
                if(isset($jsonFiles) && !empty($jsonFiles)) {
                
                $menuName = []; $item = [];
                $side = []; $addon = []; $variation = [];
                $customSidesHtml = [];
                foreach($jsonFiles as $key=>$jsonFile) {
                    $menuName[$key] = array('menu_name'=>$jsonFile->name, 'monday'=>isset($jsonFile->Monday) ? $jsonFile->Monday : '', 'Tuesday'=>isset($jsonFile->Tuesday) ? $jsonFile->Tuesday : '', 'Wenesday'=>isset($jsonFile->Wenesday) ? $jsonFile->Wenesday : '', 'Thurday'=>isset($jsonFile->Thurday) ? $jsonFile->Thurday : '', 'Friday'=>isset($jsonFile->Friday) ? $jsonFile->Friday : '', 'Saturday'=>isset($jsonFile->Saturday) ? $jsonFile->Saturday : '', 'Sunday'=>isset($jsonFile->Sunday) ? $jsonFile->Sunday : '', 'start_time'=>isset($jsonFile->start_time) ? $jsonFile->start_time : '', 'end_time'=>isset($jsonFile->end_time) ? $jsonFile->end_time : '');
                    
                    if(isset($jsonFile->item) && !empty($jsonFile->item)) {
                        $item[$key] = $jsonFile->item;
                        $itemlists = $jsonFile->item;
                        
                        $option='';
                        for($i = 0; $i<count($itemlists); $i++) {
                            $sum = $i+1;
                            $option .= '<option value="'.$i.'">'.$sum.'</option>';
                        }
                        
                        if(isset($itemlists) && !empty($itemlists)) {
                            foreach($itemlists as $itemKey=>$itemlist) {
                                $side[$key][$itemKey] = (isset($itemlist->side) && !empty($itemlist->side)) ? $itemlist->side : array();
                                $addon[$key][$itemKey] = (isset($itemlist->addon) && !empty($itemlist->side)) ? $itemlist->addon : array();
                                $variation[$key][$itemKey] = (isset($itemlist->variation) && !empty($itemlist->side)) ? $itemlist->variation : array();
                                
                                
                                if(isset($itemlist->side) && !empty($itemlist->side)) {
                                    $itemSides = $itemlist->side;
                                    foreach($itemSides as $sideKey=>$itemSide) {
    
                                        $customSidesHtml[$key] = "<div class='additemform' id='additemform_".$jsonFile->name."'><label id='side_menu_lb_".$jsonFile->name."'>".$jsonFile->name."</label><select class='itemopt' id='itemopt_".$jsonFile->name."'>".$option."</select><label class='specific-sideitem-lb' attrval=".$jsonFile->name.">Add Sides</label></div>";
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            $startTime = date('h A');
            $endTime = date('h A', strtotime('+5 hours'));
            $exStart = explode(' ', $startTime);
            $start = $exStart[0].':00 '. $exStart[1];
            
            $exEnd = explode(' ', $endTime);
            $end = $exEnd[0].':00 '. $exEnd[1];
        
                return view('admin/modifyrestaurant', compact('menuName', 'item', 'side', 'addon', 'variation', 'customSidesHtml', 'start', 'end'));
            }
            
        } else {
            return view('admin/restaurant');
        }
    }
    
    
    public function sortParentAryForModify($commonArrayOfSections, $menuName)
    {
    	$finalArray = [];
        if(isset($commonArrayOfSections)) {
            foreach ($commonArrayOfSections as $key => $commonArrayOfSection) {
                
                $initialAry = $commonArrayOfSection;
        
                $insideKeyAry = [];
                if(isset($commonArrayOfSection)) {

                    foreach($commonArrayOfSection as $key1 => $commonArrayOfSectionss) {
                        $insideKeyAry[] = $key1;
                    }
                    sort($insideKeyAry);
                }
 
                $sortResult=[];
                if(isset($insideKeyAry)) {
                    foreach ($insideKeyAry as $insideKeyArys) {
                        $sortResult[$insideKeyArys] = $initialAry[$insideKeyArys];
                    }
                    $finalArray[$key] = $sortResult;
                }
            }
        }
        return $finalArray;
    }
  
    public function sortSubParentAryModify($commonArrayOfSections, $menuName)
    {
    	$finalArray = [];
        $res = [];
        if(isset($commonArrayOfSections)) {
            foreach ($commonArrayOfSections as $key => $commonArrayOfSection) {

                foreach ($commonArrayOfSection as $key1 => $subAry) {
                    $initialAry = $subAry;

                    $insideSubKeyAry = [];
                    if(isset($subAry)) {
                        foreach($subAry as $key2 => $subArys) {
                            $insideSubKeyAry[] = $key2;
                        }
                        sort($insideSubKeyAry);
                    }

                    if(isset($insideSubKeyAry) && !empty($insideSubKeyAry)) {
                        foreach($insideSubKeyAry as $key3=>$insideSubKeyArys) {
                            $res[$key][$key1][$insideSubKeyArys] =  $initialAry[$insideSubKeyArys];
                        }
                    }
                    
                }
            }
        }
        return $res;
    }
    
    public function mainJsonResponseSort($mainAry) {
        $finalArray = [];
        if(isset($mainAry)) {
            foreach ($mainAry as $key => $mainArys) {
                
                $initialAry = $mainArys;
                $finalArray[] = $mainAry[$key];
            }
        }
        return $finalArray;
    }
    
    public function modifysubmitrestaurant(Request $request)
    {
        if(isset($_FILES) && !empty($_FILES)) {
            $images = $request->file('menu_image');
            $imagesForBackendless = $_FILES['menu_image'];
        }
        
        $main = array();
    	$menuName = $request->get('menu_name');

    	$mainTab1Ary = array('day'=>$request->get('day'),
    						'start_time'=>$request->get('start_time'),
    						'end_time'=>$request->get('end_time'));
    	$finalMainTab1Ary = $this->getDayTimeByMenu($mainTab1Ary, $menuName);
    	/*sort($menuName);
    	 echo '<pre>';print_r($menuName);
    	 die;*/
    
    	$itemAry = array('name'=>$request->get('name'),'category'=>$request->get('category'),'price'=>$request->get('price'),'gluten_free'=>$request->get('gluten_free'),'kosher'=>$request->get('kosher'),'halal'=>$request->get('halal'),'vegan'=>$request->get('vegan'),'vegetarian'=>$request->get('vegetarian'),'spicy'=>$request->get('spicy'),'ocean_wise'=>$request->get('ocean_wise'),'msg'=>$request->get('msg'),'corn'=>$request->get('corn'),'peanuts'=>$request->get('peanuts'),'treenuts'=>$request->get('treenuts'), 'sulfites'=>$request->get('sulfites'), 'mustard'=>$request->get('mustard'), 'wheat'=>$request->get('wheat'), 'soy'=>$request->get('soy'), 'seafood'=>$request->get('seafood'), 'garlic'=>$request->get('garlic'), 'eggs'=>$request->get('eggs'), 'tartrazine'=>$request->get('tartrazine'), 'onions'=>$request->get('onions'), 'animal_fats_oils'=>$request->get('animal_fats_oils'), 'shellfish'=>$request->get('shellfish'), 'fish'=>$request->get('fish'), 'sesama'=>$request->get('sesama'), 'dairy'=>$request->get('dairy'), 'saturated_fats'=>$request->get('saturated_fats'), 'vitamin_a'=>$request->get('vitamin_a'), 'carbs'=>$request->get('carbs'), 'vitamin_c'=>$request->get('vitamin_c'), 'protein'=>$request->get('protein'), 'fat'=>$request->get('fat'), 'cholesterol'=>$request->get('cholesterol'), 'fiber'=>$request->get('fiber'), 'calcium'=>$request->get('calcium'), 'calories'=>$request->get('calories'), 'sodium'=>$request->get('sodium'), 'trans_fat'=>$request->get('trans_fat'), 'iron'=>$request->get('iron'), 'sugar'=>$request->get('sugar'));
    
    	$finalItemAry = $this->sortParentAryForModify($itemAry, $menuName);

    	$sideAry = array('side_standard'=>$request->get('side_standard'),'side_name'=>$request->get('side_name'),'side_category'=>$request->get('side_category'),'side_price'=>$request->get('side_price'),'side_gluten_free'=>$request->get('side_gluten_free'),'side_kosher'=>$request->get('side_kosher'),'side_halal'=>$request->get('side_halal'),'side_vegan'=>$request->get('side_vegan'),'side_vegetarian'=>$request->get('side_vegetarian'),'side_spicy'=>$request->get('side_spicy'),'side_ocean_wise'=>$request->get('side_ocean_wise'),'side_msg'=>$request->get('side_msg'),'side_corn'=>$request->get('side_corn'),'side_peanuts'=>$request->get('side_peanuts'),'side_treenuts'=>$request->get('side_treenuts'), 'side_sulfites'=>$request->get('side_sulfites'), 'side_mustard'=>$request->get('side_mustard'), 'side_wheat'=>$request->get('side_wheat'), 'side_soy'=>$request->get('side_soy'), 'side_seafood'=>$request->get('side_seafood'), 'side_garlic'=>$request->get('side_garlic'), 'side_eggs'=>$request->get('side_eggs'), 'side_tartrazine'=>$request->get('side_tartrazine'), 'side_onions'=>$request->get('side_onions'), 'side_animal_fats_oils'=>$request->get('side_animal_fats_oils'), 'side_shellfish'=>$request->get('side_shellfish'), 'side_fish'=>$request->get('side_fish'), 'side_sesama'=>$request->get('side_sesama'), 'side_dairy'=>$request->get('side_dairy'), 'side_saturated_fats'=>$request->get('side_saturated_fats'), 'side_vitamin_a'=>$request->get('side_vitamin_a'), 'side_carbs'=>$request->get('side_carbs'), 'side_vitamin_c'=>$request->get('side_vitamin_c'), 'side_protein'=>$request->get('side_protein'), 'side_fat'=>$request->get('side_fat'), 'side_cholesterol'=>$request->get('side_cholesterol'), 'side_fiber'=>$request->get('side_fiber'), 'side_calcium'=>$request->get('side_calcium'), 'side_calories'=>$request->get('side_calories'), 'side_sodium'=>$request->get('side_sodium'), 'side_trans_fat'=>$request->get('side_trans_fat'), 'side_iron'=>$request->get('side_iron'), 'side_sugar'=>$request->get('side_sugar'));
    	
    	$finalSideAry = $this->sortParentAryForModify($sideAry, $menuName);
    	
    	$finalSubSideAry = $this->sortSubParentAryModify($finalSideAry, $menuName);


    	$addonAry = array('addon_name'=>$request->get('addon_name'),'addon_category'=>$request->get('addon_category'),'addon_price'=>$request->get('addon_price'),'addon_gluten_free'=>$request->get('addon_gluten_free'),'addon_kosher'=>$request->get('addon_kosher'),'addon_halal'=>$request->get('addon_halal'),'addon_vegan'=>$request->get('addon_vegan'),'addon_vegetarian'=>$request->get('addon_vegetarian'),'addon_spicy'=>$request->get('addon_spicy'),'addon_ocean_wise'=>$request->get('addon_ocean_wise'),'addon_msg'=>$request->get('addon_msg'),'addon_corn'=>$request->get('addon_corn'),'addon_peanuts'=>$request->get('addon_peanuts'),'addon_treenuts'=>$request->get('addon_treenuts'), 'addon_sulfites'=>$request->get('addon_sulfites'), 'addon_mustard'=>$request->get('addon_mustard'), 'addon_wheat'=>$request->get('addon_wheat'), 'addon_soy'=>$request->get('addon_soy'), 'addon_seafood'=>$request->get('addon_seafood'), 'addon_garlic'=>$request->get('addon_garlic'), 'addon_eggs'=>$request->get('addon_eggs'), 'addon_tartrazine'=>$request->get('addon_tartrazine'), 'addon_onions'=>$request->get('addon_onions'), 'addon_animal_fats_oils'=>$request->get('addon_animal_fats_oils'), 'addon_shellfish'=>$request->get('addon_shellfish'), 'addon_fish'=>$request->get('addon_fish'), 'addon_sesama'=>$request->get('addon_sesama'), 'addon_dairy'=>$request->get('addon_dairy'), 'addon_saturated_fats'=>$request->get('addon_saturated_fats'), 'addon_vitamin_a'=>$request->get('addon_vitamin_a'), 'addon_carbs'=>$request->get('addon_carbs'), 'addon_vitamin_c'=>$request->get('addon_vitamin_c'), 'addon_protein'=>$request->get('addon_protein'), 'addon_fat'=>$request->get('addon_fat'), 'addon_cholesterol'=>$request->get('addon_cholesterol'), 'addon_fiber'=>$request->get('addon_fiber'), 'addon_calcium'=>$request->get('addon_calcium'), 'addon_calories'=>$request->get('addon_calories'), 'addon_sodium'=>$request->get('addon_sodium'), 'addon_trans_fat'=>$request->get('addon_trans_fat'), 'addon_iron'=>$request->get('addon_iron'), 'addon_sugar'=>$request->get('addon_sugar'));
    	$finalAddonAry = $this->sortParentAryForModify($addonAry, $menuName);
    	$finalSubAddonAry = $this->sortSubParentAryModify($finalAddonAry, $menuName);


    	$variationAry = array('variation_name'=>$request->get('variation_name'),'variation_category'=>$request->get('variation_category'),'variation_price'=>$request->get('variation_price'),'variation_gluten_free'=>$request->get('variation_gluten_free'),'variation_kosher'=>$request->get('variation_kosher'),'variation_halal'=>$request->get('variation_halal'),'variation_vegan'=>$request->get('variation_vegan'),'variation_vegetarian'=>$request->get('variation_vegetarian'),'variation_spicy'=>$request->get('variation_spicy'),'variation_ocean_wise'=>$request->get('variation_ocean_wise'),'variation_msg'=>$request->get('variation_msg'),'variation_corn'=>$request->get('variation_corn'),'variation_peanuts'=>$request->get('variation_peanuts'),'variation_treenuts'=>$request->get('variation_treenuts'), 'variation_sulfites'=>$request->get('variation_sulfites'), 'variation_mustard'=>$request->get('variation_mustard'), 'variation_wheat'=>$request->get('variation_wheat'), 'variation_soy'=>$request->get('variation_soy'), 'variation_seafood'=>$request->get('variation_seafood'), 'variation_garlic'=>$request->get('variation_garlic'), 'variation_eggs'=>$request->get('variation_eggs'), 'variation_tartrazine'=>$request->get('variation_tartrazine'), 'variation_onions'=>$request->get('variation_onions'), 'variation_animal_fats_oils'=>$request->get('variation_animal_fats_oils'), 'variation_shellfish'=>$request->get('variation_shellfish'), 'variation_fish'=>$request->get('variation_fish'), 'variation_sesama'=>$request->get('variation_sesama'), 'variation_dairy'=>$request->get('variation_dairy'), 'variation_saturated_fats'=>$request->get('variation_saturated_fats'), 'variation_vitamin_a'=>$request->get('variation_vitamin_a'), 'variation_carbs'=>$request->get('variation_carbs'), 'variation_vitamin_c'=>$request->get('variation_vitamin_c'), 'variation_protein'=>$request->get('variation_protein'), 'variation_fat'=>$request->get('variation_fat'), 'variation_cholesterol'=>$request->get('variation_cholesterol'), 'variation_fiber'=>$request->get('variation_fiber'), 'variation_calcium'=>$request->get('variation_calcium'), 'variation_calories'=>$request->get('variation_calories'), 'variation_sodium'=>$request->get('variation_sodium'), 'variation_trans_fat'=>$request->get('variation_trans_fat'), 'variation_iron'=>$request->get('variation_iron'), 'variation_sugar'=>$request->get('variation_sugar'));
    	$finalVariationAry = $this->sortParentAryForModify($variationAry, $menuName);
    	$finalSubVariationAry = $this->sortSubParentAryModify($finalVariationAry, $menuName);


    	$toppingAry = array('topping_name'=>$request->get('topping_name'),'topping_category'=>$request->get('topping_category'),'topping_price'=>$request->get('topping_price'),'topping_gluten_free'=>$request->get('topping_gluten_free'),'topping_kosher'=>$request->get('topping_kosher'),'topping_halal'=>$request->get('topping_halal'),'topping_vegan'=>$request->get('topping_vegan'),'topping_vegetarian'=>$request->get('topping_vegetarian'),'topping_spicy'=>$request->get('topping_spicy'),'topping_ocean_wise'=>$request->get('topping_ocean_wise'),'topping_msg'=>$request->get('topping_msg'),'topping_corn'=>$request->get('topping_corn'),'topping_peanuts'=>$request->get('topping_peanuts'),'topping_treenuts'=>$request->get('topping_treenuts'), 'topping_sulfites'=>$request->get('topping_sulfites'), 'topping_mustard'=>$request->get('topping_mustard'), 'topping_wheat'=>$request->get('topping_wheat'), 'topping_soy'=>$request->get('topping_soy'), 'topping_seafood'=>$request->get('topping_seafood'), 'topping_garlic'=>$request->get('topping_garlic'), 'topping_eggs'=>$request->get('topping_eggs'), 'topping_tartrazine'=>$request->get('topping_tartrazine'), 'topping_onions'=>$request->get('topping_onions'), 'topping_animal_fats_oils'=>$request->get('topping_animal_fats_oils'), 'topping_shellfish'=>$request->get('topping_shellfish'), 'topping_fish'=>$request->get('topping_fish'), 'topping_sesama'=>$request->get('topping_sesama'), 'topping_dairy'=>$request->get('topping_dairy'), 'topping_saturated_fats'=>$request->get('topping_saturated_fats'), 'topping_vitamin_a'=>$request->get('topping_vitamin_a'), 'topping_carbs'=>$request->get('topping_carbs'), 'topping_vitamin_c'=>$request->get('topping_vitamin_c'), 'topping_protein'=>$request->get('topping_protein'), 'topping_fat'=>$request->get('topping_fat'), 'topping_cholesterol'=>$request->get('topping_cholesterol'), 'topping_fiber'=>$request->get('topping_fiber'), 'topping_calcium'=>$request->get('topping_calcium'), 'topping_calories'=>$request->get('topping_calories'), 'topping_sodium'=>$request->get('topping_sodium'), 'topping_trans_fat'=>$request->get('topping_trans_fat'), 'topping_iron'=>$request->get('topping_iron'), 'topping_sugar'=>$request->get('topping_sugar'));
    	$finalToppingAry = $this->sortParentAryForModify($toppingAry, $menuName);
    	$finalSubToppingAry = $this->sortSubParentAryModify($finalToppingAry, $menuName);
    	
        
        $main = [];
        foreach($menuName as $i => $menuNames) {
            $item=[];
            if(isset($finalItemAry['name'][$i])) {
                $itemName = $finalItemAry['name'][$i];
                
                foreach($itemName as $j=>$itemNameVal) {
                    $side = [];
                    
                    if(isset($finalSubSideAry['side_standard'][$i][$j])) {
                        $sideStandard = $finalSubSideAry['side_standard'][$i][$j];
                        
                        foreach($sideStandard as $k => $sideStandards) {
                            /*$side[] = array('name'=>isset($finalSubSideAry['side_name'][$i][$j][$k]) ? $finalSubSideAry['side_name'][$i][$j][$k] : '');*/
                            $side[] = array(
                                'standard'=>$finalSubSideAry['side_standard'][$i][$j][$k], 'name'=>isset($finalSubSideAry['side_name'][$i][$j][$k]) ? $finalSubSideAry['side_name'][$i][$j][$k] : '', 'category'=>isset($finalSubSideAry['side_category'][$i][$j][$k]) ? $finalSubSideAry['side_category'][$i][$j][$k] : '','price'=>isset($finalSubSideAry['side_price'][$i][$j][$k]) ? $finalSubSideAry['side_price'][$i][$j][$k] : '','gluten_free'=>isset($finalSubSideAry['side_gluten_free'][$i][$j][$k]) ? $finalSubSideAry['side_gluten_free'][$i][$j][$k] : '','kosher'=>isset($finalSubSideAry['side_kosher'][$i][$j][$k]) ? $finalSubSideAry['side_kosher'][$i][$j][$k] : '','halal'=>isset($finalSubSideAry['side_halal'][$i][$j][$k]) ? $finalSubSideAry['side_halal'][$i][$j][$k] : '','vegan'=>isset($finalSubSideAry['side_vegan'][$i][$j][$k]) ? $finalSubSideAry['side_vegan'][$i][$j][$k] : '','vegetarian'=>isset($finalSubSideAry['side_vegetarian'][$i][$j][$k]) ? $finalSubSideAry['side_vegetarian'][$i][$j][$k] : '','spicy'=>isset($finalSubSideAry['side_spicy'][$i][$j][$k]) ? $finalSubSideAry['side_spicy'][$i][$j][$k] : '','ocean_wise'=>isset($finalSubSideAry['side_ocean_wise'][$i][$j][$k]) ? $finalSubSideAry['side_ocean_wise'][$i][$j][$k] : '','msg'=>isset($finalSubSideAry['side_msg'][$i][$j][$k]) ? $finalSubSideAry['side_msg'][$i][$j][$k] : '','corn'=>isset($finalSubSideAry['side_corn'][$i][$j][$k]) ? $finalSubSideAry['side_corn'][$i][$j][$k] : '','peanuts'=>isset($finalSubSideAry['side_peanuts'][$i][$j][$k]) ? $finalSubSideAry['side_peanuts'][$i][$j][$k] : '','treenuts'=>isset($finalSubSideAry['side_treenuts'][$i][$j][$k]) ? $finalSubSideAry['side_treenuts'][$i][$j][$k] : '','sulfites'=>isset($finalSubSideAry['side_sulfites'][$i][$j][$k]) ? $finalSubSideAry['side_sulfites'][$i][$j][$k] : '','mustard'=>isset($finalSubSideAry['side_mustard'][$i][$j][$k]) ? $finalSubSideAry['side_mustard'][$i][$j][$k] : '','wheat'=>isset($finalSubSideAry['side_wheat'][$i][$j][$k]) ? $finalSubSideAry['side_wheat'][$i][$j][$k] : '','soy'=>isset($finalSubSideAry['side_soy'][$i][$j][$k]) ? $finalSubSideAry['side_soy'][$i][$j][$k] : '','seafood'=>isset($finalSubSideAry['side_seafood'][$i][$j][$k]) ? $finalSubSideAry['side_seafood'][$i][$j][$k] : '','garlic'=>isset($finalSubSideAry['side_garlic'][$i][$j][$k]) ? $finalSubSideAry['side_garlic'][$i][$j][$k] : '','eggs'=>isset($finalSubSideAry['side_eggs'][$i][$j][$k]) ? $finalSubSideAry['side_eggs'][$i][$j][$k] : '','tartrazine'=>isset($finalSubSideAry['side_tartrazine'][$i][$j][$k]) ? $finalSubSideAry['side_tartrazine'][$i][$j][$k] : '','onions'=>isset($finalSubSideAry['side_onions'][$i][$j][$k]) ? $finalSubSideAry['side_onions'][$i][$j][$k] : '','animal_fats_oils'=>isset($finalSubSideAry['side_animal_fats_oils'][$i][$j][$k]) ? $finalSubSideAry['side_animal_fats_oils'][$i][$j][$k] : '','shellfish'=>isset($finalSubSideAry['side_shellfish'][$i][$j][$k]) ? $finalSubSideAry['side_shellfish'][$i][$j][$k] : '','fish'=>isset($finalSubSideAry['side_fish'][$i][$j][$k]) ? $finalSubSideAry['side_fish'][$i][$j][$k] : '','sesama'=>isset($finalSubSideAry['side_sesama'][$i][$j][$k]) ? $finalSubSideAry['side_sesama'][$i][$j][$k] : '','dairy'=>isset($finalSubSideAry['side_dairy'][$i][$j][$k]) ? $finalSubSideAry['side_dairy'][$i][$j][$k] : '','saturated_fats'=>isset($finalSubSideAry['side_saturated_fats'][$i][$j][$k]) ? $finalSubSideAry['side_saturated_fats'][$i][$j][$k] : '','vitamin_a'=>isset($finalSubSideAry['side_vitamin_a'][$i][$j][$k]) ? $finalSubSideAry['side_vitamin_a'][$i][$j][$k] : '','carbs'=>isset($finalSubSideAry['side_carbs'][$i][$j][$k]) ? $finalSubSideAry['side_carbs'][$i][$j][$k] : '','vitamin_c'=>isset($finalSubSideAry['side_vitamin_c'][$i][$j][$k]) ? $finalSubSideAry['side_vitamin_c'][$i][$j][$k] : '','protein'=>isset($finalSubSideAry['side_protein'][$i][$j][$k]) ? $finalSubSideAry['side_protein'][$i][$j][$k] : '','fat'=>isset($finalSubSideAry['side_fat'][$i][$j][$k]) ? $finalSubSideAry['side_fat'][$i][$j][$k] : '','cholesterol'=>isset($finalSubSideAry['side_cholesterol'][$i][$j][$k]) ? $finalSubSideAry['side_cholesterol'][$i][$j][$k] : '','fiber'=>isset($finalSubSideAry['side_fiber'][$i][$j][$k]) ? $finalSubSideAry['side_fiber'][$i][$j][$k] : '','calcium'=>isset($finalSubSideAry['side_calcium'][$i][$j][$k]) ? $finalSubSideAry['side_calcium'][$i][$j][$k] : '','calories'=>isset($finalSubSideAry['side_calories'][$i][$j][$k]) ? $finalSubSideAry['side_calories'][$i][$j][$k] : '','sodium'=>isset($finalSubSideAry['side_sodium'][$i][$j][$k]) ? $finalSubSideAry['side_sodium'][$i][$j][$k] : '','trans_fat'=>isset($finalSubSideAry['side_trans_fat'][$i][$j][$k]) ? $finalSubSideAry['side_trans_fat'][$i][$j][$k] : '','iron'=>isset($finalSubSideAry['side_iron'][$i][$j][$k]) ? $finalSubSideAry['side_iron'][$i][$j][$k] : '','sugar'=>isset($finalSubSideAry['side_sugar'][$i][$j][$k]) ? $finalSubSideAry['side_sugar'][$i][$j][$k] : '');
                        }
                    }
                    
                    $addon = [];
                    if(isset($finalSubAddonAry['addon_name'][$i][$j])) {
                        $addonName = $finalSubAddonAry['addon_name'][$i][$j];
                        foreach($addonName as $l => $addonNames) {
                            $addon[] = array(
                                'name'=>$finalSubAddonAry['addon_name'][$i][$j][$l],'category'=>$finalSubAddonAry['addon_category'][$i][$j][$l], 'price'=>isset($finalSubAddonAry['addon_price'][$i][$j][$l]) ? $finalSubAddonAry['addon_price'][$i][$j][$l] : '','gluten_free'=>isset($finalSubAddonAry['addon_gluten_free'][$i][$j][$l]) ? $finalSubAddonAry['addon_gluten_free'][$i][$j][$l] : '','kosher'=>isset($finalSubAddonAry['addon_kosher'][$i][$j][$l]) ? $finalSubAddonAry['addon_kosher'][$i][$j][$l] : '','halal'=>isset($finalSubAddonAry['addon_halal'][$i][$j][$l]) ? $finalSubAddonAry['addon_halal'][$i][$j][$l] : '','vegan'=>isset($finalSubAddonAry['addon_vegan'][$i][$j][$l]) ? $finalSubAddonAry['addon_vegan'][$i][$j][$l] : '','vegetarian'=>isset($finalSubAddonAry['addon_vegetarian'][$i][$j][$l]) ? $finalSubAddonAry['addon_vegetarian'][$i][$j][$l] : '','spicy'=>isset($finalSubAddonAry['addon_spicy'][$i][$j][$l]) ? $finalSubAddonAry['addon_spicy'][$i][$j][$l] : '','ocean_wise'=>isset($finalSubAddonAry['addon_ocean_wise'][$i][$j][$l]) ? $finalSubAddonAry['addon_ocean_wise'][$i][$j][$l] : '','msg'=>isset($finalSubAddonAry['addon_msg'][$i][$j][$l]) ? $finalSubAddonAry['addon_msg'][$i][$j][$l] : '','corn'=>isset($finalSubAddonAry['addon_corn'][$i][$j][$l]) ? $finalSubAddonAry['addon_corn'][$i][$j][$l] : '','peanuts'=>isset($finalSubAddonAry['addon_peanuts'][$i][$j][$l]) ? $finalSubAddonAry['addon_peanuts'][$i][$j][$l] : '','treenuts'=>isset($finalSubAddonAry['addon_treenuts'][$i][$j][$l]) ? $finalSubAddonAry['addon_treenuts'][$i][$j][$l] : '','sulfites'=>isset($finalSubAddonAry['addon_sulfites'][$i][$j][$l]) ? $finalSubAddonAry['addon_sulfites'][$i][$j][$l] : '','mustard'=>isset($finalSubAddonAry['addon_mustard'][$i][$j][$l]) ? $finalSubAddonAry['addon_mustard'][$i][$j][$l] : '','wheat'=>isset($finalSubAddonAry['addon_wheat'][$i][$j][$l]) ? $finalSubAddonAry['addon_wheat'][$i][$j][$l] : '','soy'=>isset($finalSubAddonAry['addon_soy'][$i][$j][$l]) ? $finalSubAddonAry['addon_soy'][$i][$j][$l] : '','seafood'=>isset($finalSubAddonAry['addon_seafood'][$i][$j][$l]) ? $finalSubAddonAry['addon_seafood'][$i][$j][$l] : '','garlic'=>isset($finalSubAddonAry['addon_garlic'][$i][$j][$l]) ? $finalSubAddonAry['addon_garlic'][$i][$j][$l] : '','eggs'=>isset($finalSubAddonAry['addon_eggs'][$i][$j][$l]) ? $finalSubAddonAry['addon_eggs'][$i][$j][$l] : '','tartrazine'=>isset($finalSubAddonAry['addon_tartrazine'][$i][$j][$l]) ? $finalSubAddonAry['addon_tartrazine'][$i][$j][$l] : '','onions'=>isset($finalSubAddonAry['addon_onions'][$i][$j][$l]) ? $finalSubAddonAry['addon_onions'][$i][$j][$l] : '','animal_fats_oils'=>isset($finalSubAddonAry['addon_animal_fats_oils'][$i][$j][$l]) ? $finalSubAddonAry['addon_animal_fats_oils'][$i][$j][$l] : '','shellfish'=>isset($finalSubAddonAry['addon_shellfish'][$i][$j][$l]) ? $finalSubAddonAry['addon_shellfish'][$i][$j][$l] : '','fish'=>isset($finalSubAddonAry['addon_fish'][$i][$j][$l]) ? $finalSubAddonAry['addon_fish'][$i][$j][$l] : '','sesama'=>isset($finalSubAddonAry['addon_sesama'][$i][$j][$l]) ? $finalSubAddonAry['addon_sesama'][$i][$j][$l] : '','dairy'=>isset($finalSubAddonAry['addon_dairy'][$i][$j][$l]) ? $finalSubAddonAry['addon_dairy'][$i][$j][$l] : '','saturated_fats'=>isset($finalSubAddonAry['addon_saturated_fats'][$i][$j][$l]) ? $finalSubAddonAry['addon_saturated_fats'][$i][$j][$l] : '','vitamin_a'=>isset($finalSubAddonAry['addon_vitamin_a'][$i][$j][$l]) ? $finalSubAddonAry['addon_vitamin_a'][$i][$j][$l] : '','carbs'=>isset($finalSubAddonAry['addon_carbs'][$i][$j][$l]) ? $finalSubAddonAry['addon_carbs'][$i][$j][$l] : '','vitamin_c'=>isset($finalSubAddonAry['addon_vitamin_c'][$i][$j][$l]) ? $finalSubAddonAry['addon_vitamin_c'][$i][$j][$l] : '','protein'=>isset($finalSubAddonAry['addon_protein'][$i][$j][$l]) ? $finalSubAddonAry['addon_protein'][$i][$j][$l] : '','fat'=>isset($finalSubAddonAry['addon_fat'][$i][$j][$l]) ? $finalSubAddonAry['addon_fat'][$i][$j][$l] : '','cholesterol'=>isset($finalSubAddonAry['addon_cholesterol'][$i][$j][$l]) ? $finalSubAddonAry['addon_cholesterol'][$i][$j][$l] : '','fiber'=>isset($finalSubAddonAry['addon_fiber'][$i][$j][$l]) ? $finalSubAddonAry['addon_fiber'][$i][$j][$l] : '','calcium'=>isset($finalSubAddonAry['addon_calcium'][$i][$j][$l]) ? $finalSubAddonAry['addon_calcium'][$i][$j][$l] : '','calories'=>isset($finalSubAddonAry['addon_calories'][$i][$j][$l]) ? $finalSubAddonAry['addon_calories'][$i][$j][$l] : '','sodium'=>isset($finalSubAddonAry['addon_sodium'][$i][$j][$l]) ? $finalSubAddonAry['addon_sodium'][$i][$j][$l] : '','trans_fat'=>isset($finalSubAddonAry['addon_trans_fat'][$i][$j][$l]) ? $finalSubAddonAry['addon_trans_fat'][$i][$j][$l] : '','iron'=>isset($finalSubAddonAry['addon_iron'][$i][$j][$l]) ? $finalSubAddonAry['addon_iron'][$i][$j][$l] : '','sugar'=>isset($finalSubAddonAry['addon_sugar'][$i][$j][$l]) ? $finalSubAddonAry['addon_sugar'][$i][$j][$l] : '');
                        }
                    }
                    
                    $variation=[];
                    if(isset($finalSubVariationAry['variation_name'][$i][$j])) {
                        $variationName = $finalSubVariationAry['variation_name'][$i][$j];
                        foreach($variationName as $m => $variationNames) {
                            $variation[] = array(
                                'name'=>isset($finalSubVariationAry['variation_name'][$i][$j][$m]) ? $finalSubVariationAry['variation_name'][$i][$j][$m] : '', 'category'=>isset($finalSubVariationAry['variation_category'][$i][$j][$m]) ? $finalSubVariationAry['variation_category'][$i][$j][$m] : '','price'=>isset($finalSubVariationAry['variation_price'][$i][$j][$m]) ? $finalSubVariationAry['variation_price'][$i][$j][$m] : '','gluten_free'=>isset($finalSubVariationAry['variation_gluten_free'][$i][$j][$m]) ? $finalSubVariationAry['variation_gluten_free'][$i][$j][$m] : '','kosher'=>isset($finalSubVariationAry['variation_kosher'][$i][$j][$m]) ? $finalSubVariationAry['variation_kosher'][$i][$j][$m] : '','halal'=>isset($finalSubVariationAry['variation_halal'][$i][$j][$m]) ? $finalSubVariationAry['variation_halal'][$i][$j][$m] : '','vegan'=>isset($finalSubVariationAry['variation_vegan'][$i][$j][$m]) ? $finalSubVariationAry['variation_vegan'][$i][$j][$m] : '','vegetarian'=>isset($finalSubVariationAry['variation_vegetarian'][$i][$j][$m]) ? $finalSubVariationAry['variation_vegetarian'][$i][$j][$m] : '','spicy'=>isset($finalSubVariationAry['variation_spicy'][$i][$j][$m]) ? $finalSubVariationAry['variation_spicy'][$i][$j][$m] : '','ocean_wise'=>isset($finalSubVariationAry['variation_ocean_wise'][$i][$j][$m]) ? $finalSubVariationAry['variation_ocean_wise'][$i][$j][$m] : '','msg'=>isset($finalSubVariationAry['variation_msg'][$i][$j][$m]) ? $finalSubVariationAry['variation_msg'][$i][$j][$m] : '','corn'=>isset($finalSubVariationAry['variation_corn'][$i][$j][$m]) ? $finalSubVariationAry['variation_corn'][$i][$j][$m] : '','peanuts'=>isset($finalSubVariationAry['variation_peanuts'][$i][$j][$m]) ? $finalSubVariationAry['variation_peanuts'][$i][$j][$m] : '','treenuts'=>isset($finalSubVariationAry['variation_treenuts'][$i][$j][$m]) ? $finalSubVariationAry['variation_treenuts'][$i][$j][$m] : '','sulfites'=>isset($finalSubVariationAry['variation_sulfites'][$i][$j][$m]) ? $finalSubVariationAry['variation_sulfites'][$i][$j][$m] : '','mustard'=>isset($finalSubVariationAry['variation_mustard'][$i][$j][$m]) ? $finalSubVariationAry['variation_mustard'][$i][$j][$m] : '','wheat'=>isset($finalSubVariationAry['variation_wheat'][$i][$j][$m]) ? $finalSubVariationAry['variation_wheat'][$i][$j][$m] : '','soy'=>isset($finalSubVariationAry['variation_soy'][$i][$j][$m]) ? $finalSubVariationAry['variation_soy'][$i][$j][$m] : '','seafood'=>isset($finalSubVariationAry['variation_seafood'][$i][$j][$m]) ? $finalSubVariationAry['variation_seafood'][$i][$j][$m] : '','garlic'=>isset($finalSubVariationAry['variation_garlic'][$i][$j][$m]) ? $finalSubVariationAry['variation_garlic'][$i][$j][$m] : '','eggs'=>isset($finalSubVariationAry['variation_eggs'][$i][$j][$m]) ? $finalSubVariationAry['variation_eggs'][$i][$j][$m] : '','tartrazine'=>isset($finalSubVariationAry['variation_tartrazine'][$i][$j][$m]) ? $finalSubVariationAry['variation_tartrazine'][$i][$j][$m] : '','onions'=>isset($finalSubVariationAry['variation_onions'][$i][$j][$m]) ? $finalSubVariationAry['variation_onions'][$i][$j][$m] : '','animal_fats_oils'=>isset($finalSubVariationAry['variation_animal_fats_oils'][$i][$j][$m]) ? $finalSubVariationAry['variation_animal_fats_oils'][$i][$j][$m] : '','shellfish'=>isset($finalSubVariationAry['variation_shellfish'][$i][$j][$m]) ? $finalSubVariationAry['variation_shellfish'][$i][$j][$m] : '','fish'=>isset($finalSubVariationAry['variation_fish'][$i][$j][$m]) ? $finalSubVariationAry['variation_fish'][$i][$j][$m] : '','sesama'=>isset($finalSubVariationAry['variation_sesama'][$i][$j][$m]) ? $finalSubVariationAry['variation_sesama'][$i][$j][$m] : '','dairy'=>isset($finalSubVariationAry['variation_dairy'][$i][$j][$m]) ? $finalSubVariationAry['variation_dairy'][$i][$j][$m] : '','saturated_fats'=>isset($finalSubVariationAry['variation_saturated_fats'][$i][$j][$m]) ? $finalSubVariationAry['variation_saturated_fats'][$i][$j][$m] : '','vitamin_a'=>isset($finalSubVariationAry['variation_vitamin_a'][$i][$j][$m]) ? $finalSubVariationAry['variation_vitamin_a'][$i][$j][$m] : '','carbs'=>isset($finalSubVariationAry['variation_carbs'][$i][$j][$m]) ? $finalSubVariationAry['variation_carbs'][$i][$j][$m] : '','vitamin_c'=>isset($finalSubVariationAry['variation_vitamin_c'][$i][$j][$m]) ? $finalSubVariationAry['variation_vitamin_c'][$i][$j][$m] : '','protein'=>isset($finalSubVariationAry['variation_protein'][$i][$j][$m]) ? $finalSubVariationAry['variation_protein'][$i][$j][$m] : '','fat'=>isset($finalSubVariationAry['variation_fat'][$i][$j][$m]) ? $finalSubVariationAry['variation_fat'][$i][$j][$m] : '','cholesterol'=>isset($finalSubVariationAry['variation_cholesterol'][$i][$j][$m]) ? $finalSubVariationAry['variation_cholesterol'][$i][$j][$m] : '','fiber'=>isset($finalSubVariationAry['variation_fiber'][$i][$j][$m]) ? $finalSubVariationAry['variation_fiber'][$i][$j][$m] : '','calcium'=>isset($finalSubVariationAry['variation_calcium'][$i][$j][$m]) ? $finalSubVariationAry['variation_calcium'][$i][$j][$m] : '','calories'=>isset($finalSubVariationAry['variation_calories'][$i][$j][$m]) ? $finalSubVariationAry['variation_calories'][$i][$j][$m] : '','sodium'=>isset($finalSubVariationAry['variation_sodium'][$i][$j][$m]) ? $finalSubVariationAry['variation_sodium'][$i][$j][$m] : '','trans_fat'=>isset($finalSubVariationAry['variation_trans_fat'][$i][$j][$m]) ? $finalSubVariationAry['variation_trans_fat'][$i][$j][$m] : '','iron'=>isset($finalSubVariationAry['variation_iron'][$i][$j][$m]) ? $finalSubVariationAry['variation_iron'][$i][$j][$m] : '','sugar'=>isset($finalSubVariationAry['variation_sugar'][$i][$j][$m]) ? $finalSubVariationAry['variation_sugar'][$i][$j][$m] : '');
                        }
                    }                    
                    
                    $topping=[];
                    if(isset($finalSubToppingAry['topping_name'][$i][$j])) {
                        $toppingName = $finalSubToppingAry['topping_name'][$i][$j];
                        foreach($toppingName as $n => $toppingNames) {
                            $topping[] = array(
                                'name'=>isset($finalSubToppingAry['topping_name'][$i][$j][$n]) ? $finalSubToppingAry['topping_name'][$i][$j][$n] : '', 'category'=>isset($finalSubToppingAry['topping_category'][$i][$j][$n]) ? $finalSubToppingAry['topping_category'][$i][$j][$n] : '','price'=>isset($finalSubToppingAry['topping_price'][$i][$j][$n]) ? $finalSubToppingAry['topping_price'][$i][$j][$n] : '','gluten_free'=>isset($finalSubToppingAry['topping_gluten_free'][$i][$j][$n]) ? $finalSubToppingAry['topping_gluten_free'][$i][$j][$n] : '','kosher'=>isset($finalSubToppingAry['topping_kosher'][$i][$j][$n]) ? $finalSubToppingAry['topping_kosher'][$i][$j][$n] : '','halal'=>isset($finalSubToppingAry['topping_halal'][$i][$j][$n]) ? $finalSubToppingAry['topping_halal'][$i][$j][$n] : '','vegan'=>isset($finalSubToppingAry['topping_vegan'][$i][$j][$n]) ? $finalSubToppingAry['topping_vegan'][$i][$j][$n] : '','vegetarian'=>isset($finalSubToppingAry['topping_vegetarian'][$i][$j][$n]) ? $finalSubToppingAry['topping_vegetarian'][$i][$j][$n] : '','spicy'=>isset($finalSubToppingAry['topping_spicy'][$i][$j][$n]) ? $finalSubToppingAry['topping_spicy'][$i][$j][$n] : '','ocean_wise'=>isset($finalSubToppingAry['topping_ocean_wise'][$i][$j][$n]) ? $finalSubToppingAry['topping_ocean_wise'][$i][$j][$n] : '','msg'=>isset($finalSubToppingAry['topping_msg'][$i][$j][$n]) ? $finalSubToppingAry['topping_msg'][$i][$j][$n] : '','corn'=>isset($finalSubToppingAry['topping_corn'][$i][$j][$n]) ? $finalSubToppingAry['topping_corn'][$i][$j][$n] : '','peanuts'=>isset($finalSubToppingAry['topping_peanuts'][$i][$j][$n]) ? $finalSubToppingAry['topping_peanuts'][$i][$j][$n] : '','treenuts'=>isset($finalSubToppingAry['topping_treenuts'][$i][$j][$n]) ? $finalSubToppingAry['topping_treenuts'][$i][$j][$n] : '','sulfites'=>isset($finalSubToppingAry['topping_sulfites'][$i][$j][$n]) ? $finalSubToppingAry['topping_sulfites'][$i][$j][$n] : '','mustard'=>isset($finalSubToppingAry['topping_mustard'][$i][$j][$n]) ? $finalSubToppingAry['topping_mustard'][$i][$j][$n] : '','wheat'=>isset($finalSubToppingAry['topping_wheat'][$i][$j][$n]) ? $finalSubToppingAry['topping_wheat'][$i][$j][$n] : '','soy'=>isset($finalSubToppingAry['topping_soy'][$i][$j][$n]) ? $finalSubToppingAry['topping_soy'][$i][$j][$n] : '','seafood'=>isset($finalSubToppingAry['topping_seafood'][$i][$j][$n]) ? $finalSubToppingAry['topping_seafood'][$i][$j][$n] : '','garlic'=>isset($finalSubToppingAry['topping_garlic'][$i][$j][$n]) ? $finalSubToppingAry['topping_garlic'][$i][$j][$n] : '','eggs'=>isset($finalSubToppingAry['topping_eggs'][$i][$j][$n]) ? $finalSubToppingAry['topping_eggs'][$i][$j][$n] : '','tartrazine'=>isset($finalSubToppingAry['topping_tartrazine'][$i][$j][$n]) ? $finalSubToppingAry['topping_tartrazine'][$i][$j][$n] : '','onions'=>isset($finalSubToppingAry['topping_onions'][$i][$j][$n]) ? $finalSubToppingAry['topping_onions'][$i][$j][$n] : '','animal_fats_oils'=>isset($finalSubToppingAry['topping_animal_fats_oils'][$i][$j][$n]) ? $finalSubToppingAry['topping_animal_fats_oils'][$i][$j][$n] : '','shellfish'=>isset($finalSubToppingAry['topping_shellfish'][$i][$j][$n]) ? $finalSubToppingAry['topping_shellfish'][$i][$j][$n] : '','fish'=>isset($finalSubToppingAry['topping_fish'][$i][$j][$n]) ? $finalSubToppingAry['topping_fish'][$i][$j][$n] : '','sesama'=>isset($finalSubToppingAry['topping_sesama'][$i][$j][$n]) ? $finalSubToppingAry['topping_sesama'][$i][$j][$n] : '','dairy'=>isset($finalSubToppingAry['topping_dairy'][$i][$j][$n]) ? $finalSubToppingAry['topping_dairy'][$i][$j][$n] : '','saturated_fats'=>isset($finalSubToppingAry['topping_saturated_fats'][$i][$j][$n]) ? $finalSubToppingAry['topping_saturated_fats'][$i][$j][$n] : '','vitamin_a'=>isset($finalSubToppingAry['topping_vitamin_a'][$i][$j][$n]) ? $finalSubToppingAry['topping_vitamin_a'][$i][$j][$n] : '','carbs'=>isset($finalSubToppingAry['topping_carbs'][$i][$j][$n]) ? $finalSubToppingAry['topping_carbs'][$i][$j][$n] : '','vitamin_c'=>isset($finalSubToppingAry['topping_vitamin_c'][$i][$j][$n]) ? $finalSubToppingAry['topping_vitamin_c'][$i][$j][$n] : '','protein'=>isset($finalSubToppingAry['topping_protein'][$i][$j][$n]) ? $finalSubToppingAry['topping_protein'][$i][$j][$n] : '','fat'=>isset($finalSubToppingAry['topping_fat'][$i][$j][$n]) ? $finalSubToppingAry['topping_fat'][$i][$j][$n] : '','cholesterol'=>isset($finalSubToppingAry['topping_cholesterol'][$i][$j][$n]) ? $finalSubToppingAry['topping_cholesterol'][$i][$j][$n] : '','fiber'=>isset($finalSubToppingAry['topping_fiber'][$i][$j][$n]) ? $finalSubToppingAry['topping_fiber'][$i][$j][$n] : '','calcium'=>isset($finalSubToppingAry['topping_calcium'][$i][$j][$n]) ? $finalSubToppingAry['topping_calcium'][$i][$j][$n] : '','calories'=>isset($finalSubToppingAry['topping_calories'][$i][$j][$n]) ? $finalSubToppingAry['topping_calories'][$i][$j][$n] : '','sodium'=>isset($finalSubToppingAry['topping_sodium'][$i][$j][$n]) ? $finalSubToppingAry['topping_sodium'][$i][$j][$n] : '','trans_fat'=>isset($finalSubToppingAry['topping_trans_fat'][$i][$j][$n]) ? $finalSubToppingAry['topping_trans_fat'][$i][$j][$n] : '','iron'=>isset($finalSubToppingAry['topping_iron'][$i][$j][$n]) ? $finalSubToppingAry['topping_iron'][$i][$j][$n] : '','sugar'=>isset($finalSubToppingAry['topping_sugar'][$i][$j][$n]) ? $finalSubToppingAry['topping_sugar'][$i][$j][$n] : '');
                        }
                    }
                    
                    /*$item[] = array('name'=>isset($finalItemAry['name'][$i][$j][0]) ? $finalItemAry['name'][$i][$j][0] : '', 'category'=>isset($finalItemAry['category'][$i][$j][0]) ? $finalItemAry['category'][$i][$j][0] : '','price'=>isset($finalItemAry['price'][$i][$j][0]) ? $finalItemAry['price'][$i][$j][0] : '', 'side'=>$side, 'topping'=>$topping);*/
                    $item[] = array(
                        'name'=>isset($finalItemAry['name'][$i][$j][0]) ? $finalItemAry['name'][$i][$j][0] : '', 'category'=>isset($finalItemAry['category'][$i][$j][0]) ? $finalItemAry['category'][$i][$j][0] : '','price'=>isset($finalItemAry['price'][$i][$j][0]) ? $finalItemAry['price'][$i][$j][0] : '','gluten_free'=>isset($finalItemAry['gluten_free'][$i][$j][0]) ? $finalItemAry['gluten_free'][$i][$j][0] : '','kosher'=>isset($finalItemAry['kosher'][$i][$j][0]) ? $finalItemAry['kosher'][$i][$j][0] : '','halal'=>isset($finalItemAry['halal'][$i][$j][0]) ? $finalItemAry['halal'][$i][$j][0] : '','vegan'=>isset($finalItemAry['vegan'][$i][$j][0]) ? $finalItemAry['vegan'][$i][$j][0] : '','vegetarian'=>isset($finalItemAry['vegetarian'][$i][$j][0]) ? $finalItemAry['vegetarian'][$i][$j][0] : '','spicy'=>isset($finalItemAry['spicy'][$i][$j][0]) ? $finalItemAry['spicy'][$i][$j][0] : '','ocean_wise'=>isset($finalItemAry['ocean_wise'][$i][$j][0]) ? $finalItemAry['ocean_wise'][$i][$j][0] : '','msg'=>isset($finalItemAry['msg'][$i][$j][0]) ? $finalItemAry['msg'][$i][$j][0] : '','corn'=>isset($finalItemAry['corn'][$i][$j][0]) ? $finalItemAry['corn'][$i][$j][0] : '','peanuts'=>isset($finalItemAry['peanuts'][$i][$j][0]) ? $finalItemAry['peanuts'][$i][$j][0] : '','treenuts'=>isset($finalItemAry['treenuts'][$i][$j][0]) ? $finalItemAry['treenuts'][$i][$j][0] : '','sulfites'=>isset($finalItemAry['sulfites'][$i][$j][0]) ? $finalItemAry['sulfites'][$i][$j][0] : '','mustard'=>isset($finalItemAry['mustard'][$i][$j][0]) ? $finalItemAry['mustard'][$i][$j][0] : '','wheat'=>isset($finalItemAry['wheat'][$i][$j][0]) ? $finalItemAry['wheat'][$i][$j][0] : '','soy'=>isset($finalItemAry['soy'][$i][$j][0]) ? $finalItemAry['soy'][$i][$j][0] : '','seafood'=>isset($finalItemAry['seafood'][$i][$j][0]) ? $finalItemAry['seafood'][$i][$j][0] : '','garlic'=>isset($finalItemAry['garlic'][$i][$j][0]) ? $finalItemAry['garlic'][$i][$j][0] : '','eggs'=>isset($finalItemAry['eggs'][$i][$j][0]) ? $finalItemAry['eggs'][$i][$j][0] : '','tartrazine'=>isset($finalItemAry['tartrazine'][$i][$j][0]) ? $finalItemAry['tartrazine'][$i][$j][0] : '','onions'=>isset($finalItemAry['onions'][$i][$j][0]) ? $finalItemAry['onions'][$i][$j][0] : '','animal_fats_oils'=>isset($finalItemAry['animal_fats_oils'][$i][$j][0]) ? $finalItemAry['animal_fats_oils'][$i][$j][0] : '','shellfish'=>isset($finalItemAry['shellfish'][$i][$j][0]) ? $finalItemAry['shellfish'][$i][$j][0] : '','fish'=>isset($finalItemAry['fish'][$i][$j][0]) ? $finalItemAry['fish'][$i][$j][0] : '','sesama'=>isset($finalItemAry['sesama'][$i][$j][0]) ? $finalItemAry['sesama'][$i][$j][0] : '','dairy'=>isset($finalItemAry['dairy'][$i][$j][0]) ? $finalItemAry['dairy'][$i][$j][0] : '','saturated_fats'=>isset($finalItemAry['saturated_fats'][$i][$j][0]) ? $finalItemAry['saturated_fats'][$i][$j][0] : '','vitamin_a'=>isset($finalItemAry['vitamin_a'][$i][$j][0]) ? $finalItemAry['vitamin_a'][$i][$j][0] : '','carbs'=>isset($finalItemAry['carbs'][$i][$j][0]) ? $finalItemAry['carbs'][$i][$j][0] : '','vitamin_c'=>isset($finalItemAry['vitamin_c'][$i][$j][0]) ? $finalItemAry['vitamin_c'][$i][$j][0] : '','protein'=>isset($finalItemAry['protein'][$i][$j][0]) ? $finalItemAry['protein'][$i][$j][0] : '','fat'=>isset($finalItemAry['fat'][$i][$j][0]) ? $finalItemAry['fat'][$i][$j][0] : '','cholesterol'=>isset($finalItemAry['cholesterol'][$i][$j][0]) ? $finalItemAry['cholesterol'][$i][$j][0] : '','fiber'=>isset($finalItemAry['fiber'][$i][$j][0]) ? $finalItemAry['fiber'][$i][$j][0] : '','calcium'=>isset($finalItemAry['calcium'][$i][$j][0]) ? $finalItemAry['calcium'][$i][$j][0] : '','calories'=>isset($finalItemAry['calories'][$i][$j][0]) ? $finalItemAry['calories'][$i][$j][0] : '','sodium'=>isset($finalItemAry['sodium'][$i][$j][0]) ? $finalItemAry['sodium'][$i][$j][0] : '','trans_fat'=>isset($finalItemAry['trans_fat'][$i][$j][0]) ? $finalItemAry['trans_fat'][$i][$j][0] : '','iron'=>isset($finalItemAry['iron'][$i][$j][0]) ? $finalItemAry['iron'][$i][$j][0] : '','sugar'=>isset($finalItemAry['sugar'][$i][$j][0]) ? $finalItemAry['sugar'][$i][$j][0] : '', 'side'=>$side, 'addon'=>$addon, 'variation'=>$variation, 'topping'=>$topping);

                }
            }
            $menuNameForDay = isset($menuName[$i]) ?$menuName[$i] : '';
            
            $monday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('1', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$tuesday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('2', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$wenesday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('3', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$thurday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('4', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$friday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('5', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$saturday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('6', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$sunday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('7', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';

            
            if(isset($menuNameForDay) && ($menuNameForDay != '')) {
                $main[$i] = array('name'=>$menuNameForDay, 
                'Monday' => $monday,
	    		'Tuesday' => $tuesday,
	    		'Wenesday' => $wenesday,
	    		'Thurday' => $thurday,
	    		'Friday' => $friday,
	    		'Saturday' => $saturday,
	    		'Sunday' => $sunday,
	    		'start_time'=>isset($finalMainTab1Ary['start_time'][$menuNameForDay]) ? $finalMainTab1Ary['start_time'][$menuNameForDay] : '',
	    		'end_time'=>isset($finalMainTab1Ary['end_time'][$menuNameForDay]) ? $finalMainTab1Ary['end_time'][$menuNameForDay] : '',
                'item'=>$item);
            }
        }
        $newmain = $this->mainJsonResponseSort($main);
        /*echo '<pre>';
        print_r($newmain);
        die;*/
    	
    	$jsonFileName = $this->generateJsonFile($newmain);
    	if(isset($_FILES) && !empty($_FILES)) {
    	    $uploadImg = $this->uploadMeanuImage($images, $imagesForBackendless, $menuName);
    	    
    	    $imgPostData = [];
    	    if(isset($uploadImg) && !empty($uploadImg)) {
    	        foreach($uploadImg as $key => $imgs) {
                    $customeImgAry = [];
                    if(isset($imgs) && !empty($imgs)) {
                        foreach($imgs as $key1 => $img) {
                            $customeImgAry[] = array('menuFile'=>$img['file_url'], 'name'=>$menuName[$key]);
                        }
                    }
                    $imgPostData[$key] = $customeImgAry;
                }
    	    }
            
            
            $decodeImgJson = [];
            if(isset($imgPostData) && !empty($imgPostData)) {
                foreach ($imgPostData as $key => $imgPostDatas) {
                    $menuImgUrl = 'https://api.backendless.com/C41FC229-743D-296A-FF29-480E1EC14D00/9975C2C2-F45E-76F2-FF55-6AAC872E6E00/data/bulk/RestaurantMenus';
                    $menuImg = curlPostFun($menuImgUrl, $imgPostDatas);
                    $decodeImgJson[$key] = json_decode($menuImg);
                }
            }
           
    	}
    	$resturantData = $this->getUserResturant();
    	
    	if(isset($resturantData) && !empty($resturantData) && isset($resturantData->restaurant) && !empty($resturantData->restaurant)) {
    	    
    	    $restaurantDetails = $resturantData->restaurant[0];
            $resturantObjectId = $restaurantDetails->objectId;

            $jsonUpdateUrl = 'https://api.backendless.com/C41FC229-743D-296A-FF29-480E1EC14D00/9975C2C2-F45E-76F2-FF55-6AAC872E6E00/data/Restaurants/'.$resturantObjectId;
            $postData = array('JSONfile' => $jsonFileName);
            $response = curlPutFun($jsonUpdateUrl, $postData);
            $decodeJson = json_decode($response);
            
            $oldImages = $this->getResturantImages($resturantObjectId);
            
            
            if(isset($decodeImgJson) && !empty($decodeImgJson)) {

                $singleArray = []; 
                foreach ($decodeImgJson as $childArray) 
                { 
                    if(isset($childArray) && !empty($childArray)) {
                        foreach ($childArray as $value) 
                        { 
                            $singleArray[] = $value; 
                        } 
                    }
                }
                if(isset($oldImages) && !empty($oldImages)) {
                    $oldImagesId = array_merge($oldImages, $singleArray);  
                } else {
                    $oldImagesId = $singleArray;  
                }
                $imageRes = $this->updateMenuNameId($oldImagesId, $resturantObjectId);
            }
    	}
    	
    	
        if($decodeJson) {
            return redirect()->route('admin.dashboard')->with('success','JSON File Mofified Successfully!');
        } else {
            return redirect()->route('admin.addrestaurant')->with('error','Something Went Wrong, Please Try Again!!');
        }
    }
    
    public function addrestaurant()
    {
        $startTime = date('h A');
        $endTime = date('h A', strtotime('+5 hours'));
        $exStart = explode(' ', $startTime);
        $start = $exStart[0].':00 '. $exStart[1];
        
        $exEnd = explode(' ', $endTime);
        $end = $exEnd[0].':00 '. $exEnd[1];
    	return view('admin/restaurant', compact('start','end'));
    }

    public function getBooleanValueOfDay($dayArys)
    {
    	$rer = array(
    		'Monday' => (in_array('1', $dayArys)) ? 'true' : 'false',
    		'Tuesday' => (in_array('2', $dayArys)) ? 'true' : 'false',
    		'Wenesday' => (in_array('3', $dayArys)) ? 'true' : 'false',
    		'Thurday' => (in_array('4', $dayArys)) ? 'true' : 'false',
    		'Friday' => (in_array('5', $dayArys)) ? 'true' : 'false',
    		'Saturday' => (in_array('6', $dayArys)) ? 'true' : 'false',
    		'Sunday' => (in_array('7', $dayArys)) ? 'true' : 'false'
    	);
    	return $rer;
    }

    public function getDayTimeByMenu($mainTab1Ary, $menuName)
    {
    	$main=[];
    	if(isset($mainTab1Ary) && !empty($mainTab1Ary)) {
    	   foreach ($mainTab1Ary as $key => $mainTab1Arys) {
        		$finalDay = [];
        		if(isset($menuName) && !empty($menuName)) {
        		    foreach($menuName as $key1=>$menuNames) {
        	    		$finalDay[$menuNames] = isset($mainTab1Arys[$key1]) ? $mainTab1Arys[$key1] : '';
        	    	}
        	    	$main[$key] = $finalDay;
        		}
        	} 
    	}
    	
    	return $main;
    }

    public function sortParentAry($commonArrayOfSections)
    {
    	$finalArray = [];
    	if(isset($commonArrayOfSections)) {
    		foreach ($commonArrayOfSections as $key => $commonArrayOfSection) {

	    		$initialAry = $commonArrayOfSection;

	    		$insideKeyAry = [];
	    		if(isset($commonArrayOfSection)) {
	    			foreach($commonArrayOfSection as $key1 => $commonArrayOfSectionss) {
		    			$insideKeyAry[] = $key1;
		    		}
		    		sort($insideKeyAry);
	    		}

	    		$sortResult=[];
	    		if(isset($insideKeyAry)) {
	    			foreach ($insideKeyAry as $insideKeyArys) {
			    		$sortResult[$insideKeyArys] = $initialAry[$insideKeyArys];
			    	}
			    	$finalArray[$key] = $sortResult;
	    		}
	    	}
    	}

    	return $finalArray;
    }
    
     public function sortSubParentAry($commonArrayOfSections)
    {
    	$finalArray = [];
    	$res = [];
    	if(isset($commonArrayOfSections)) {
    		foreach ($commonArrayOfSections as $key => $commonArrayOfSection) {

    			foreach ($commonArrayOfSection as $key1 => $subAry) {
    				$initialAry = $subAry;

    				$insideSubKeyAry = [];
		    		if(isset($subAry)) {
		    			foreach($subAry as $key2 => $subArys) {
			    			$insideSubKeyAry[] = $key2;
			    		}
			    		sort($insideSubKeyAry);
		    		}

		    		if(isset($insideSubKeyAry) && !empty($insideSubKeyAry)) {
		    			foreach($insideSubKeyAry as $key3=>$insideSubKeyArys) {
			    			$res[$key][$key1][$insideSubKeyArys] =  $initialAry[$insideSubKeyArys];
			    		}
		    		}
		    		
    			}
	    	}
	    }
	    return $res;
    }
    
    


    public function submitrestaurant(Request $request)
    {
        $images = $request->file('menu_image');
        $imagesForBackendless = $_FILES['menu_image'];
        
    	$main = array();
    	$menuName = $request->get('menu_name');

    	$mainTab1Ary = array('day'=>$request->get('day'),
    						'start_time'=>$request->get('start_time'),
    						'end_time'=>$request->get('end_time'));
    	$finalMainTab1Ary = $this->getDayTimeByMenu($mainTab1Ary, $menuName);

    	//sort($menuName);

    	$itemAry = array('name'=>$request->get('name'),'category'=>$request->get('category'),'price'=>$request->get('price'),'gluten_free'=>$request->get('gluten_free'),'kosher'=>$request->get('kosher'),'halal'=>$request->get('halal'),'vegan'=>$request->get('vegan'),'vegetarian'=>$request->get('vegetarian'),'spicy'=>$request->get('spicy'),'ocean_wise'=>$request->get('ocean_wise'),'msg'=>$request->get('msg'),'corn'=>$request->get('corn'),'peanuts'=>$request->get('peanuts'),'treenuts'=>$request->get('treenuts'), 'sulfites'=>$request->get('sulfites'), 'mustard'=>$request->get('mustard'), 'wheat'=>$request->get('wheat'), 'soy'=>$request->get('soy'), 'seafood'=>$request->get('seafood'), 'garlic'=>$request->get('garlic'), 'eggs'=>$request->get('eggs'), 'tartrazine'=>$request->get('tartrazine'), 'onions'=>$request->get('onions'), 'animal_fats_oils'=>$request->get('animal_fats_oils'), 'shellfish'=>$request->get('shellfish'), 'fish'=>$request->get('fish'), 'sesama'=>$request->get('sesama'), 'dairy'=>$request->get('dairy'), 'saturated_fats'=>$request->get('saturated_fats'), 'vitamin_a'=>$request->get('vitamin_a'), 'carbs'=>$request->get('carbs'), 'vitamin_c'=>$request->get('vitamin_c'), 'protein'=>$request->get('protein'), 'fat'=>$request->get('fat'), 'cholesterol'=>$request->get('cholesterol'), 'fiber'=>$request->get('fiber'), 'calcium'=>$request->get('calcium'), 'calories'=>$request->get('calories'), 'sodium'=>$request->get('sodium'), 'trans_fat'=>$request->get('trans_fat'), 'iron'=>$request->get('iron'), 'sugar'=>$request->get('sugar'));
    	$finalItemAry = $this->sortParentAry($itemAry);


    	$sideAry = array('side_standard'=>$request->get('side_standard'),'side_name'=>$request->get('side_name'),'side_category'=>$request->get('side_category'),'side_price'=>$request->get('side_price'),'side_gluten_free'=>$request->get('side_gluten_free'),'side_kosher'=>$request->get('side_kosher'),'side_halal'=>$request->get('side_halal'),'side_vegan'=>$request->get('side_vegan'),'side_vegetarian'=>$request->get('side_vegetarian'),'side_spicy'=>$request->get('side_spicy'),'side_ocean_wise'=>$request->get('side_ocean_wise'),'side_msg'=>$request->get('side_msg'),'side_corn'=>$request->get('side_corn'),'side_peanuts'=>$request->get('side_peanuts'),'side_treenuts'=>$request->get('side_treenuts'), 'side_sulfites'=>$request->get('side_sulfites'), 'side_mustard'=>$request->get('side_mustard'), 'side_wheat'=>$request->get('side_wheat'), 'side_soy'=>$request->get('side_soy'), 'side_seafood'=>$request->get('side_seafood'), 'side_garlic'=>$request->get('side_garlic'), 'side_eggs'=>$request->get('side_eggs'), 'side_tartrazine'=>$request->get('side_tartrazine'), 'side_onions'=>$request->get('side_onions'), 'side_animal_fats_oils'=>$request->get('side_animal_fats_oils'), 'side_shellfish'=>$request->get('side_shellfish'), 'side_fish'=>$request->get('side_fish'), 'side_sesama'=>$request->get('side_sesama'), 'side_dairy'=>$request->get('side_dairy'), 'side_saturated_fats'=>$request->get('side_saturated_fats'), 'side_vitamin_a'=>$request->get('side_vitamin_a'), 'side_carbs'=>$request->get('side_carbs'), 'side_vitamin_c'=>$request->get('side_vitamin_c'), 'side_protein'=>$request->get('side_protein'), 'side_fat'=>$request->get('side_fat'), 'side_cholesterol'=>$request->get('side_cholesterol'), 'side_fiber'=>$request->get('side_fiber'), 'side_calcium'=>$request->get('side_calcium'), 'side_calories'=>$request->get('side_calories'), 'side_sodium'=>$request->get('side_sodium'), 'side_trans_fat'=>$request->get('side_trans_fat'), 'side_iron'=>$request->get('side_iron'), 'side_sugar'=>$request->get('side_sugar'));
    	$finalSideAry = $this->sortParentAry($sideAry);
    	$finalSubSideAry = $this->sortSubParentAry($finalSideAry);


    	$addonAry = array('addon_name'=>$request->get('addon_name'),'addon_category'=>$request->get('addon_category'),'addon_price'=>$request->get('addon_price'),'addon_gluten_free'=>$request->get('addon_gluten_free'),'addon_kosher'=>$request->get('addon_kosher'),'addon_halal'=>$request->get('addon_halal'),'addon_vegan'=>$request->get('addon_vegan'),'addon_vegetarian'=>$request->get('addon_vegetarian'),'addon_spicy'=>$request->get('addon_spicy'),'addon_ocean_wise'=>$request->get('addon_ocean_wise'),'addon_msg'=>$request->get('addon_msg'),'addon_corn'=>$request->get('addon_corn'),'addon_peanuts'=>$request->get('addon_peanuts'),'addon_treenuts'=>$request->get('addon_treenuts'), 'addon_sulfites'=>$request->get('addon_sulfites'), 'addon_mustard'=>$request->get('addon_mustard'), 'addon_wheat'=>$request->get('addon_wheat'), 'addon_soy'=>$request->get('addon_soy'), 'addon_seafood'=>$request->get('addon_seafood'), 'addon_garlic'=>$request->get('addon_garlic'), 'addon_eggs'=>$request->get('addon_eggs'), 'addon_tartrazine'=>$request->get('addon_tartrazine'), 'addon_onions'=>$request->get('addon_onions'), 'addon_animal_fats_oils'=>$request->get('addon_animal_fats_oils'), 'addon_shellfish'=>$request->get('addon_shellfish'), 'addon_fish'=>$request->get('addon_fish'), 'addon_sesama'=>$request->get('addon_sesama'), 'addon_dairy'=>$request->get('addon_dairy'), 'addon_saturated_fats'=>$request->get('addon_saturated_fats'), 'addon_vitamin_a'=>$request->get('addon_vitamin_a'), 'addon_carbs'=>$request->get('addon_carbs'), 'addon_vitamin_c'=>$request->get('addon_vitamin_c'), 'addon_protein'=>$request->get('addon_protein'), 'addon_fat'=>$request->get('addon_fat'), 'addon_cholesterol'=>$request->get('addon_cholesterol'), 'addon_fiber'=>$request->get('addon_fiber'), 'addon_calcium'=>$request->get('addon_calcium'), 'addon_calories'=>$request->get('addon_calories'), 'addon_sodium'=>$request->get('addon_sodium'), 'addon_trans_fat'=>$request->get('addon_trans_fat'), 'addon_iron'=>$request->get('addon_iron'), 'addon_sugar'=>$request->get('addon_sugar'));
    	$finalAddonAry = $this->sortParentAry($addonAry);
    	$finalSubAddonAry = $this->sortSubParentAry($finalAddonAry);


    	$variationAry = array('variation_name'=>$request->get('variation_name'),'variation_category'=>$request->get('variation_category'),'variation_price'=>$request->get('variation_price'),'variation_gluten_free'=>$request->get('variation_gluten_free'),'variation_kosher'=>$request->get('variation_kosher'),'variation_halal'=>$request->get('variation_halal'),'variation_vegan'=>$request->get('variation_vegan'),'variation_vegetarian'=>$request->get('variation_vegetarian'),'variation_spicy'=>$request->get('variation_spicy'),'variation_ocean_wise'=>$request->get('variation_ocean_wise'),'variation_msg'=>$request->get('variation_msg'),'variation_corn'=>$request->get('variation_corn'),'variation_peanuts'=>$request->get('variation_peanuts'),'variation_treenuts'=>$request->get('variation_treenuts'), 'variation_sulfites'=>$request->get('variation_sulfites'), 'variation_mustard'=>$request->get('variation_mustard'), 'variation_wheat'=>$request->get('variation_wheat'), 'variation_soy'=>$request->get('variation_soy'), 'variation_seafood'=>$request->get('variation_seafood'), 'variation_garlic'=>$request->get('variation_garlic'), 'variation_eggs'=>$request->get('variation_eggs'), 'variation_tartrazine'=>$request->get('variation_tartrazine'), 'variation_onions'=>$request->get('variation_onions'), 'variation_animal_fats_oils'=>$request->get('variation_animal_fats_oils'), 'variation_shellfish'=>$request->get('variation_shellfish'), 'variation_fish'=>$request->get('variation_fish'), 'variation_sesama'=>$request->get('variation_sesama'), 'variation_dairy'=>$request->get('variation_dairy'), 'variation_saturated_fats'=>$request->get('variation_saturated_fats'), 'variation_vitamin_a'=>$request->get('variation_vitamin_a'), 'variation_carbs'=>$request->get('variation_carbs'), 'variation_vitamin_c'=>$request->get('variation_vitamin_c'), 'variation_protein'=>$request->get('variation_protein'), 'variation_fat'=>$request->get('variation_fat'), 'variation_cholesterol'=>$request->get('variation_cholesterol'), 'variation_fiber'=>$request->get('variation_fiber'), 'variation_calcium'=>$request->get('variation_calcium'), 'variation_calories'=>$request->get('variation_calories'), 'variation_sodium'=>$request->get('variation_sodium'), 'variation_trans_fat'=>$request->get('variation_trans_fat'), 'variation_iron'=>$request->get('variation_iron'), 'variation_sugar'=>$request->get('variation_sugar'));
    	$finalVariationAry = $this->sortParentAry($variationAry);
    	$finalSubVariationAry = $this->sortSubParentAry($finalVariationAry);


    	$toppingAry = array('topping_name'=>$request->get('topping_name'),'topping_category'=>$request->get('topping_category'),'topping_price'=>$request->get('topping_price'),'topping_gluten_free'=>$request->get('topping_gluten_free'),'topping_kosher'=>$request->get('topping_kosher'),'topping_halal'=>$request->get('topping_halal'),'topping_vegan'=>$request->get('topping_vegan'),'topping_vegetarian'=>$request->get('topping_vegetarian'),'topping_spicy'=>$request->get('topping_spicy'),'topping_ocean_wise'=>$request->get('topping_ocean_wise'),'topping_msg'=>$request->get('topping_msg'),'topping_corn'=>$request->get('topping_corn'),'topping_peanuts'=>$request->get('topping_peanuts'),'topping_treenuts'=>$request->get('topping_treenuts'), 'topping_sulfites'=>$request->get('topping_sulfites'), 'topping_mustard'=>$request->get('topping_mustard'), 'topping_wheat'=>$request->get('topping_wheat'), 'topping_soy'=>$request->get('topping_soy'), 'topping_seafood'=>$request->get('topping_seafood'), 'topping_garlic'=>$request->get('topping_garlic'), 'topping_eggs'=>$request->get('topping_eggs'), 'topping_tartrazine'=>$request->get('topping_tartrazine'), 'topping_onions'=>$request->get('topping_onions'), 'topping_animal_fats_oils'=>$request->get('topping_animal_fats_oils'), 'topping_shellfish'=>$request->get('topping_shellfish'), 'topping_fish'=>$request->get('topping_fish'), 'topping_sesama'=>$request->get('topping_sesama'), 'topping_dairy'=>$request->get('topping_dairy'), 'topping_saturated_fats'=>$request->get('topping_saturated_fats'), 'topping_vitamin_a'=>$request->get('topping_vitamin_a'), 'topping_carbs'=>$request->get('topping_carbs'), 'topping_vitamin_c'=>$request->get('topping_vitamin_c'), 'topping_protein'=>$request->get('topping_protein'), 'topping_fat'=>$request->get('topping_fat'), 'topping_cholesterol'=>$request->get('topping_cholesterol'), 'topping_fiber'=>$request->get('topping_fiber'), 'topping_calcium'=>$request->get('topping_calcium'), 'topping_calories'=>$request->get('topping_calories'), 'topping_sodium'=>$request->get('topping_sodium'), 'topping_trans_fat'=>$request->get('topping_trans_fat'), 'topping_iron'=>$request->get('topping_iron'), 'topping_sugar'=>$request->get('topping_sugar'));
    	$finalToppingAry = $this->sortParentAry($toppingAry);
    	$finalSubToppingAry = $this->sortSubParentAry($finalToppingAry);


    	$main = [];
    	for($i=0; $i<count($menuName); $i++) {

    		$item = [];
    		if(isset($finalItemAry['name'][$i])) {
    			$itemCount = count($finalItemAry['name'][$i]);
	    		for($j=0; $j<$itemCount; $j++) {

	    			$side=array();
	    			if(isset($finalSubSideAry['side_standard'][$i][$j])) {
	    				for($k=0; $k<count($finalSubSideAry['side_standard'][$i][$j]); $k++) {
			    			$side[] = array('standard'=>$finalSubSideAry['side_standard'][$i][$j][$k], 'name'=>isset($finalSubSideAry['side_name'][$i][$j][$k]) ? $finalSubSideAry['side_name'][$i][$j][$k] : '', 'category'=>isset($finalSubSideAry['side_category'][$i][$j][$k]) ? $finalSubSideAry['side_category'][$i][$j][$k] : '','price'=>isset($finalSubSideAry['side_price'][$i][$j][$k]) ? $finalSubSideAry['side_price'][$i][$j][$k] : '','gluten_free'=>isset($finalSubSideAry['side_gluten_free'][$i][$j][$k]) ? $finalSubSideAry['side_gluten_free'][$i][$j][$k] : '','kosher'=>isset($finalSubSideAry['side_kosher'][$i][$j][$k]) ? $finalSubSideAry['side_kosher'][$i][$j][$k] : '','halal'=>isset($finalSubSideAry['side_halal'][$i][$j][$k]) ? $finalSubSideAry['side_halal'][$i][$j][$k] : '','vegan'=>isset($finalSubSideAry['side_vegan'][$i][$j][$k]) ? $finalSubSideAry['side_vegan'][$i][$j][$k] : '','vegetarian'=>isset($finalSubSideAry['side_vegetarian'][$i][$j][$k]) ? $finalSubSideAry['side_vegetarian'][$i][$j][$k] : '','spicy'=>isset($finalSubSideAry['side_spicy'][$i][$j][$k]) ? $finalSubSideAry['side_spicy'][$i][$j][$k] : '','ocean_wise'=>isset($finalSubSideAry['side_ocean_wise'][$i][$j][$k]) ? $finalSubSideAry['side_ocean_wise'][$i][$j][$k] : '','msg'=>isset($finalSubSideAry['side_msg'][$i][$j][$k]) ? $finalSubSideAry['side_msg'][$i][$j][$k] : '','corn'=>isset($finalSubSideAry['side_corn'][$i][$j][$k]) ? $finalSubSideAry['side_corn'][$i][$j][$k] : '','peanuts'=>isset($finalSubSideAry['side_peanuts'][$i][$j][$k]) ? $finalSubSideAry['side_peanuts'][$i][$j][$k] : '','treenuts'=>isset($finalSubSideAry['side_treenuts'][$i][$j][$k]) ? $finalSubSideAry['side_treenuts'][$i][$j][$k] : '','sulfites'=>isset($finalSubSideAry['side_sulfites'][$i][$j][$k]) ? $finalSubSideAry['side_sulfites'][$i][$j][$k] : '','mustard'=>isset($finalSubSideAry['side_mustard'][$i][$j][$k]) ? $finalSubSideAry['side_mustard'][$i][$j][$k] : '','wheat'=>isset($finalSubSideAry['side_wheat'][$i][$j][$k]) ? $finalSubSideAry['side_wheat'][$i][$j][$k] : '','soy'=>isset($finalSubSideAry['side_soy'][$i][$j][$k]) ? $finalSubSideAry['side_soy'][$i][$j][$k] : '','seafood'=>isset($finalSubSideAry['side_seafood'][$i][$j][$k]) ? $finalSubSideAry['side_seafood'][$i][$j][$k] : '','garlic'=>isset($finalSubSideAry['side_garlic'][$i][$j][$k]) ? $finalSubSideAry['side_garlic'][$i][$j][$k] : '','eggs'=>isset($finalSubSideAry['side_eggs'][$i][$j][$k]) ? $finalSubSideAry['side_eggs'][$i][$j][$k] : '','tartrazine'=>isset($finalSubSideAry['side_tartrazine'][$i][$j][$k]) ? $finalSubSideAry['side_tartrazine'][$i][$j][$k] : '','onions'=>isset($finalSubSideAry['side_onions'][$i][$j][$k]) ? $finalSubSideAry['side_onions'][$i][$j][$k] : '','animal_fats_oils'=>isset($finalSubSideAry['side_animal_fats_oils'][$i][$j][$k]) ? $finalSubSideAry['side_animal_fats_oils'][$i][$j][$k] : '','shellfish'=>isset($finalSubSideAry['side_shellfish'][$i][$j][$k]) ? $finalSubSideAry['side_shellfish'][$i][$j][$k] : '','fish'=>isset($finalSubSideAry['side_fish'][$i][$j][$k]) ? $finalSubSideAry['side_fish'][$i][$j][$k] : '','sesama'=>isset($finalSubSideAry['side_sesama'][$i][$j][$k]) ? $finalSubSideAry['side_sesama'][$i][$j][$k] : '','dairy'=>isset($finalSubSideAry['side_dairy'][$i][$j][$k]) ? $finalSubSideAry['side_dairy'][$i][$j][$k] : '','saturated_fats'=>isset($finalSubSideAry['side_saturated_fats'][$i][$j][$k]) ? $finalSubSideAry['side_saturated_fats'][$i][$j][$k] : '','vitamin_a'=>isset($finalSubSideAry['side_vitamin_a'][$i][$j][$k]) ? $finalSubSideAry['side_vitamin_a'][$i][$j][$k] : '','carbs'=>isset($finalSubSideAry['side_carbs'][$i][$j][$k]) ? $finalSubSideAry['side_carbs'][$i][$j][$k] : '','vitamin_c'=>isset($finalSubSideAry['side_vitamin_c'][$i][$j][$k]) ? $finalSubSideAry['side_vitamin_c'][$i][$j][$k] : '','protein'=>isset($finalSubSideAry['side_protein'][$i][$j][$k]) ? $finalSubSideAry['side_protein'][$i][$j][$k] : '','fat'=>isset($finalSubSideAry['side_fat'][$i][$j][$k]) ? $finalSubSideAry['side_fat'][$i][$j][$k] : '','cholesterol'=>isset($finalSubSideAry['side_cholesterol'][$i][$j][$k]) ? $finalSubSideAry['side_cholesterol'][$i][$j][$k] : '','fiber'=>isset($finalSubSideAry['side_fiber'][$i][$j][$k]) ? $finalSubSideAry['side_fiber'][$i][$j][$k] : '','calcium'=>isset($finalSubSideAry['side_calcium'][$i][$j][$k]) ? $finalSubSideAry['side_calcium'][$i][$j][$k] : '','calories'=>isset($finalSubSideAry['side_calories'][$i][$j][$k]) ? $finalSubSideAry['side_calories'][$i][$j][$k] : '','sodium'=>isset($finalSubSideAry['side_sodium'][$i][$j][$k]) ? $finalSubSideAry['side_sodium'][$i][$j][$k] : '','trans_fat'=>isset($finalSubSideAry['side_trans_fat'][$i][$j][$k]) ? $finalSubSideAry['side_trans_fat'][$i][$j][$k] : '','iron'=>isset($finalSubSideAry['side_iron'][$i][$j][$k]) ? $finalSubSideAry['side_iron'][$i][$j][$k] : '','sugar'=>isset($finalSubSideAry['side_sugar'][$i][$j][$k]) ? $finalSubSideAry['side_sugar'][$i][$j][$k] : '');
			    		}
	    			}

	    			$addon=array();
		    		if(isset($finalSubAddonAry['addon_name'][$i][$j])){
			    		for($l=0; $l<count($finalSubAddonAry['addon_name'][$i][$j]); $l++) {
			    			$addon[] = array('name'=>$finalSubAddonAry['addon_name'][$i][$j][$l],'category'=>$finalSubAddonAry['addon_category'][$i][$j][$l], 'price'=>isset($finalSubAddonAry['addon_price'][$i][$j][$l]) ? $finalSubAddonAry['addon_price'][$i][$j][$l] : '','gluten_free'=>isset($finalSubAddonAry['addon_gluten_free'][$i][$j][$l]) ? $finalSubAddonAry['addon_gluten_free'][$i][$j][$l] : '','kosher'=>isset($finalSubAddonAry['addon_kosher'][$i][$j][$l]) ? $finalSubAddonAry['addon_kosher'][$i][$j][$l] : '','halal'=>isset($finalSubAddonAry['addon_halal'][$i][$j][$l]) ? $finalSubAddonAry['addon_halal'][$i][$j][$l] : '','vegan'=>isset($finalSubAddonAry['addon_vegan'][$i][$j][$l]) ? $finalSubAddonAry['addon_vegan'][$i][$j][$l] : '','vegetarian'=>isset($finalSubAddonAry['addon_vegetarian'][$i][$j][$l]) ? $finalSubAddonAry['addon_vegetarian'][$i][$j][$l] : '','spicy'=>isset($finalSubAddonAry['addon_spicy'][$i][$j][$l]) ? $finalSubAddonAry['addon_spicy'][$i][$j][$l] : '','ocean_wise'=>isset($finalSubAddonAry['addon_ocean_wise'][$i][$j][$l]) ? $finalSubAddonAry['addon_ocean_wise'][$i][$j][$l] : '','msg'=>isset($finalSubAddonAry['addon_msg'][$i][$j][$l]) ? $finalSubAddonAry['addon_msg'][$i][$j][$l] : '','corn'=>isset($finalSubAddonAry['addon_corn'][$i][$j][$l]) ? $finalSubAddonAry['addon_corn'][$i][$j][$l] : '','peanuts'=>isset($finalSubAddonAry['addon_peanuts'][$i][$j][$l]) ? $finalSubAddonAry['addon_peanuts'][$i][$j][$l] : '','treenuts'=>isset($finalSubAddonAry['addon_treenuts'][$i][$j][$l]) ? $finalSubAddonAry['addon_treenuts'][$i][$j][$l] : '','sulfites'=>isset($finalSubAddonAry['addon_sulfites'][$i][$j][$l]) ? $finalSubAddonAry['addon_sulfites'][$i][$j][$l] : '','mustard'=>isset($finalSubAddonAry['addon_mustard'][$i][$j][$l]) ? $finalSubAddonAry['addon_mustard'][$i][$j][$l] : '','wheat'=>isset($finalSubAddonAry['addon_wheat'][$i][$j][$l]) ? $finalSubAddonAry['addon_wheat'][$i][$j][$l] : '','soy'=>isset($finalSubAddonAry['addon_soy'][$i][$j][$l]) ? $finalSubAddonAry['addon_soy'][$i][$j][$l] : '','seafood'=>isset($finalSubAddonAry['addon_seafood'][$i][$j][$l]) ? $finalSubAddonAry['addon_seafood'][$i][$j][$l] : '','garlic'=>isset($finalSubAddonAry['addon_garlic'][$i][$j][$l]) ? $finalSubAddonAry['addon_garlic'][$i][$j][$l] : '','eggs'=>isset($finalSubAddonAry['addon_eggs'][$i][$j][$l]) ? $finalSubAddonAry['addon_eggs'][$i][$j][$l] : '','tartrazine'=>isset($finalSubAddonAry['addon_tartrazine'][$i][$j][$l]) ? $finalSubAddonAry['addon_tartrazine'][$i][$j][$l] : '','onions'=>isset($finalSubAddonAry['addon_onions'][$i][$j][$l]) ? $finalSubAddonAry['addon_onions'][$i][$j][$l] : '','animal_fats_oils'=>isset($finalSubAddonAry['addon_animal_fats_oils'][$i][$j][$l]) ? $finalSubAddonAry['addon_animal_fats_oils'][$i][$j][$l] : '','shellfish'=>isset($finalSubAddonAry['addon_shellfish'][$i][$j][$l]) ? $finalSubAddonAry['addon_shellfish'][$i][$j][$l] : '','fish'=>isset($finalSubAddonAry['addon_fish'][$i][$j][$l]) ? $finalSubAddonAry['addon_fish'][$i][$j][$l] : '','sesama'=>isset($finalSubAddonAry['addon_sesama'][$i][$j][$l]) ? $finalSubAddonAry['addon_sesama'][$i][$j][$l] : '','dairy'=>isset($finalSubAddonAry['addon_dairy'][$i][$j][$l]) ? $finalSubAddonAry['addon_dairy'][$i][$j][$l] : '','saturated_fats'=>isset($finalSubAddonAry['addon_saturated_fats'][$i][$j][$l]) ? $finalSubAddonAry['addon_saturated_fats'][$i][$j][$l] : '','vitamin_a'=>isset($finalSubAddonAry['addon_vitamin_a'][$i][$j][$l]) ? $finalSubAddonAry['addon_vitamin_a'][$i][$j][$l] : '','carbs'=>isset($finalSubAddonAry['addon_carbs'][$i][$j][$l]) ? $finalSubAddonAry['addon_carbs'][$i][$j][$l] : '','vitamin_c'=>isset($finalSubAddonAry['addon_vitamin_c'][$i][$j][$l]) ? $finalSubAddonAry['addon_vitamin_c'][$i][$j][$l] : '','protein'=>isset($finalSubAddonAry['addon_protein'][$i][$j][$l]) ? $finalSubAddonAry['addon_protein'][$i][$j][$l] : '','fat'=>isset($finalSubAddonAry['addon_fat'][$i][$j][$l]) ? $finalSubAddonAry['addon_fat'][$i][$j][$l] : '','cholesterol'=>isset($finalSubAddonAry['addon_cholesterol'][$i][$j][$l]) ? $finalSubAddonAry['addon_cholesterol'][$i][$j][$l] : '','fiber'=>isset($finalSubAddonAry['addon_fiber'][$i][$j][$l]) ? $finalSubAddonAry['addon_fiber'][$i][$j][$l] : '','calcium'=>isset($finalSubAddonAry['addon_calcium'][$i][$j][$l]) ? $finalSubAddonAry['addon_calcium'][$i][$j][$l] : '','calories'=>isset($finalSubAddonAry['addon_calories'][$i][$j][$l]) ? $finalSubAddonAry['addon_calories'][$i][$j][$l] : '','sodium'=>isset($finalSubAddonAry['addon_sodium'][$i][$j][$l]) ? $finalSubAddonAry['addon_sodium'][$i][$j][$l] : '','trans_fat'=>isset($finalSubAddonAry['addon_trans_fat'][$i][$j][$l]) ? $finalSubAddonAry['addon_trans_fat'][$i][$j][$l] : '','iron'=>isset($finalSubAddonAry['addon_iron'][$i][$j][$l]) ? $finalSubAddonAry['addon_iron'][$i][$j][$l] : '','sugar'=>isset($finalSubAddonAry['addon_sugar'][$i][$j][$l]) ? $finalSubAddonAry['addon_sugar'][$i][$j][$l] : '');
			    		}
			    	}

			    	$variation=array();
		    		if(isset($finalSubVariationAry['variation_name'][$i][$j])){
			    		for($m=0; $m<count($finalSubVariationAry['variation_name'][$i][$j]); $m++) {
			    			$variation[] = array('name'=>isset($finalSubVariationAry['variation_name'][$i][$j][$m]) ? $finalSubVariationAry['variation_name'][$i][$j][$m] : '', 'category'=>isset($finalSubVariationAry['variation_category'][$i][$j][$m]) ? $finalSubVariationAry['variation_category'][$i][$j][$m] : '','price'=>isset($finalSubVariationAry['variation_price'][$i][$j][$m]) ? $finalSubVariationAry['variation_price'][$i][$j][$m] : '','gluten_free'=>isset($finalSubVariationAry['variation_gluten_free'][$i][$j][$m]) ? $finalSubVariationAry['variation_gluten_free'][$i][$j][$m] : '','kosher'=>isset($finalSubVariationAry['variation_kosher'][$i][$j][$m]) ? $finalSubVariationAry['variation_kosher'][$i][$j][$m] : '','halal'=>isset($finalSubVariationAry['variation_halal'][$i][$j][$m]) ? $finalSubVariationAry['variation_halal'][$i][$j][$m] : '','vegan'=>isset($finalSubVariationAry['variation_vegan'][$i][$j][$m]) ? $finalSubVariationAry['variation_vegan'][$i][$j][$m] : '','vegetarian'=>isset($finalSubVariationAry['variation_vegetarian'][$i][$j][$m]) ? $finalSubVariationAry['variation_vegetarian'][$i][$j][$m] : '','spicy'=>isset($finalSubVariationAry['variation_spicy'][$i][$j][$m]) ? $finalSubVariationAry['variation_spicy'][$i][$j][$m] : '','ocean_wise'=>isset($finalSubVariationAry['variation_ocean_wise'][$i][$j][$m]) ? $finalSubVariationAry['variation_ocean_wise'][$i][$j][$m] : '','msg'=>isset($finalSubVariationAry['variation_msg'][$i][$j][$m]) ? $finalSubVariationAry['variation_msg'][$i][$j][$m] : '','corn'=>isset($finalSubVariationAry['variation_corn'][$i][$j][$m]) ? $finalSubVariationAry['variation_corn'][$i][$j][$m] : '','peanuts'=>isset($finalSubVariationAry['variation_peanuts'][$i][$j][$m]) ? $finalSubVariationAry['variation_peanuts'][$i][$j][$m] : '','treenuts'=>isset($finalSubVariationAry['variation_treenuts'][$i][$j][$m]) ? $finalSubVariationAry['variation_treenuts'][$i][$j][$m] : '','sulfites'=>isset($finalSubVariationAry['variation_sulfites'][$i][$j][$m]) ? $finalSubVariationAry['variation_sulfites'][$i][$j][$m] : '','mustard'=>isset($finalSubVariationAry['variation_mustard'][$i][$j][$m]) ? $finalSubVariationAry['variation_mustard'][$i][$j][$m] : '','wheat'=>isset($finalSubVariationAry['variation_wheat'][$i][$j][$m]) ? $finalSubVariationAry['variation_wheat'][$i][$j][$m] : '','soy'=>isset($finalSubVariationAry['variation_soy'][$i][$j][$m]) ? $finalSubVariationAry['variation_soy'][$i][$j][$m] : '','seafood'=>isset($finalSubVariationAry['variation_seafood'][$i][$j][$m]) ? $finalSubVariationAry['variation_seafood'][$i][$j][$m] : '','garlic'=>isset($finalSubVariationAry['variation_garlic'][$i][$j][$m]) ? $finalSubVariationAry['variation_garlic'][$i][$j][$m] : '','eggs'=>isset($finalSubVariationAry['variation_eggs'][$i][$j][$m]) ? $finalSubVariationAry['variation_eggs'][$i][$j][$m] : '','tartrazine'=>isset($finalSubVariationAry['variation_tartrazine'][$i][$j][$m]) ? $finalSubVariationAry['variation_tartrazine'][$i][$j][$m] : '','onions'=>isset($finalSubVariationAry['variation_onions'][$i][$j][$m]) ? $finalSubVariationAry['variation_onions'][$i][$j][$m] : '','animal_fats_oils'=>isset($finalSubVariationAry['variation_animal_fats_oils'][$i][$j][$m]) ? $finalSubVariationAry['variation_animal_fats_oils'][$i][$j][$m] : '','shellfish'=>isset($finalSubVariationAry['variation_shellfish'][$i][$j][$m]) ? $finalSubVariationAry['variation_shellfish'][$i][$j][$m] : '','fish'=>isset($finalSubVariationAry['variation_fish'][$i][$j][$m]) ? $finalSubVariationAry['variation_fish'][$i][$j][$m] : '','sesama'=>isset($finalSubVariationAry['variation_sesama'][$i][$j][$m]) ? $finalSubVariationAry['variation_sesama'][$i][$j][$m] : '','dairy'=>isset($finalSubVariationAry['variation_dairy'][$i][$j][$m]) ? $finalSubVariationAry['variation_dairy'][$i][$j][$m] : '','saturated_fats'=>isset($finalSubVariationAry['variation_saturated_fats'][$i][$j][$m]) ? $finalSubVariationAry['variation_saturated_fats'][$i][$j][$m] : '','vitamin_a'=>isset($finalSubVariationAry['variation_vitamin_a'][$i][$j][$m]) ? $finalSubVariationAry['variation_vitamin_a'][$i][$j][$m] : '','carbs'=>isset($finalSubVariationAry['variation_carbs'][$i][$j][$m]) ? $finalSubVariationAry['variation_carbs'][$i][$j][$m] : '','vitamin_c'=>isset($finalSubVariationAry['variation_vitamin_c'][$i][$j][$m]) ? $finalSubVariationAry['variation_vitamin_c'][$i][$j][$m] : '','protein'=>isset($finalSubVariationAry['variation_protein'][$i][$j][$m]) ? $finalSubVariationAry['variation_protein'][$i][$j][$m] : '','fat'=>isset($finalSubVariationAry['variation_fat'][$i][$j][$m]) ? $finalSubVariationAry['variation_fat'][$i][$j][$m] : '','cholesterol'=>isset($finalSubVariationAry['variation_cholesterol'][$i][$j][$m]) ? $finalSubVariationAry['variation_cholesterol'][$i][$j][$m] : '','fiber'=>isset($finalSubVariationAry['variation_fiber'][$i][$j][$m]) ? $finalSubVariationAry['variation_fiber'][$i][$j][$m] : '','calcium'=>isset($finalSubVariationAry['variation_calcium'][$i][$j][$m]) ? $finalSubVariationAry['variation_calcium'][$i][$j][$m] : '','calories'=>isset($finalSubVariationAry['variation_calories'][$i][$j][$m]) ? $finalSubVariationAry['variation_calories'][$i][$j][$m] : '','sodium'=>isset($finalSubVariationAry['variation_sodium'][$i][$j][$m]) ? $finalSubVariationAry['variation_sodium'][$i][$j][$m] : '','trans_fat'=>isset($finalSubVariationAry['variation_trans_fat'][$i][$j][$m]) ? $finalSubVariationAry['variation_trans_fat'][$i][$j][$m] : '','iron'=>isset($finalSubVariationAry['variation_iron'][$i][$j][$m]) ? $finalSubVariationAry['variation_iron'][$i][$j][$m] : '','sugar'=>isset($finalSubVariationAry['variation_sugar'][$i][$j][$m]) ? $finalSubVariationAry['variation_sugar'][$i][$j][$m] : '');
			    		}
			    	}


			    	$topping=array();
		    		if(isset($finalSubToppingAry['topping_name'][$i][$j]) && isset($finalSubToppingAry['topping_name'][$i]) && isset($finalSubToppingAry['topping_name'])){
		    			for($n=0; $n<count($finalSubToppingAry['topping_name'][$i][$j]); $n++) {
			    			$topping[] = array('name'=>isset($finalSubToppingAry['topping_name'][$i][$j][$n]) ? $finalSubToppingAry['topping_name'][$i][$j][$n] : '', 'category'=>isset($finalSubToppingAry['topping_category'][$i][$j][$n]) ? $finalSubToppingAry['topping_category'][$i][$j][$n] : '','price'=>isset($finalSubToppingAry['topping_price'][$i][$j][$n]) ? $finalSubToppingAry['topping_price'][$i][$j][$n] : '','gluten_free'=>isset($finalSubToppingAry['topping_gluten_free'][$i][$j][$n]) ? $finalSubToppingAry['topping_gluten_free'][$i][$j][$n] : '','kosher'=>isset($finalSubToppingAry['topping_kosher'][$i][$j][$n]) ? $finalSubToppingAry['topping_kosher'][$i][$j][$n] : '','halal'=>isset($finalSubToppingAry['topping_halal'][$i][$j][$n]) ? $finalSubToppingAry['topping_halal'][$i][$j][$n] : '','vegan'=>isset($finalSubToppingAry['topping_vegan'][$i][$j][$n]) ? $finalSubToppingAry['topping_vegan'][$i][$j][$n] : '','vegetarian'=>isset($finalSubToppingAry['topping_vegetarian'][$i][$j][$n]) ? $finalSubToppingAry['topping_vegetarian'][$i][$j][$n] : '','spicy'=>isset($finalSubToppingAry['topping_spicy'][$i][$j][$n]) ? $finalSubToppingAry['topping_spicy'][$i][$j][$n] : '','ocean_wise'=>isset($finalSubToppingAry['topping_ocean_wise'][$i][$j][$n]) ? $finalSubToppingAry['topping_ocean_wise'][$i][$j][$n] : '','msg'=>isset($finalSubToppingAry['topping_msg'][$i][$j][$n]) ? $finalSubToppingAry['topping_msg'][$i][$j][$n] : '','corn'=>isset($finalSubToppingAry['topping_corn'][$i][$j][$n]) ? $finalSubToppingAry['topping_corn'][$i][$j][$n] : '','peanuts'=>isset($finalSubToppingAry['topping_peanuts'][$i][$j][$n]) ? $finalSubToppingAry['topping_peanuts'][$i][$j][$n] : '','treenuts'=>isset($finalSubToppingAry['topping_treenuts'][$i][$j][$n]) ? $finalSubToppingAry['topping_treenuts'][$i][$j][$n] : '','sulfites'=>isset($finalSubToppingAry['topping_sulfites'][$i][$j][$n]) ? $finalSubToppingAry['topping_sulfites'][$i][$j][$n] : '','mustard'=>isset($finalSubToppingAry['topping_mustard'][$i][$j][$n]) ? $finalSubToppingAry['topping_mustard'][$i][$j][$n] : '','wheat'=>isset($finalSubToppingAry['topping_wheat'][$i][$j][$n]) ? $finalSubToppingAry['topping_wheat'][$i][$j][$n] : '','soy'=>isset($finalSubToppingAry['topping_soy'][$i][$j][$n]) ? $finalSubToppingAry['topping_soy'][$i][$j][$n] : '','seafood'=>isset($finalSubToppingAry['topping_seafood'][$i][$j][$n]) ? $finalSubToppingAry['topping_seafood'][$i][$j][$n] : '','garlic'=>isset($finalSubToppingAry['topping_garlic'][$i][$j][$n]) ? $finalSubToppingAry['topping_garlic'][$i][$j][$n] : '','eggs'=>isset($finalSubToppingAry['topping_eggs'][$i][$j][$n]) ? $finalSubToppingAry['topping_eggs'][$i][$j][$n] : '','tartrazine'=>isset($finalSubToppingAry['topping_tartrazine'][$i][$j][$n]) ? $finalSubToppingAry['topping_tartrazine'][$i][$j][$n] : '','onions'=>isset($finalSubToppingAry['topping_onions'][$i][$j][$n]) ? $finalSubToppingAry['topping_onions'][$i][$j][$n] : '','animal_fats_oils'=>isset($finalSubToppingAry['topping_animal_fats_oils'][$i][$j][$n]) ? $finalSubToppingAry['topping_animal_fats_oils'][$i][$j][$n] : '','shellfish'=>isset($finalSubToppingAry['topping_shellfish'][$i][$j][$n]) ? $finalSubToppingAry['topping_shellfish'][$i][$j][$n] : '','fish'=>isset($finalSubToppingAry['topping_fish'][$i][$j][$n]) ? $finalSubToppingAry['topping_fish'][$i][$j][$n] : '','sesama'=>isset($finalSubToppingAry['topping_sesama'][$i][$j][$n]) ? $finalSubToppingAry['topping_sesama'][$i][$j][$n] : '','dairy'=>isset($finalSubToppingAry['topping_dairy'][$i][$j][$n]) ? $finalSubToppingAry['topping_dairy'][$i][$j][$n] : '','saturated_fats'=>isset($finalSubToppingAry['topping_saturated_fats'][$i][$j][$n]) ? $finalSubToppingAry['topping_saturated_fats'][$i][$j][$n] : '','vitamin_a'=>isset($finalSubToppingAry['topping_vitamin_a'][$i][$j][$n]) ? $finalSubToppingAry['topping_vitamin_a'][$i][$j][$n] : '','carbs'=>isset($finalSubToppingAry['topping_carbs'][$i][$j][$n]) ? $finalSubToppingAry['topping_carbs'][$i][$j][$n] : '','vitamin_c'=>isset($finalSubToppingAry['topping_vitamin_c'][$i][$j][$n]) ? $finalSubToppingAry['topping_vitamin_c'][$i][$j][$n] : '','protein'=>isset($finalSubToppingAry['topping_protein'][$i][$j][$n]) ? $finalSubToppingAry['topping_protein'][$i][$j][$n] : '','fat'=>isset($finalSubToppingAry['topping_fat'][$i][$j][$n]) ? $finalSubToppingAry['topping_fat'][$i][$j][$n] : '','cholesterol'=>isset($finalSubToppingAry['topping_cholesterol'][$i][$j][$n]) ? $finalSubToppingAry['topping_cholesterol'][$i][$j][$n] : '','fiber'=>isset($finalSubToppingAry['topping_fiber'][$i][$j][$n]) ? $finalSubToppingAry['topping_fiber'][$i][$j][$n] : '','calcium'=>isset($finalSubToppingAry['topping_calcium'][$i][$j][$n]) ? $finalSubToppingAry['topping_calcium'][$i][$j][$n] : '','calories'=>isset($finalSubToppingAry['topping_calories'][$i][$j][$n]) ? $finalSubToppingAry['topping_calories'][$i][$j][$n] : '','sodium'=>isset($finalSubToppingAry['topping_sodium'][$i][$j][$n]) ? $finalSubToppingAry['topping_sodium'][$i][$j][$n] : '','trans_fat'=>isset($finalSubToppingAry['topping_trans_fat'][$i][$j][$n]) ? $finalSubToppingAry['topping_trans_fat'][$i][$j][$n] : '','iron'=>isset($finalSubToppingAry['topping_iron'][$i][$j][$n]) ? $finalSubToppingAry['topping_iron'][$i][$j][$n] : '','sugar'=>isset($finalSubToppingAry['topping_sugar'][$i][$j][$n]) ? $finalSubToppingAry['topping_sugar'][$i][$j][$n] : '');
			    		}
		    		}

		    		$item[] = array('name'=>isset($finalItemAry['name'][$i][$j]) ? $finalItemAry['name'][$i][$j] : '', 'category'=>isset($finalItemAry['category'][$i][$j]) ? $finalItemAry['category'][$i][$j] : '','price'=>isset($finalItemAry['price'][$i][$j]) ? $finalItemAry['price'][$i][$j] : '','gluten_free'=>isset($finalItemAry['gluten_free'][$i][$j]) ? $finalItemAry['gluten_free'][$i][$j] : '','kosher'=>isset($finalItemAry['kosher'][$i][$j]) ? $finalItemAry['kosher'][$i][$j] : '','halal'=>isset($finalItemAry['halal'][$i][$j]) ? $finalItemAry['halal'][$i][$j] : '','vegan'=>isset($finalItemAry['vegan'][$i][$j]) ? $finalItemAry['vegan'][$i][$j] : '','vegetarian'=>isset($finalItemAry['vegetarian'][$i][$j]) ? $finalItemAry['vegetarian'][$i][$j] : '','spicy'=>isset($finalItemAry['spicy'][$i][$j]) ? $finalItemAry['spicy'][$i][$j] : '','ocean_wise'=>isset($finalItemAry['ocean_wise'][$i][$j]) ? $finalItemAry['ocean_wise'][$i][$j] : '','msg'=>isset($finalItemAry['msg'][$i][$j]) ? $finalItemAry['msg'][$i][$j] : '','corn'=>isset($finalItemAry['corn'][$i][$j]) ? $finalItemAry['corn'][$i][$j] : '','peanuts'=>isset($finalItemAry['peanuts'][$i][$j]) ? $finalItemAry['peanuts'][$i][$j] : '','treenuts'=>isset($finalItemAry['treenuts'][$i][$j]) ? $finalItemAry['treenuts'][$i][$j] : '','sulfites'=>isset($finalItemAry['sulfites'][$i][$j]) ? $finalItemAry['sulfites'][$i][$j] : '','mustard'=>isset($finalItemAry['mustard'][$i][$j]) ? $finalItemAry['mustard'][$i][$j] : '','wheat'=>isset($finalItemAry['wheat'][$i][$j]) ? $finalItemAry['wheat'][$i][$j] : '','soy'=>isset($finalItemAry['soy'][$i][$j]) ? $finalItemAry['soy'][$i][$j] : '','seafood'=>isset($finalItemAry['seafood'][$i][$j]) ? $finalItemAry['seafood'][$i][$j] : '','garlic'=>isset($finalItemAry['garlic'][$i][$j]) ? $finalItemAry['garlic'][$i][$j] : '','eggs'=>isset($finalItemAry['eggs'][$i][$j]) ? $finalItemAry['eggs'][$i][$j] : '','tartrazine'=>isset($finalItemAry['tartrazine'][$i][$j]) ? $finalItemAry['tartrazine'][$i][$j] : '','onions'=>isset($finalItemAry['onions'][$i][$j]) ? $finalItemAry['onions'][$i][$j] : '','animal_fats_oils'=>isset($finalItemAry['animal_fats_oils'][$i][$j]) ? $finalItemAry['animal_fats_oils'][$i][$j] : '','shellfish'=>isset($finalItemAry['shellfish'][$i][$j]) ? $finalItemAry['shellfish'][$i][$j] : '','fish'=>isset($finalItemAry['fish'][$i][$j]) ? $finalItemAry['fish'][$i][$j] : '','sesama'=>isset($finalItemAry['sesama'][$i][$j]) ? $finalItemAry['sesama'][$i][$j] : '','dairy'=>isset($finalItemAry['dairy'][$i][$j]) ? $finalItemAry['dairy'][$i][$j] : '','saturated_fats'=>isset($finalItemAry['saturated_fats'][$i][$j]) ? $finalItemAry['saturated_fats'][$i][$j] : '','vitamin_a'=>isset($finalItemAry['vitamin_a'][$i][$j]) ? $finalItemAry['vitamin_a'][$i][$j] : '','carbs'=>isset($finalItemAry['carbs'][$i][$j]) ? $finalItemAry['carbs'][$i][$j] : '','vitamin_c'=>isset($finalItemAry['vitamin_c'][$i][$j]) ? $finalItemAry['vitamin_c'][$i][$j] : '','protein'=>isset($finalItemAry['protein'][$i][$j]) ? $finalItemAry['protein'][$i][$j] : '','fat'=>isset($finalItemAry['fat'][$i][$j]) ? $finalItemAry['fat'][$i][$j] : '','cholesterol'=>isset($finalItemAry['cholesterol'][$i][$j]) ? $finalItemAry['cholesterol'][$i][$j] : '','fiber'=>isset($finalItemAry['fiber'][$i][$j]) ? $finalItemAry['fiber'][$i][$j] : '','calcium'=>isset($finalItemAry['calcium'][$i][$j]) ? $finalItemAry['calcium'][$i][$j] : '','calories'=>isset($finalItemAry['calories'][$i][$j]) ? $finalItemAry['calories'][$i][$j] : '','sodium'=>isset($finalItemAry['sodium'][$i][$j]) ? $finalItemAry['sodium'][$i][$j] : '','trans_fat'=>isset($finalItemAry['trans_fat'][$i][$j]) ? $finalItemAry['trans_fat'][$i][$j] : '','iron'=>isset($finalItemAry['iron'][$i][$j]) ? $finalItemAry['iron'][$i][$j] : '','sugar'=>isset($finalItemAry['sugar'][$i][$j]) ? $finalItemAry['sugar'][$i][$j] : '', 'side'=>$side, 'addon'=>$addon, 'variation'=>$variation, 'topping'=>$topping);


	    			/*$item[] = array('name'=>isset($finalItemAry['name'][$i][$j]) ? $finalItemAry['name'][$i][$j] : '', 'category'=>isset($finalItemAry['category'][$i][$j]) ? $finalItemAry['category'][$i][$j] : '', 'side'=>$side, 'addon'=>$addon, 'variation'=>$variation, 'topping'=>$topping);*/

	    		}
	    	}


    		$menuNameForDay = $menuName[$i];


    		$monday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('1', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$tuesday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('2', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$wenesday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('3', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$thurday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('4', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$friday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('5', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$saturday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('6', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';
    		$sunday = (isset($finalMainTab1Ary['day'][$menuNameForDay]) && !empty($finalMainTab1Ary['day'][$menuNameForDay])) ? ((in_array('7', $finalMainTab1Ary['day'][$menuNameForDay])) ? 'true' : 'false') : 'false';



    		$main[$i] = array('name'=>$menuName[$i], 
    			'Monday' => $monday,
	    		'Tuesday' => $tuesday,
	    		'Wenesday' => $wenesday,
	    		'Thurday' => $thurday,
	    		'Friday' => $friday,
	    		'Saturday' => $saturday,
	    		'Sunday' => $sunday, 
	    		'start_time'=>isset($finalMainTab1Ary['start_time'][$menuNameForDay]) ? $finalMainTab1Ary['start_time'][$menuNameForDay] : '',
	    		'end_time'=>isset($finalMainTab1Ary['end_time'][$menuNameForDay]) ? $finalMainTab1Ary['end_time'][$menuNameForDay] : '',
                 'item'=>$item);
    	}
    	
    	
    	$jsonFileName = $this->generateJsonFile($main);
    	
    	if(isset($_FILES) && !empty($_FILES)) {
    	   $uploadImg = $this->uploadMeanuImage($images, $imagesForBackendless, $menuName);
    	   if(isset($uploadImg) && !empty($uploadImg)) {
    	        $imgPostData = [];
                foreach($uploadImg as $key => $imgs) {
                    $customeImgAry = [];
                    if(isset($imgs) && !empty($imgs)) {
                        foreach($imgs as $key1 => $img) {
                            $customeImgAry[] = array('menuFile'=>$img['file_url'], 'name'=>$menuName[$key]);
                        }
                        $imgPostData[$key] = $customeImgAry;
                    }
                }
    	   }
    	   
    	   if(isset($imgPostData) && !empty($imgPostData)) {
    	       $decodeImgJson = [];
                foreach ($imgPostData as $key => $imgPostDatas) {
                    $menuImgUrl = 'https://api.backendless.com/C41FC229-743D-296A-FF29-480E1EC14D00/9975C2C2-F45E-76F2-FF55-6AAC872E6E00/data/bulk/RestaurantMenus';
                    $menuImg = curlPostFun($menuImgUrl, $imgPostDatas);
                    $decodeImgJson[$key] = json_decode($menuImg);
                }
    	   }
    	}
        
        
        $resturantData = $this->getUserResturant();
        
        
        if(isset($resturantData) && !empty($resturantData) && isset($resturantData->restaurant) && !empty($resturantData->restaurant)) {
            
            $restaurantDetails = $resturantData->restaurant[0];
            $resturantObjectId = $restaurantDetails->objectId;

            $jsonUpdateUrl = 'https://api.backendless.com/C41FC229-743D-296A-FF29-480E1EC14D00/9975C2C2-F45E-76F2-FF55-6AAC872E6E00/data/Restaurants/'.$resturantObjectId;
            $postData = array('JSONfile' => $jsonFileName);
            $response = curlPutFun($jsonUpdateUrl, $postData);
            $decodeJson = json_decode($response);
            
            if(isset($decodeImgJson) && !empty($decodeImgJson)) {

                $singleArray = []; 
                foreach ($decodeImgJson as $childArray) 
                { 
                    if(isset($childArray) && !empty($childArray)) {
                        foreach ($childArray as $value) 
                        { 
                            $singleArray[] = $value; 
                        } 
                    }
                }
                $imageRes = $this->updateMenuNameId($singleArray, $resturantObjectId);
            }
        }
        
        if($decodeJson) {
            return redirect()->route('admin.dashboard')->with('success','JSON File Created Successfully!');
        } else {
            return redirect()->route('admin.addrestaurant')->with('error','Something Went Wrong, Please Try Again!!');
        }
    }
    
    public function updateMenuNameId($menuImagesId, $resturantObjectId)
    {
        $url = 'https://api.backendless.com/C41FC229-743D-296A-FF29-480E1EC14D00/9975C2C2-F45E-76F2-FF55-6AAC872E6E00/data/Restaurants/'.$resturantObjectId.'/menuImages:RestaurantMenus:n';
        //$postData = ['92236E3A-394E-350F-FF0F-3B05F310CA00','F4750568-0FF6-E54F-FFA7-6EA4E1EFE800'];
        //$jsonData = json_encode($menuImagesId);
        $result = curlPostFun($url, $menuImagesId);
        $res = json_decode($result);
        return $res;
    }
    
    
    public function uploadImageOnBackendless($filename, $filedata, $filesize, $filetype, $resturantFolderName)
    {
        /*echo '<pre>'; print_r($_FILES);
        $fileVar = $_FILES["menu_image"];
        $filename = time().$fileVar['name'];
        $filedata = $fileVar['tmp_name'];
        $filesize = $fileVar['size'];
        $filetype = $fileVar['type'];*/
        //$postfields = array("filedata" => "@$filedata");
        
        $backendPath = 'Restaurant/'.$resturantFolderName.'/Images';
        $curl = curl_init();
        $cfile = new \CURLFile($filedata, $filetype, $filename);
        $postfields = array("filedata" =>$cfile);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_URL, 'https://api.backendless.com/C41FC229-743D-296A-FF29-480E1EC14D00/9975C2C2-F45E-76F2-FF55-6AAC872E6E00/files/'.$backendPath.'/'.$filename.'/?overwrite=true');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postfields);
        curl_setopt($curl, CURLOPT_INFILESIZE , $filesize);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Content-Type: multipart/form-data')
        );
        $result = curl_exec($curl);
        curl_close($curl);

        return $result;
    }
    
    public function uploadImageOnLocalFolder($tmpName, $filename, $targetPath)
    {
        if (move_uploaded_file($tmpName, $targetPath)) {
            return $filename;
        } else {
            return false;
        }
    }
    
    public function uploadMeanuImage($images, $imagesForBackendless, $menuName)
    { 
        $loginData = loginUserData();
        $loginObjectId = $loginData->objectId;
        $name = str_replace(' ', '', $loginData->name);

        $resturantData = $this->getUserResturant();
        $resturantObjectId = $resturantData->restaurant[0]->city.'_'.$resturantData->restaurant[0]->postal;
        $resturantFolderName = $name.'_'.$resturantObjectId;
    
       /* $filePathWithFolder = $_SERVER['DOCUMENT_ROOT'] . '/dashboard/backendless/public/Restaurant/'.$resturantFolderName.'/JSON/'.$filename;*/
        
        $destinationPath = public_path().'/Restaurant/'.$resturantFolderName.'/Images/';
        if(!is_dir($destinationPath)) {
            mkdir($destinationPath, 0777, true);
        }

        $imageForLoops = $imagesForBackendless['name'];
        $res=[];
        if(isset($imageForLoops) && !empty($imageForLoops)) {
            foreach($imageForLoops as $key=>$imageForLoop) {
                
                if(isset($imageForLoop) && !empty($imageForLoop)) {
                    
                    foreach($imageForLoop as $key1=>$images) {
                        $actuallyFileName = $imagesForBackendless['name'][$key][$key1];
                        if($actuallyFileName != '') {
                             $ext = pathinfo($actuallyFileName, PATHINFO_EXTENSION);
        
                            $filename = $menuName[$key].'_'.$key1.'.'.$ext;
            
                            $filedata = $imagesForBackendless['tmp_name'][$key][$key1];
                            $filesize = $imagesForBackendless['size'][$key][$key1];
                            $filetype = $imagesForBackendless['type'][$key][$key1];
            
                            $getFileUrl = $this->uploadImageOnBackendless($filename, $filedata, $filesize, $filetype, $resturantFolderName);
                            if(isset($getFileUrl) && !empty($getFileUrl)) {
                                $decodeJson = json_decode($getFileUrl);
                            }
            
                            $targetPath = $destinationPath.'/'.$filename;
                            $localImg = $this->uploadImageOnLocalFolder($filedata, $filename, $targetPath);
            
                            $res[$key][] = array('file_name'=>$filename, 'file_url'=>(isset($decodeJson)) ? $decodeJson->fileURL : '');     
                        }
                    } 
                }
            } 
        }
        return $res;
    }
    
    
    public function uploadJsonFileOnBackendless($name, $resturantFolderName, $filePathWithFolder, $filedata, $filetype, $filename)
    {
        $backendPath = 'Restaurant/'.$resturantFolderName.'/JSON';
        $curl = curl_init();

        $filetype = 'application/json';
        //$filePathWithFolder = 'D:\xampp\htdocs\backendless\public\Restaurant\admin\JSON\admin.json';
        
        $filePathWithFolder = $_SERVER['DOCUMENT_ROOT'] . '/dashboard/backendless/public/Restaurant/'.$resturantFolderName.'/JSON/'.$filename;

        $filesize = filesize($filePathWithFolder);

        $cfile = new \CURLFile($filePathWithFolder, $filetype, $filename);
        $postfields = array("filedata" =>$cfile);

        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_URL, 'https://api.backendless.com/C41FC229-743D-296A-FF29-480E1EC14D00/9975C2C2-F45E-76F2-FF55-6AAC872E6E00/files/'.$backendPath.'/'.$filename.'/?overwrite=true');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $postfields);
        curl_setopt($curl, CURLOPT_INFILESIZE , $filesize);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
        'Content-Type: multipart/form-data', 'boundary: RECORD_BOUNDARY')
        );
        $result = curl_exec($curl);
        curl_close($curl);
        return $result;
    }
    
    
    public function generateJsonFile($result)
    {
		$loginData = loginUserData();
		$loginObjectId = $loginData->objectId;
		$name = str_replace(' ', '', $loginData->name);
		
		$resturantData = $this->getUserResturant();
        $resturantObjectId = $resturantData->restaurant[0]->city.'_'.$resturantData->restaurant[0]->postal;
        $resturantFolderName = $name.'_'.$resturantObjectId;
        
        $filedata = json_encode($result);
        $filetype = 'JSON';
        $filename = $name.'.json';

		$folderPath = public_path().'/Restaurant/'.$resturantFolderName.'/JSON/';
    
        $filePathWithFolder = $_SERVER['DOCUMENT_ROOT'] . '/dashboard/backendless/public/Restaurant/'.$resturantFolderName.'/JSON/'.$filename;
        
		if (!is_dir($folderPath)) {
		    mkdir($folderPath, 0777, true);
			if(file_exists($filePathWithFolder)) {
				unlink($filePathWithFolder);
			}
			file_put_contents($filePathWithFolder, json_encode($result));
		} else {
		    if(file_exists($filePathWithFolder)) {
				unlink($filePathWithFolder);
			}
		    file_put_contents($filePathWithFolder, json_encode($result));
		}
		
		$getJsonFileUrl = $this->uploadJsonFileOnBackendless($name, $resturantFolderName, $filePathWithFolder, $filedata, $filetype, $filename);
        $decodeJsonFile = json_decode($getJsonFileUrl);
		return $decodeJsonFile->fileURL;
    }
    
    public function updateJsonFile($jsonfile)
    {
        $loginData = loginUserData();
        $loginObjectId = $loginData->objectId;

        $url = 'http://api.backendless.com/'.$this->appId.'/'.$this->apiKey.'/data/Users/'.$loginObjectId.'?loadRelations=restaurant';

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        $resturantData = json_decode($result);

        if(isset($resturantData) && isset($resturantData->restaurant) && isset($resturantData->restaurant[0])) {
            $restaurantDetails = $resturantData->restaurant[0];
            $restaurantObjectId = $restaurantDetails->objectId;

            $fileUploadUrl = 'https://api.backendless.com/C41FC229-743D-296A-FF29-480E1EC14D00/9975C2C2-F45E-76F2-FF55-6AAC872E6E00/files/jsonfile/'.$jsonfile;

            $url = 'https://api.backendless.com/C41FC229-743D-296A-FF29-480E1EC14D00/9975C2C2-F45E-76F2-FF55-6AAC872E6E00/data/Restaurants/'.$resturantObjectId;
            $postData = array(
                'JSONfile' => $jsonfile
            );

            $jsonData = json_encode($postData);
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch, CURLOPT_POSTFIELDS,$jsonData);
            $response = curl_exec($ch);
            curl_close($ch);

            $decodeJson = json_decode($response);

        } else {

        }
    }
    
    public function slidehtml(Request $request)
    {
        $menuname = $request->get('menuName');
        $newMenuString = str_replace('_', ' ', $menuname);
        $itemname = $request->get('itemName');
        
        $resturantData = $this->getUserResturant();
        $aa = '';
        
        if(isset($resturantData->restaurant[0]->JSONfile) && ($resturantData->restaurant[0]->JSONfile != '')) {
            $restaurantDetails = $resturantData->restaurant[0]->JSONfile;
            $jsonFiles = json_decode(file_get_contents($restaurantDetails));
            $main = '';
            
            foreach($jsonFiles as $key=>$jsonFile) {
                if ($jsonFile->name == trim($newMenuString))
                {   
                    $main .= '<div class="menu-side-content-div-cls" attr-menu="'.$menuname.'" id="menu_side_content_div_'.$menuname.'" attr-menu-key="'.$key.'">';
                    
                    $menuId = $key;
                    $items = $jsonFiles[$menuId]->item;
                    if(isset($items) && !empty($items)) {
                        foreach($items as $key1=>$item) {
                            
                            $main .= '<div class="menu-item2-side-content-cls" id="menu_item2_side_content_cls_'.$menuname.'_'.$key1.'" attr-menu-key="'.$key.'" attr-item-key="'.$key1.'">';
                            if(in_array($key1, $itemname)) {
                            
                                if(isset($item->side) && !empty($item->side)) {
                                    
                                $sides = $item->side;
                                foreach($sides as $key2=>$side) {
                                    $cat = isset($side->category) ? $side->category : '';
                                    
                                    $glutenFreeNA = (($side->gluten_free == 'NA') ? "Selected" : "");
                                    $glutenFreeY = (($side->gluten_free == 'Y') ? "Selected" : "");
                                    $glutenFreeN = (($side->gluten_free == 'N') ? "Selected" : "");
                                    
                                    $animalFatOilsNA = (($side->animal_fats_oils == 'NA') ? "Selected" : "");
                                    $animalFatOilsY = (($side->animal_fats_oils == 'Y') ? "Selected" : "");
                                    $animalFatOilsN = (($side->animal_fats_oils == 'N') ? "Selected" : "");
                                    
                                    $standardTrue = (($side->standard == 'true') ? "Selected" : "");
                                    $standardFalse = (($side->standard == 'false') ? "Selected" : "");
                                    
                                    $main .= "<div class='side-content-div-cls' attr-menu='".$menuname."' attr-item='".$key1."' attr-menu-key='".$key."' attr-slide='".$key2."' id='side_content_div_".$menuname."_".$key1."_".$key2."'><div class='item-content-div clearfix'><h5 class='menu_head hide'>Menu ".$newMenuString." AND Item" .$key1. "</h5><div class='sideform'><div class='col-md-3 form-group'><label class='side_standard'>Standard</label><select class='form-control' name='side_standard[$menuId][$key1][]' id='standard'><option value='true' $standardTrue>true</option><option value='false' $standardFalse>false</option></select></div><div class='col-md-3 form-group'><label>Name</label><input type='text' value='".$side->name."' class='form-control name side-name-text' name='side_name[$menuId][$key1][]' id='name' placeholder='name'><span class='side_name_error'></span></div><div class='col-md-3 form-group'><label>Category</label><input type='text' value='".$cat."' class='form-control' name='side_category[$menuId][$key1][]' id='category' placeholder='category'></div><div class='col-md-3 form-group'><label>Price</label> <input type='number' class='form-control' name='side_price[$menuId][$key1][]' id='price' placeholder='price' value='".$side->price."'></div><div class='clearfix'></div><hr class='clearfix' width='100%'><div class='col-md-2 form-group'><label>Glutten</label> <select class='form-control' name='side_gluten_free[$menuId][$key1][]' id='gluten_free'><option value='NA' '".$glutenFreeNA."'>NA</option><option value='Y' '".$glutenFreeY."'>Y</option><option value='N' '".$glutenFreeN."'>N</option></select></div><div class='col-md-2 form-group'><label>Kosher</label> <select class='form-control' name='side_kosher[$menuId][$key1][]' id='kosher'><option value='NA' '.(($side->kosher == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->kosher == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->kosher == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Halal</label> <select class='form-control' name='side_halal[$menuId][$key1][]' id='halal'><option value='NA' '.(($side->halal == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->halal == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->halal == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Vegan</label> <select class='form-control' name='side_vegan[$menuId][$key1][]' id='vegan'><option value='NA' '.(($side->vegan == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->vegan == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->vegan == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Vegetarian</label> <select class='form-control' name='side_vegetarian[$menuId][$key1][]' id='vegetarian'><option value='NA' '.(($side->vegetarian == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->vegetarian == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->vegetarian == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Spicy</label> <select class='form-control' name='side_spicy[$menuId][$key1][]' id='spicy'><option value='NA' '.(($side->spicy == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->spicy == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->spicy == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Ocean</label> <select class='form-control' name='side_ocean_wise[$menuId][$key1][]' id='ocean_wise'><option value='NA' '.(($side->ocean_wise == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->ocean_wise == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->ocean_wise == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Msg</label> <select class='form-control' name='side_msg[$menuId][$key1][]' id='msg'><option value='NA' '.(($side->msg == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->msg == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->msg == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Corn</label> <select class='form-control' name='side_corn[$menuId][$key1][]' id='corn'><option value='NA' '.(($side->corn == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->corn == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->corn == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Peanuts</label> <select class='form-control' name='side_peanuts[$menuId][$key1][]' id='peanuts'><option value='NA' '.(($side->peanuts == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->peanuts == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->peanuts == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Treenuts</label> <select class='form-control' name='side_treenuts[$menuId][$key1][]' id='treenuts'><option value='NA' '.(($side->treenuts == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->treenuts == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->treenuts == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Sulfites</label> <select class='form-control' name='side_sulfites[$menuId][$key1][]' id='sulfites'><option value='NA' '.(($side->sulfites == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->sulfites == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->sulfites == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Mustard</label> <select class='form-control' name='side_mustard[$menuId][$key1][]' id='mustard'><option value='NA' '.(($side->mustard == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->mustard == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->mustard == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Wheat</label> <select class='form-control' name='side_wheat[$menuId][$key1][]' id='wheat'><option value='NA' '.(($side->wheat == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->wheat == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->wheat == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Soy</label> <select class='form-control' name='side_soy[$menuId][$key1][]' id='soy'><option value='NA' '.(($side->soy == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->soy == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->soy == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Seafood</label> <select class='form-control' name='side_seafood[$menuId][$key1][]' id='seafood'><option value='NA' '.(($side->seafood == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->seafood == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->seafood == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Garlic</label> <select class='form-control' name='side_garlic[$menuId][$key1][]' id='garlic'><option value='NA' '.(($side->garlic == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->garlic == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->garlic == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Eggs</label> <select class='form-control' name='side_eggs[$menuId][$key1][]' id='eggs'><option value='NA' '.(($side->eggs == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->eggs == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->eggs == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Tarazine</label> <select class='form-control' name='side_tartrazine[$menuId][$key1][]' id='tartrazine'><option value='NA' '.(($side->tartrazine == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->tartrazine == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->tartrazine == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Onions</label> <select class='form-control' name='side_onions[$menuId][$key1][]' id='onions'><option value='NA' '.(($side->onions == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->onions == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->onions == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Animal Fats</label> <select class='form-control' name='side_animal_fats_oils[$menuId][$key1][]' id='animal_fats_oils'><option value='NA' '.$animalFatOilsNA.'>NA</option><option value='Y' '.$animalFatOilsY.'>Y</option><option value='N' '.$animalFatOilsN.'>N</option></select></div><div class='col-md-2 form-group'><label>ShellFish</label> <select class='form-control' name='side_shellfish[$menuId][$key1][]' id='shellfish'><option value='NA' '.(($side->shellfish == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->shellfish == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->shellfish == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Fish</label> <select class='form-control' name='side_fish[$menuId][$key1][]' id='fish'><option value='NA' '.(($side->fish == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->fish == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->fish == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Sesama</label> <select class='form-control' name='side_sesama[$menuId][$key1][]' id='sesama'><option value='NA' '.(($side->sesama == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->sesama == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->sesama == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='col-md-2 form-group'><label>Dairy</label> <select class='form-control' name='side_dairy[$menuId][$key1][]' id='dairy'><option value='NA' '.(($side->dairy == 'NA') ? 'Selected' : '').'>NA</option><option value='Y' '.(($side->dairy == 'Y') ? 'Selected' : '').'>Y</option><option value='N' '.(($side->dairy == 'N') ? 'Selected' : '').'>N</option> </select></div><div class='clearfix'><hr class='clearfix' width='100%'><div class='col-md-2 form-group'><label>Saturated Fats</label><input type='number' class='form-control' name='side_saturated_fats[$menuId][$key1][]' id='saturated_fats' placeholder='saturated_fats' value=$side->saturated_fats></div><div class='col-md-2 form-group'><label>Vitamin A</label> <input type='number' class='form-control' name='side_vitamin_a[$menuId][$key1][]' id='vitamin_a' placeholder='vitamin_a' value=$side->vitamin_a></div><div class='col-md-2 form-group'><label>Carbs</label> <input type='number' class='form-control' name='side_carbs[$menuId][$key1][]' id='carbs' placeholder='carbs' value=$side->carbs></div><div class='col-md-2 form-group'><label>Vitamin C</label> <input type='number' class='form-control' name='side_vitamin_c[$menuId][$key1][]' id='vitamin_c' placeholder='vitamin_c' value=$side->vitamin_c></div><div class='col-md-2 form-group'><label>Protien</label> <input type='number' class='form-control' name='side_protein[$menuId][$key1][]' id='protein' placeholder='protein' value=$side->protein></div><div class='col-md-2 form-group'><label>Fat</label> <input type='number' class='form-control' name='side_fat[$menuId][$key1][]' id='fat' placeholder='fat' value=$side->fat></div><div class='col-md-2 form-group'><label>Cholesterol</label> <input type='number' class='form-control' name='side_cholesterol[$menuId][$key1][]' id='cholesterol' placeholder='cholesterol' value=$side->cholesterol></div><div class='col-md-2 form-group'><label>Fiber</label> <input type='number' class='form-control' name='side_fiber[$menuId][$key1][]' id='fiber' placeholder='fiber' value=$side->fiber></div><div class='col-md-2 form-group'><label>Protien</label> <input type='number' class='form-control' name='side_protein[$menuId][$key1][]' id='protein' placeholder='protein' value=$side->protein></div><div class='col-md-2 form-group'><label>Calcium</label> <input type='number' class='form-control' name='side_calcium[$menuId][$key1][]' id='calcium' placeholder='calcium' value=$side->calcium></div><div class='col-md-2 form-group'><label>Calories</label> <input type='number' class='form-control' name='side_calories[$menuId][$key1][]' id='calories' placeholder='calories' value=$side->calories></div><div class='col-md-2 form-group'><label>Sodium</label> <input type='number' class='form-control' name='side_sodium[$menuId][$key1][]' id='sodium' placeholder='sodium' value=$side->sodium></div><div class='col-md-2 form-group'><label>Trans Fat</label> <input type='number' class='form-control' name='side_trans_fat[$menuId][$key1][]' id='trans_fat' placeholder='trans_fat' value=$side->trans_fat></div><div class='col-md-2 form-group'><label>Iron</label> <input type='number' class='form-control' name='side_iron['.$menuId.']['.$key1.'][]' id='iron' placeholder='iron' value=$side->iron></div><div class='col-md-2 form-group'><label>Sugar</label> <input type='number' class='form-control' name='side_sugar['.$menuId.']['.$key1.'][]' id='sugar' placeholder='sugar' value=$side->sugar></div></div><div class='col-md-12'><label class='sides_remove btn btn-danger pull-right'>Remove</label></div></div></div></div>";
                                }
                            } else {
                                    //$main .= '';
                                }
                            }
                            
                            $main .= '</div>';
                        }
                    }
                    
                    $main .= '</div>';
                } else {
                    $menuId = '';
                }
            }
            echo $main;
        }
    }
    
    
    public function addonhtml(Request $request)
    {
        $menuname = $request->get('menuName');
        $newMenuString = str_replace('_', ' ', $menuname);

        $itemname = $request->get('itemName');
        
        $resturantData = $this->getUserResturant();
        
        if(isset($resturantData->restaurant[0]->JSONfile) && ($resturantData->restaurant[0]->JSONfile != '')) {
            $restaurantDetails = $resturantData->restaurant[0]->JSONfile;
            $jsonFiles = json_decode(file_get_contents($restaurantDetails));
            $main = '';
            
            foreach($jsonFiles as $key=>$jsonFile) {
                if ($jsonFile->name == trim($newMenuString))
                {
                    $main .= '<div class="menu-addon-content-div-cls" attr-menu="'.$menuname.'" id="menu_addon_content_div_'.$menuname.'" attr-menu-key="'.$key.'">';
                    $menuId = $key;
                    $items = $jsonFiles[$menuId]->item;
                    
                    if(isset($items) && !empty($items)) {
                        foreach($items as $key1=>$item) {
                            
                            $main .= '<div class="menu-item2-addon-content-cls" id="menu_item2_addon_content_cls_'.$menuname.'_'.$key1.'" attr-menu-key="'.$key.'" attr-item-key="'.$key1.'">';
                            
                            if(in_array($key1, $itemname)) {
                                if(isset($item->addon) && !empty($item->addon)) {
                                    $addons = $item->addon;
                                    foreach($addons as $key2=>$addon) {
                                    
                                    $glutenFreeNA = (($addon->gluten_free == 'NA') ? "Selected" : "");
                                    $glutenFreeY = (($addon->gluten_free == 'Y') ? "Selected" : "");
                                    $glutenFreeN = (($addon->gluten_free == 'N') ? "Selected" : "");
                                    
                                    $animalFatOilsNA = (($addon->animal_fats_oils == 'NA') ? "Selected" : "");
                                    $animalFatOilsY = (($addon->animal_fats_oils == 'Y') ? "Selected" : "");
                                    $animalFatOilsN = (($addon->animal_fats_oils == 'N') ? "Selected" : "");
                                    
                                    $main .= '<div class="addon-content-div-cls" attr-menu='.$menuname.' attr-item='.$key1.' attr-menu-key='.$key.' attr-slide='.$key2.' id="side_content_div_'.$menuname.'_'.$key1.'_'.$key2.'"><div class="item-content-div clearfix"><h5 class="menu_head hide">Menu '.$newMenuString.' AND Item '.$key1.'</h5><div class="addonform"><div class="col-md-4 form-group"><label>Name</label> <input type="text" class="form-control name addon-name-text" name="addon_name['.$menuId.']['.$key1.'][]" id="name" placeholder="name" value="'.$addon->name.'"><span class="addon_name_error"></span></div><div class="col-md-4 form-group"><label>Category</label> <input type="text" class="form-control" name="addon_category['.$menuId.']['.$key1.'][]" id="category" placeholder="category" value="'.$addon->category.'"></div><div class="col-md-4 form-group"><label>Price</label> <input type="number" class="form-control" name="addon_price['.$menuId.']['.$key1.'][]" id="price" placeholder="price" value="'.$addon->price.'"></div><div class="clearfix"></div><hr class="clearfix" width="100%"><div class="col-md-2 form-group"><label>Glutten</label> <select class="form-control" name="addon_gluten_free['.$menuId.']['.$key1.'][]" id="gluten_free"><option value="NA" '.$glutenFreeNA.'>NA</option><option value="Y" '.$glutenFreeY.'>Y</option><option value="N" '.$glutenFreeN.'>N</option> </select></div><div class="col-md-2 form-group"><label>Kosher</label> <select class="form-control" name="addon_kosher['.$menuId.']['.$key1.'][]" id="kosher"><option value="NA" '.(($addon->kosher == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->kosher == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->kosher == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Halal</label> <select class="form-control" name="addon_halal['.$menuId.']['.$key1.'][]" id="halal"><option value="NA" '.(($addon->halal == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->halal == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->halal == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Vegan</label> <select class="form-control" name="addon_vegan['.$menuId.']['.$key1.'][]" id="vegan"><option value="NA" '.(($addon->vegan == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->vegan == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->vegan == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Vegetarian</label> <select class="form-control" name="addon_vegetarian['.$menuId.']['.$key1.'][]" id="vegetarian"><option value="NA" '.(($addon->vegetarian == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->vegetarian == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->vegetarian == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Spicy</label> <select class="form-control" name="addon_spicy['.$menuId.']['.$key1.'][]" id="spicy"><option value="NA" '.(($addon->spicy == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->spicy == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->spicy == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Ocean</label> <select class="form-control" name="addon_ocean_wise['.$menuId.']['.$key1.'][]" id="ocean_wise"><option value="NA" '.(($addon->ocean_wise == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->ocean_wise == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->ocean_wise == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Msg</label> <select class="form-control" name="addon_msg['.$menuId.']['.$key1.'][]" id="msg"><option value="NA" '.(($addon->msg == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->msg == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->msg == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Corn</label> <select class="form-control" name="addon_corn['.$menuId.']['.$key1.'][]" id="corn"><option value="NA" '.(($addon->corn == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->corn == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->corn == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Peanuts</label> <select class="form-control" name="addon_peanuts['.$menuId.']['.$key1.'][]" id="peanuts"><option value="NA" '.(($addon->peanuts == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->peanuts == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->peanuts == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Treenuts</label> <select class="form-control" name="addon_treenuts['.$menuId.']['.$key1.'][]" id="treenuts"><option value="NA" '.(($addon->treenuts == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->treenuts == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->treenuts == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Sulfites</label> <select class="form-control" name="addon_sulfites['.$menuId.']['.$key1.'][]" id="sulfites"><option value="NA" '.(($addon->sulfites == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->sulfites == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->sulfites == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Mustard</label> <select class="form-control" name="addon_mustard['.$menuId.']['.$key1.'][]" id="mustard"><option value="NA" '.(($addon->mustard == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->mustard == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->mustard == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Wheat</label> <select class="form-control" name="addon_wheat['.$menuId.']['.$key1.'][]" id="wheat"><option value="NA" '.(($addon->wheat == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->wheat == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->wheat == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Soy</label> <select class="form-control" name="addon_soy['.$menuId.']['.$key1.'][]" id="soy"><option value="NA" '.(($addon->soy == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->soy == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->soy == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Seafood</label> <select class="form-control" name="addon_seafood['.$menuId.']['.$key1.'][]" id="seafood"><option value="NA" '.(($addon->seafood == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->seafood == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->seafood == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Garlic</label> <select class="form-control" name="addon_garlic['.$menuId.']['.$key1.'][]" id="garlic"><option value="NA" '.(($addon->garlic == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->garlic == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->garlic == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Eggs</label> <select class="form-control" name="addon_eggs['.$menuId.']['.$key1.'][]" id="eggs"><option value="NA" '.(($addon->eggs == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->eggs == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->eggs == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Tarazine</label> <select class="form-control" name="addon_tartrazine['.$menuId.']['.$key1.'][]" id="tartrazine"><option value="NA" '.(($addon->tartrazine == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->tartrazine == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->tartrazine == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Onions</label> <select class="form-control" name="addon_onions['.$menuId.']['.$key1.'][]" id="onions"><option value="NA" '.(($addon->onions == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->onions == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->onions == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Animal Fats</label> <select class="form-control" name="addon_animal_fats_oils['.$menuId.']['.$key1.'][]" id="animal_fats_oils"><option value="NA">NA</option><option value="Y">Y</option><option value="N">N</option> </select></div><div class="col-md-2 form-group"><label>ShellFish</label> <select class="form-control" name="addon_shellfish['.$menuId.']['.$key1.'][]" id="shellfish"><option value="NA" '.(($addon->shellfish == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->shellfish == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->shellfish == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Fish</label> <select class="form-control" name="addon_fish['.$menuId.']['.$key1.'][]" id="fish"><option value="NA" '.(($addon->fish == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->fish == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->fish == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Sesama</label> <select class="form-control" name="addon_sesama['.$menuId.']['.$key1.'][]" id="sesama"><option value="NA" '.(($addon->sesama == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->sesama == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->sesama == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Dairy</label> <select class="form-control" name="addon_dairy['.$menuId.']['.$key1.'][]" id="dairy"><option value="NA" '.(($addon->dairy == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($addon->dairy == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($addon->dairy == 'N') ? "Selected" : "").'>N</option> </select></div><div class="clearfix"></div><hr class="clearfix" width="100%"><div class="col-md-2 form-group"><label>Saturated Fats</label> <input type="number" class="form-control" name="addon_saturated_fats['.$menuId.']['.$key1.'][]" id="saturated_fats" placeholder="saturated_fats" value="'.$addon->saturated_fats.'"></div><div class="col-md-2 form-group"><label>Vitamin A</label> <input type="number" class="form-control" name="addon_vitamin_a['.$menuId.']['.$key1.'][]" id="vitamin_a" placeholder="vitamin_a" value="'.$addon->vitamin_a.'"></div><div class="col-md-2 form-group"><label>Carbs</label> <input type="number" class="form-control" name="addon_carbs['.$menuId.']['.$key1.'][]" id="carbs" placeholder="carbs" value="'.$addon->carbs.'"></div><div class="col-md-2 form-group"><label>Vitamin C</label> <input type="number" class="form-control" name="addon_vitamin_c['.$menuId.']['.$key1.'][]" id="vitamin_c" placeholder="vitamin_c" value="'.$addon->vitamin_c.'"></div><div class="col-md-2 form-group"><label>Protien</label> <input type="number" class="form-control" name="addon_protein['.$menuId.']['.$key1.'][]" id="protein" placeholder="protein" value="'.$addon->protein.'"></div><div class="col-md-2 form-group"><label>Fat</label> <input type="number" class="form-control" name="addon_fat['.$menuId.']['.$key1.'][]" id="fat" placeholder="fat" value="'.$addon->fat.'"></div><div class="col-md-2 form-group"><label>Cholesterol</label> <input type="number" class="form-control" name="addon_cholesterol['.$menuId.']['.$key1.'][]" id="cholesterol" placeholder="cholesterol" value="'.$addon->cholesterol.'"></div><div class="col-md-2 form-group"><label>Fiber</label> <input type="number" class="form-control" name="addon_fiber['.$menuId.']['.$key1.'][]" id="fiber" placeholder="fiber" value="'.$addon->fiber.'"></div><div class="col-md-2 form-group"><label>Protien</label> <input type="number" class="form-control" name="addon_protein['.$menuId.']['.$key1.'][]" id="protein" placeholder="protein" value="'.$addon->protein.'"></div><div class="col-md-2 form-group"><label>Calcium</label> <input type="number" class="form-control" name="addon_calcium['.$menuId.']['.$key1.'][]" id="calcium" placeholder="calcium" value="'.$addon->calcium.'"></div><div class="col-md-2 form-group"><label>Calories</label> <input type="number" class="form-control" name="addon_calories['.$menuId.']['.$key1.'][]" id="calories" placeholder="calories" value="'.$addon->calories.'"></div><div class="col-md-2 form-group"><label>Sodium</label> <input type="number" class="form-control" name="addon_sodium['.$menuId.']['.$key1.'][]" id="sodium" placeholder="sodium" value="'.$addon->sodium.'"></div><div class="col-md-2 form-group"><label>Trans Fat</label> <input type="number" class="form-control" name="addon_trans_fat['.$menuId.']['.$key1.'][]" id="trans_fat" placeholder="trans_fat" value="'.$addon->trans_fat.'"></div><div class="col-md-2 form-group"><label>Iron</label> <input type="number" class="form-control" name="addon_iron['.$menuId.']['.$key1.'][]" id="iron" placeholder="iron" value="'.$addon->iron.'"></div><div class="col-md-2 form-group"><label>Sugar</label> <input type="number" class="form-control" name="addon_sugar['.$menuId.']['.$key1.'][]" id="sugar" placeholder="sugar" value="'.$addon->sugar.'"></div><div class="col-md-12"><label class="addon_remove btn btn-danger pull-right">Remove</label></div></div></div>';
                                }
                                }
                            }
                            
                            $main .= '</div>';
                        }
                    }
                    
                    $main .= '</div>';
                } else {
                    $menuId = '';
                }
            }
            echo $main;
        }
    }
        
    
    public function variationhtml(Request $request)
    {
        $menuname = $request->get('menuName');
        $newMenuString = str_replace('_', ' ', $menuname);

        $itemname = $request->get('itemName');
        
        $resturantData = $this->getUserResturant();
        
        if(isset($resturantData->restaurant[0]->JSONfile) && ($resturantData->restaurant[0]->JSONfile != '')) {
            $restaurantDetails = $resturantData->restaurant[0]->JSONfile;
            $jsonFiles = json_decode(file_get_contents($restaurantDetails));
            
            $main = '';
            foreach($jsonFiles as $key=>$jsonFile) {
                if ($jsonFile->name == trim($newMenuString)) {
                    
                    $main .= '<div class="menu-variation-content-div-cls" attr-menu="'.$menuname.'" id="menu_variation_content_div_'.$menuname.'" attr-menu-key="'.$key.'">';
                    
                    $menuId = $key;
                    $items = $jsonFiles[$menuId]->item;
                    
                    if(isset($items) && !empty($items)) {
                        foreach($items as $key1=>$item) {
                            $main .= '<div class="menu-item2-variation-content-cls" id="menu_item2_variation_content_cls_'.$menuname.'_'.$key1.'" attr-menu-key="'.$key.'" attr-item-key="'.$key1.'">';
                            
                            if(in_array($key1, $itemname)) {
                                if(isset($item->variation) && !empty($item->variation)) {
                                    $variations = $item->variation;
                                    foreach($variations as $key2=>$variation) {
                                        
                                        $glutenFreeNA = (($variation->gluten_free == 'NA') ? "Selected" : "");
                                        $glutenFreeY = (($variation->gluten_free == 'Y') ? "Selected" : "");
                                        $glutenFreeN = (($variation->gluten_free == 'N') ? "Selected" : "");
                                        
                                       $animalFatOilsNA = (($variation->animal_fats_oils == 'NA') ? "Selected" : "");
                                        $animalFatOilsY = (($variation->animal_fats_oils == 'Y') ? "Selected" : "");
                                        $animalFatOilsN = (($variation->animal_fats_oils == 'N') ? "Selected" : "");
                                        
                                        $sugar = $variation->sugar;
                                        $b = $menuname.'_'.$key1.'_'.$key2;
                                        
                                        $main.= '<div class="side-content-div-cls" attr-menu="'.$menuname.'" attr-item="'.$key1.'" attr-menu-key="'.$key.'" attr-slide="'.$key2.'" id="side_content_div_'.$b.'"><div class="item-content-div clearfix"><h5 class="menu_head hide">Menu '.$newMenuString.' AND Item '.$key1.'</h5><div class="variationform"><div class="col-md-4 form-group"><label>Name</label> <input type="text" class="form-control name variation-name-text" name="variation_name['.$menuId.']['.$key1.'][]" id="name" placeholder="name" value="'.$variation->name.'"><span class="variation_name_error"></span></div><div class="col-md-4 form-group"><label>Category</label> <input type="text" class="form-control" name="variation_category['.$menuId.']['.$key1.'][]" id="category" placeholder="category" value="'.$variation->category.'"></div><div class="col-md-4 form-group"><label>Price</label> <input type="number" class="form-control" name="variation_price['.$menuId.']['.$key1.'][]" id="price" placeholder="price" value="'.$variation->price.'"></div><div class="clearfix"></div><hr class="clearfix"><div class="col-md-2 form-group"><label>Glutten</label> <select class="form-control" name="variation_gluten_free['.$menuId.']['.$key1.'][]" id="gluten_free"><option value="NA" '.$glutenFreeNA.'>NA</option><option value="Y" '.$glutenFreeY.'>Y</option><option value="N" '.$glutenFreeN.'>N</option> </select></div><div class="col-md-2 form-group"><label>Kosher</label> <select class="form-control" name="variation_kosher['.$menuId.']['.$key1.'][]" id="kosher"><option value="NA" '.(($variation->kosher == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->kosher == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->kosher == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Halal</label> <select class="form-control" name="variation_halal['.$menuId.']['.$key1.'][]" id="halal"><option value="NA" '.(($variation->halal == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->halal == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->halal == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Vegan</label> <select class="form-control" name="variation_vegan['.$menuId.']['.$key1.'][]" id="vegan"><option value="NA" '.(($variation->vegan == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->vegan == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->vegan == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Vegetarian</label> <select class="form-control" name="variation_vegetarian['.$menuId.']['.$key1.'][]" id="vegetarian"><option value="NA" '.(($variation->vegetarian == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->vegetarian == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->vegetarian == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Spicy</label> <select class="form-control" name="variation_spicy['.$menuId.']['.$key1.'][]" id="spicy"><option value="NA" '.(($variation->spicy == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->spicy == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->spicy == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Ocean</label> <select class="form-control" name="variation_ocean_wise['.$menuId.']['.$key1.'][]" id="ocean_wise"><option value="NA" '.(($variation->ocean_wise == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->ocean_wise == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->ocean_wise == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Msg</label> <select class="form-control" name="variation_msg['.$menuId.']['.$key1.'][]" id="msg"><option value="NA" '.(($variation->msg == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->msg == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->msg == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Corn</label> <select class="form-control" name="variation_corn['.$menuId.']['.$key1.'][]" id="corn"><option value="NA" '.(($variation->corn == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->corn == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->corn == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Peanuts</label> <select class="form-control" name="variation_peanuts['.$menuId.']['.$key1.'][]" id="peanuts"><option value="NA" '.(($variation->peanuts == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->peanuts == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->peanuts == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Treenuts</label> <select class="form-control" name="variation_treenuts['.$menuId.']['.$key1.'][]" id="treenuts"><option value="NA" '.(($variation->treenuts == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->treenuts == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->treenuts == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Sulfites</label> <select class="form-control" name="variation_sulfites['.$menuId.']['.$key1.'][]" id="sulfites"><option value="NA" '.(($variation->sulfites == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->sulfites == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->sulfites == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Mustard</label> <select class="form-control" name="variation_mustard['.$menuId.']['.$key1.'][]" id="mustard"><option value="NA" '.(($variation->mustard == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->mustard == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->mustard == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Wheat</label> <select class="form-control" name="variation_wheat['.$menuId.']['.$key1.'][]" id="wheat"><option value="NA" '.(($variation->wheat == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->wheat == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->wheat == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Soy</label> <select class="form-control" name="variation_soy['.$menuId.']['.$key1.'][]" id="soy"><option value="NA" '.(($variation->soy == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->soy == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->soy == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Seafood</label> <select class="form-control" name="variation_seafood['.$menuId.']['.$key1.'][]" id="seafood"><option value="NA" '.(($variation->seafood == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->seafood == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->seafood == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Garlic</label> <select class="form-control" name="variation_garlic['.$menuId.']['.$key1.'][]" id="garlic"><option value="NA" '.(($variation->garlic == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->garlic == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->garlic == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Eggs</label> <select class="form-control" name="variation_eggs['.$menuId.']['.$key1.'][]" id="eggs"><option value="NA" '.(($variation->eggs == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->eggs == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->eggs == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Tarazine</label> <select class="form-control" name="variation_tartrazine['.$menuId.']['.$key1.'][]" id="tartrazine"><option value="NA" '.(($variation->tartrazine == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->tartrazine == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->tartrazine == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Onions</label> <select class="form-control" name="variation_onions['.$menuId.']['.$key1.'][]" id="onions"><option value="NA" '.(($variation->onions == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->onions == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->onions == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Animal Fats</label> <select class="form-control" name="variation_animal_fats_oils['.$menuId.']['.$key1.'][]" id="animal_fats_oils"><option value="NA" '.$animalFatOilsNA.'>NA</option><option value="Y" '.$animalFatOilsY.'>Y</option><option value="N" '.$animalFatOilsN.'>N</option> </select></div><div class="col-md-2 form-group"><label>ShellFish</label> <select class="form-control" name="variation_shellfish['.$menuId.']['.$key1.'][]" id="shellfish"><option value="NA" '.(($variation->shellfish == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->shellfish == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->shellfish == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Fish</label> <select class="form-control" name="variation_fish['.$menuId.']['.$key1.'][]" id="fish"><option value="NA" '.(($variation->fish == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->fish == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->fish == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Sesama</label> <select class="form-control" name="variation_sesama['.$menuId.']['.$key1.'][]" id="sesama"><option value="NA" '.(($variation->sesama == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->sesama == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->sesama == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Dairy</label> <select class="form-control" name="variation_dairy['.$menuId.']['.$key1.'][]" id="dairy"><option value="NA" '.(($variation->dairy == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($variation->dairy == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($variation->dairy == 'N') ? "Selected" : "").'>N</option> </select></div><div class="clearfix"></div><hr class="clearfix"><div class="col-md-2 form-group"><label>Saturated Fats</label> <input type="number" class="form-control" name="variation_saturated_fats['.$menuId.']['.$key1.'][]" id="saturated_fats" placeholder="saturated_fats" value="'.$variation->saturated_fats.'"></div><div class="col-md-2 form-group"><label>Vitamins</label> <input type="number" class="form-control" name="variation_vitamin_a['.$menuId.']['.$key1.'][]" id="vitamin_a" placeholder="vitamin_a" value="'.$variation->vitamin_a.'"></div><div class="col-md-2 form-group"><label>Carbs</label> <input type="number" class="form-control" name="variation_carbs['.$menuId.']['.$key1.'][]" id="carbs" placeholder="carbs" value="'.$variation->carbs.'"></div><div class="col-md-2 form-group"><label>Vitamin C</label> <input type="number" class="form-control" name="variation_vitamin_c['.$menuId.']['.$key1.'][]" id="vitamin_c" placeholder="vitamin_c" value="'.$variation->vitamin_c.'"></div><div class="col-md-2 form-group"><label>Protien</label> <input type="number" class="form-control" name="variation_protein['.$menuId.']['.$key1.'][]" id="protein" placeholder="protein"  value="'.$variation->protein.'"></div><div class="col-md-2 form-group"><label>Fat</label> <input type="number" class="form-control" name="variation_fat['.$menuId.']['.$key1.'][]" id="fat" placeholder="fat"  value="'.$variation->fat.'"></div><div class="col-md-2 form-group"><label>Cholesterol</label> <input type="number" class="form-control" name="variation_cholesterol['.$menuId.']['.$key1.'][]" id="cholesterol" placeholder="cholesterol" value="'.$variation->cholesterol.'"></div><div class="col-md-2 form-group"><label>Fiber</label> <input type="number" class="form-control" name="variation_fiber['.$menuId.']['.$key1.'][]" id="fiber" placeholder="fiber" value="'.$variation->fiber.'"></div><div class="col-md-2 form-group"><label>Protien</label> <input type="number" class="form-control" name="variation_protein['.$menuId.']['.$key1.'][]" id="protein" placeholder="protein" value="'.$variation->protein.'"></div><div class="col-md-2 form-group"><label>Calcium</label> <input type="number" class="form-control" name="variation_calcium['.$menuId.']['.$key1.'][]" id="calcium" placeholder="calcium"  value="'.$variation->calcium.'"></div><div class="col-md-2 form-group"><label>Calories</label><input type="number" class="form-control" name="variation_calories['.$menuId.']['.$key1.'][]" id="calories" placeholder="calories" value="'.$variation->calories.'"></div><div class="col-md-2 form-group"><label>Sodium</label> <input type="number" class="form-control" name="variation_sodium['.$menuId.']['.$key1.'][]" id="sodium" placeholder="sodium" value="'.$variation->sodium.'"></div><div class="col-md-2 form-group"><label>Trans Fat</label> <input type="number" class="form-control" name="variation_trans_fat['.$menuId.']['.$key1.'][]" id="trans_fat" placeholder="trans_fat" value="'.$variation->trans_fat.'"></div><div class="col-md-2 form-group"><label>Iron</label> <input type="number" class="form-control" name="variation_iron['.$menuId.']['.$key1.'][]" id="iron" placeholder="iron" value="'.$variation->iron.'"></div><div class="col-md-2 form-group"><label>Sugar</label> <input type="number" class="form-control" name="variation_sugar['.$menuId.']['.$key1.'][]" id="sugar" placeholder="sugar" value="'.$sugar.'"></div><div class="col-md-12"><label class="variation_remove btn btn-danger pull-right">Remove</label></div></div></hr></br></div></div>';
                                    }
                                }
                            }
                            $main .= '</div>';
                        }
                    }
                    
                    $main .= '</div>';
                } else {
                    $menuId = '';
                }
            }
            echo $main;
        }
    }
    
    
    public function toppinghtml(Request $request)
    {
        $menuname = $request->get('menuName');
        $newMenuString = str_replace('_', ' ', $menuname);

        $itemname = $request->get('itemName');
        
        $resturantData = $this->getUserResturant();
        if(isset($resturantData->restaurant[0]->JSONfile) && ($resturantData->restaurant[0]->JSONfile != '')) {
            $restaurantDetails = $resturantData->restaurant[0]->JSONfile;
            $jsonFiles = json_decode(file_get_contents($restaurantDetails));
            $main = '';
            
            foreach($jsonFiles as $key=>$jsonFile) {
                if ($jsonFile->name == trim($newMenuString)) {
                    
                    $main .= '<div class="menu-topping-content-div-cls" attr-menu="'.$menuname.'" id="menu_topping_content_div_'.$menuname.'" attr-menu-key="'.$key.'">';
                    $menuId = $key;
                    $items = $jsonFiles[$menuId]->item;
                    
                    if(isset($items) && !empty($items)) {
                        foreach($items as $key1=>$item) {
                            $main .= '<div class="menu-item2-topping-content-cls" id="menu_item2_topping_content_cls_'.$menuname.'_'.$key1.'" attr-menu-key="'.$key.'" attr-item-key="'.$key1.'">';
                            
                            if(in_array($key1, $itemname)) {
                                if(isset($item->topping) && !empty($item->topping)) {
                                    $toppings = $item->topping;
                                    foreach($toppings as $key2=>$topping) {
                                        
                                        $glutenFreeNA = (($topping->gluten_free == 'NA') ? "Selected" : "");
                                        $glutenFreeY = (($topping->gluten_free == 'Y') ? "Selected" : "");
                                        $glutenFreeN = (($topping->gluten_free == 'N') ? "Selected" : "");
                                        
                                       $animalFatOilsNA = (($topping->animal_fats_oils == 'NA') ? "Selected" : "");
                                        $animalFatOilsY = (($topping->animal_fats_oils == 'Y') ? "Selected" : "");
                                        $animalFatOilsN = (($topping->animal_fats_oils == 'N') ? "Selected" : "");
                                        
                                        
                                        $main .= '<div class="topping-content-div-cls" attr-menu="'.$menuname.'" attr-item="'.$key1.'" attr-menu-key="'.$key.'" attr-slide="'.$key2.'" id="side_content_div_'.$menuname.'_'.$key1.'_'.$key2.'"><div class="item-content-div clearfix"><h5 class="menu_head hide">Menutest AND Item 0</h5><div class="toppingform"><div class="col-md-4 form-group"><label>Name</label> <input type="text" class="form-control name topping-name-text" name="topping_name['.$menuId.']['.$key1.'][]" id="name" placeholder="name" value="'.$topping->name.'"><span class="topping_name_error"></span></div><div class="col-md-4 form-group"><label>Category</label> <input type="text" class="form-control" name="topping_category['.$menuId.']['.$key1.'][]" id="category" placeholder="category"  value="'.$topping->category.'"></div><div class="col-md-4 form-group"><label>Price</label> <input type="number" class="form-control" name="topping_price['.$menuId.']['.$key1.'][]" id="price" placeholder="price"  value="'.$topping->price.'"></div><div class="clearfix"></div><hr class="clearfix"><div class="col-md-2 form-group"><label>Glutten</label> <select class="form-control" name="topping_gluten_free['.$menuId.']['.$key1.'][]" id="gluten_free"><option value="NA" '.$glutenFreeNA.'>NA</option><option value="Y" '.$glutenFreeY.'>Y</option><option value="N" '.$glutenFreeN.'>N</option> </select></div><div class="col-md-2 form-group"><label>Kosher</label> <select class="form-control" name="topping_kosher['.$menuId.']['.$key1.'][]" id="kosher"><option value="NA" '.(($topping->kosher == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->kosher == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->kosher == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Halal</label> <select class="form-control" name="topping_halal['.$menuId.']['.$key1.'][]" id="halal"><option value="NA" '.(($topping->halal == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->halal == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->halal == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Vegan</label> <select class="form-control" name="topping_vegan['.$menuId.']['.$key1.'][]" id="vegan"><option value="NA" '.(($topping->vegan == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->vegan == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->vegan == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Vegetarian</label> <select class="form-control" name="topping_vegetarian['.$menuId.']['.$key1.'][]" id="vegetarian"><option value="NA" '.(($topping->vegetarian == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->vegetarian == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->vegetarian == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Spicy</label> <select class="form-control" name="topping_spicy['.$menuId.']['.$key1.'][]" id="spicy"><option value="NA" '.(($topping->spicy == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->spicy == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->spicy == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Ocean</label> <select class="form-control" name="topping_ocean_wise['.$menuId.']['.$key1.'][]" id="ocean_wise"><option value="NA" '.(($topping->ocean_wise == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->ocean_wise == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->ocean_wise == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Msg</label> <select class="form-control" name="topping_msg['.$menuId.']['.$key1.'][]" id="msg"><option value="NA" '.(($topping->msg == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->msg == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->msg == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Corn</label> <select class="form-control" name="topping_corn['.$menuId.']['.$key1.'][]" id="corn"><option value="NA" '.(($topping->corn == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->corn == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->corn == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Peanuts</label> <select class="form-control" name="topping_peanuts['.$menuId.']['.$key1.'][]" id="peanuts"><option value="NA" '.(($topping->peanuts == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->peanuts == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->peanuts == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Treenuts</label> <select class="form-control" name="topping_treenuts['.$menuId.']['.$key1.'][]" id="treenuts"><option value="NA" '.(($topping->treenuts == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->treenuts == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->treenuts == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Sulfites</label> <select class="form-control" name="topping_sulfites['.$menuId.']['.$key1.'][]" id="sulfites"><option value="NA" '.(($topping->sulfites == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->sulfites == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->sulfites == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Mustard</label> <select class="form-control" name="topping_mustard['.$menuId.']['.$key1.'][]" id="mustard"><option value="NA" '.(($topping->mustard == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->mustard == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->mustard == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Wheat</label> <select class="form-control" name="topping_wheat['.$menuId.']['.$key1.'][]" id="wheat"><option value="NA" '.(($topping->wheat == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->wheat == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->wheat == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Soy</label> <select class="form-control" name="topping_soy['.$menuId.']['.$key1.'][]" id="soy"><option value="NA" '.(($topping->soy == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->soy == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->soy == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Seafood</label> <select class="form-control" name="topping_seafood['.$menuId.']['.$key1.'][]" id="seafood"><option value="NA" '.(($topping->seafood == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->seafood == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->seafood == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Garlic</label> <select class="form-control" name="topping_garlic['.$menuId.']['.$key1.'][]" id="garlic"><option value="NA" '.(($topping->garlic == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->garlic == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->garlic == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Eggs</label> <select class="form-control" name="topping_eggs['.$menuId.']['.$key1.'][]" id="eggs"><option value="NA" '.(($topping->eggs == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->eggs == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->eggs == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Tarazine</label> <select class="form-control" name="topping_tartrazine['.$menuId.']['.$key1.'][]" id="tartrazine"><option value="NA" '.(($topping->tartrazine == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->tartrazine == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->tartrazine == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Onions</label> <select class="form-control" name="topping_onions['.$menuId.']['.$key1.'][]" id="onions"><option value="NA" '.(($topping->onions == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->onions == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->onions == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Animal Fats</label> <select class="form-control" name="topping_animal_fats_oils['.$menuId.']['.$key1.'][]" id="animal_fats_oils"><option value="NA" '.$animalFatOilsNA.'>NA</option><option value="Y" '.$animalFatOilsY.'>Y</option><option value="N" '.$animalFatOilsN.'>N</option></select></div><div class="col-md-2 form-group"><label>ShellFish</label> <select class="form-control" name="topping_shellfish['.$menuId.']['.$key1.'][]" id="shellfish"><option value="NA" '.(($topping->shellfish == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->shellfish == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->shellfish == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Fish</label> <select class="form-control" name="topping_fish['.$menuId.']['.$key1.'][]" id="fish"><option value="NA" '.(($topping->fish == 'NA') ? "Selected" : "").'>NA</option><option value="Y"'.(($topping->fish == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->fish == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Sesama</label> <select class="form-control" name="topping_sesama['.$menuId.']['.$key1.'][]" id="sesama"><option value="NA" '.(($topping->sesama == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->sesama == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->sesama == 'N') ? "Selected" : "").'>N</option> </select></div><div class="col-md-2 form-group"><label>Dairy</label> <select class="form-control" name="topping_dairy['.$menuId.']['.$key1.'][]" id="dairy"><option value="NA" '.(($topping->dairy == 'NA') ? "Selected" : "").'>NA</option><option value="Y" '.(($topping->dairy == 'Y') ? "Selected" : "").'>Y</option><option value="N" '.(($topping->dairy == 'N') ? "Selected" : "").'>N</option> </select></div><div class="clearfix"></div><hr class="clearfix"><div class="col-md-2 form-group"><label>Saturated Fats</label> <input type="number" class="form-control" name="topping_saturated_fats['.$menuId.']['.$key1.'][]" id="saturated_fats" placeholder="saturated_fats" value="'.$topping->saturated_fats.'"></div><div class="col-md-2 form-group"><label>Vitamins</label> <input type="number" class="form-control" name="topping_vitamin_a['.$menuId.']['.$key1.'][]" id="vitamin_a" placeholder="vitamin_a" value="'.$topping->vitamin_a.'"></div><div class="col-md-2 form-group"><label>Carbs</label> <input type="number" class="form-control" name="topping_carbs['.$menuId.']['.$key1.'][]" id="carbs" placeholder="carbs" value="'.$topping->carbs.'"></div><div class="col-md-2 form-group"><label>Vitamin C</label> <input type="number" class="form-control" name="topping_vitamin_c['.$menuId.']['.$key1.'][]" id="vitamin_c" placeholder="vitamin_c" value="'.$topping->vitamin_c.'"></div><div class="col-md-2 form-group"><label>Protien</label> <input type="number" class="form-control" name="topping_protein['.$menuId.']['.$key1.'][]" id="protein" placeholder="protein" value="'.$topping->protein.'"></div><div class="col-md-2 form-group"><label>Fat</label> <input type="number" class="form-control" name="topping_fat['.$menuId.']['.$key1.'][]" id="fat" placeholder="fat" value="'.$topping->fat.'"></div><div class="col-md-2 form-group"><label>Cholesterol</label> <input type="number" class="form-control" name="topping_cholesterol['.$menuId.']['.$key1.'][]" id="cholesterol" placeholder="cholesterol" value="'.$topping->cholesterol.'"></div><div class="col-md-2 form-group"><label>Fiber</label> <input type="number" class="form-control" name="topping_fiber['.$menuId.']['.$key1.'][]" id="fiber" placeholder="fiber" value="'.$topping->fiber.'"></div><div class="col-md-2 form-group"><label>Protien</label> <input type="number" class="form-control" name="topping_protein['.$menuId.']['.$key1.'][]" id="protein" placeholder="protein" value="'.$topping->protein.'"></div><div class="col-md-2 form-group"><label>Calcium</label> <input type="number" class="form-control" name="topping_calcium['.$menuId.']['.$key1.'][]" id="calcium" placeholder="calcium" value="'.$topping->calcium.'"></div><div class="col-md-2 form-group"><label>Calories</label> <input type="number" class="form-control" name="topping_calories['.$menuId.']['.$key1.'][]" id="calories" placeholder="calories"  value="'.$topping->calories.'"></div><div class="col-md-2 form-group"><label>Sodium</label> <input type="number" class="form-control" name="topping_sodium['.$menuId.']['.$key1.'][]" id="sodium" placeholder="sodium" value="'.$topping->sodium.'"></div><div class="col-md-2 form-group"><label>Trans Fat</label> <input type="number" class="form-control" name="topping_trans_fat['.$menuId.']['.$key1.'][]" id="trans_fat" placeholder="trans_fat" value="'.$topping->trans_fat.'"></div><div class="col-md-2 form-group"><label>Iron</label> <input type="number" class="form-control" name="topping_iron['.$menuId.']['.$key1.'][]" id="iron" placeholder="iron" value="'.$topping->iron.'"></div><div class="col-md-2 form-group"><label>Sugar</label> <input type="number" class="form-control" name="topping_sugar['.$menuId.']['.$key1.'][]" id="sugar" placeholder="sugar" value="'.$topping->sugar.'"></div><div class="col-md-12"><label class="topping_remove btn btn-danger pull-right">Remove</label></div></div></hr></br></div></div>';
                                    }
                                }
                            }
                            $main .= '</div>';
                        }
                    }
                    
                    $main .= '</div>';
                } else {
                    $menuId = '';
                }
            }
            echo $main;
        }
    }
    
    public function itemhtml(Request $request)
    {
        $menuname = $request->get('menuName');
        $newMenuString = str_replace(' ', '_', $menuname);
        
        $resturantData = $this->getUserResturant();
        
        if(isset($resturantData->restaurant[0]->JSONfile) && ($resturantData->restaurant[0]->JSONfile != '')) {
            $restaurantDetails = $resturantData->restaurant[0]->JSONfile;
            $jsonFiles = json_decode(file_get_contents($restaurantDetails));
           
            $res = '';
            foreach($jsonFiles as $key=>$jsonFile) {
                
                if ($jsonFile->name == trim($menuname))
                {
                    
                    $res .= '<div class="item-content-div-cls" attr-menu="'.$newMenuString.'" id="item_content_div_'.$newMenuString.'" attr-menu-key="'.$key.'">';
                    
                    if(isset($jsonFiles[$key]->item) && !empty($jsonFiles[$key]->item)) {
                        $items = $jsonFiles[$key]->item;
                       
                        foreach($items as $key1=>$item) {
                            
                            $glutenFreeNA = ((isset($item->gluten_free) && ($item->gluten_free == 'NA')) ? "Selected" : "");
                            $glutenFreeY = ((isset($item->gluten_free) && ($item->gluten_free == 'Y')) ? "Selected" : "");
                            $glutenFreeN = ((isset($item->gluten_free) && ($item->gluten_free == 'N')) ? "Selected" : "");
                            
                           $animalFatOilsNA = ((isset($item->animal_fats_oils) && ($item->animal_fats_oils == 'NA')) ? "Selected" : "");
                            $animalFatOilsY = ((isset($item->animal_fats_oils) && ($item->animal_fats_oils == 'Y')) ? "Selected" : "");
                            $animalFatOilsN = ((isset($item->animal_fats_oils) && ($item->animal_fats_oils == 'N')) ? "Selected" : "");
                            $newclass = 'itemnametext_'.$newMenuString.'_'.$key1;
                            
                             $res .= '<div class="item-content-div clearfix" attr-item-key="'.$key1.'" attr-menu-key="'.$key.'"><h5 attr-val="'.$newMenuString.'" class="menu_head">'.$jsonFile->name.'</h5><div attritemcount="'.$newMenuString.'" class="itemform itemform_'.$newMenuString.'" id="itemform_'.$newMenuString.'"><div class="col-md-4 form-group"><label>Name</label> <input type="text" class="form-control name item-menu-text '.$newclass.' name_'.$newMenuString.'" name="name['.$key.']['.$key1.'][]" id="name" placeholder="name" value="'.$item->name.'"><span class="item_name_error"></span></div><div class="col-md-4 form-group"><label>Category</label><input type="text" class="form-control" name="category['.$key.']['.$key1.'][]" id="category" placeholder="category" value="'.$item->name.'"></div><div class="col-md-4 form-group"> <label>Price</label> <input type="number" class="form-control" name="price['.$key.']['.$key1.'][]" id="price" placeholder="price" value="'.$item->price.'"></div><hr class="clearfix" width="100%"><div class="col-md-2 form-group"><label>Gluten Free</label> <select class="form-control" name="gluten_free['.$key.']['.$key1.'][]" id="gluten_free"><option value="NA" '.$glutenFreeNA.'>NA</option><option value="Y" '.$glutenFreeY.'>Y</option><option value="N" '.$glutenFreeN.'>N</option> </select></div><div class="col-md-2 form-group"><label>Kosher</label> <select class="form-control" name="kosher['.$key.']['.$key1.'][]" id="kosher"><option '.(($item->kosher == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->kosher == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->kosher == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Halal</label> <select class="form-control" name="halal['.$key.']['.$key1.'][]" id="halal"><option '.(($item->halal == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->halal == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->halal == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Vegan</label> <select class="form-control" name="vegan['.$key.']['.$key1.'][]" id="vegan"><option '.(($item->vegan == 'N') ? "Selected" : "").' value="NA">NA</option><option '.(($item->vegan == 'N') ? "Selected" : "").' value="Y">Y</option><option '.(($item->vegan == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Vegetarian</label> <select class="form-control" name="vegetarian['.$key.']['.$key1.'][]" id="vegetarian"><option '.(($item->vegetarian == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->vegetarian == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->vegetarian == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Spicy</label><select class="form-control" name="spicy['.$key.']['.$key1.'][]" id="spicy"><option '.(($item->spicy == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->spicy == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->spicy == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Ocean Wise</label> <select class="form-control" name="ocean_wise['.$key.']['.$key1.'][]" id="ocean_wise"><option '.(($item->ocean_wise == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->ocean_wise == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->ocean_wise == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Msg</label> <select class="form-control" name="msg['.$key.']['.$key1.'][]" id="msg"><option '.(($item->msg == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->msg == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->msg == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Corn</label><select class="form-control" name="corn['.$key.']['.$key1.'][]" id="corn"><option '.(($item->corn == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->corn == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->corn == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Peanuts</label> <select class="form-control" name="peanuts['.$key.']['.$key1.'][]" id="peanuts"><option '.(($item->peanuts == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->peanuts == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->peanuts == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Treenuts</label> <select class="form-control" name="treenuts['.$key.']['.$key1.'][]" id="treenuts"><option '.(($item->treenuts == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->treenuts == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->treenuts == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Sulfites</label> <select class="form-control" name="sulfites['.$key.']['.$key1.'][]" id="sulfites"><option '.(($item->sulfites == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->sulfites == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->sulfites == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Mustard</label> <select class="form-control" name="mustard['.$key.']['.$key1.'][]" id="mustard"><option '.(($item->mustard == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->mustard == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->mustard == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Wheat</label> <select class="form-control" name="wheat['.$key.']['.$key1.'][]" id="wheat"><option '.(($item->wheat == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->wheat == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->wheat == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Soy</label> <select class="form-control" name="soy['.$key.']['.$key1.'][]" id="soy"><option '.(($item->soy == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->soy == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->soy == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Seafood</label> <select class="form-control" name="seafood['.$key.']['.$key1.'][]" id="seafood"><option '.(($item->seafood == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->seafood == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->seafood == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Garlic</label> <select class="form-control" name="garlic['.$key.']['.$key1.'][]" id="garlic"><option '.(($item->garlic == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->garlic == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->garlic == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Eggs</label> <select class="form-control" name="eggs['.$key.']['.$key1.'][]" id="eggs"><option '.(($item->eggs == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->eggs == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->eggs == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Tartrazine</label> <select class="form-control" name="tartrazine['.$key.']['.$key1.'][]" id="tartrazine"><option '.(($item->tartrazine == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->tartrazine == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->tartrazine == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Onions</label> <select class="form-control" name="onions['.$key.']['.$key1.'][]" id="onions"><option '.(($item->onions == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->onions == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->onions == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Animal Fats Oils</label> <select class="form-control" name="animal_fats_oils['.$key.']['.$key1.'][]" id="animal_fats_oils"><option value="NA" '.$animalFatOilsNA.'>NA</option><option value="Y" '.$animalFatOilsY.'>Y</option><option value="N" '.$animalFatOilsN.'>N</option></select></div><div class="col-md-2 form-group"><label>Shellfish</label> <select class="form-control" name="shellfish['.$key.']['.$key1.'][]" id="shellfish"><option '.(($item->shellfish == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->shellfish == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->shellfish == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Fish</label> <select class="form-control" name="fish['.$key.']['.$key1.'][]" id="fish"><option '.(($item->fish == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->fish == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->fish == 'N') ? "Selected" : "").' value="N">N</option></select></div><div class="col-md-2 form-group"><label>Sesama</label> <select class="form-control" name="sesama['.$key.']['.$key1.'][]" id="sesama"><option '.(($item->sesama == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->sesama == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->sesama == 'N') ? "Selected" : "").' value="N">N</option> </select></div><div class="col-md-2 form-group"><label>Dairy</label> <select class="form-control" name="dairy['.$key.']['.$key1.'][]" id="dairy"><option '.(($item->dairy == 'NA') ? "Selected" : "").' value="NA">NA</option><option '.(($item->dairy == 'Y') ? "Selected" : "").' value="Y">Y</option><option '.(($item->dairy == 'N') ? "Selected" : "").' value="N">N</option> </select></div><hr class="clearfix" width="100%"><div class="col-md-2 form-group"><label>Saturated Fats</label> <input type="number" class="form-control" value="'.$item->saturated_fats.'" name="saturated_fats['.$key.']['.$key1.'][]" id="saturated_fats" placeholder="saturated_fats"></div><div class="col-md-2 form-group"><label>Vitamin A</label> <input type="number" class="form-control" value="'.$item->vitamin_a.'" name="vitamin_a['.$key.']['.$key1.'][]" id="vitamin_a" placeholder="vitamin_a"></div><div class="col-md-2 form-group"><label>Carbs</label> <input type="number" value="'.$item->carbs.'" class="form-control" name="carbs['.$key.']['.$key1.'][]" id="carbs" placeholder="carbs"></div><div class="col-md-2 form-group"><label></label> <input type="number" value="'.$item->vitamin_c.'" class="form-control" name="vitamin_c['.$key.']['.$key1.'][]" id="vitamin_c" placeholder="vitamin_c"></div><div class="col-md-2 form-group"><label>Protein</label> <input type="number" value="'.$item->protein.'" class="form-control" name="protein['.$key.']['.$key1.'][]" id="protein" placeholder="protein"></div><div class="col-md-2 form-group"><label>Fat</label> <input type="number" class="form-control" name="fat['.$key.']['.$key1.'][]" id="fat" placeholder="fat"></div><div class="col-md-2 form-group"><label>Cholesterol</label> <input type="number" value="'.$item->cholesterol.'" class="form-control" name="cholesterol['.$key.']['.$key1.'][]" id="cholesterol" placeholder="cholesterol"></div><div class="col-md-2 form-group"><label>Fiber</label> <input value="'.$item->fiber.'" type="number" class="form-control" name="fiber['.$key.']['.$key1.'][]" id="fiber" placeholder="fiber"></div><div class="col-md-2 form-group"><label>Protien</label><input type="text" value="'.$item->protein.'" class="form-control" name="protein['.$key.']['.$key1.'][]" id="protein" placeholder="protein"></div><div class="col-md-2 form-group"><label>Calcium</label><input type="number" value="'.$item->calcium.'" class="form-control" name="calcium['.$key.']['.$key1.'][]" id="calcium" placeholder="calcium"></div><div class="col-md-2 form-group"><label>Calories</label><input type="number" class="form-control" id="calories" placeholder="calories" name="calories['.$key.']['.$key1.'][]" value="'.$item->calories.'"></div><div class="col-md-2 form-group"><label>Sodium</label><input type="number" class="form-control" id="sodium" placeholder="sodium" name="calories['.$key.']['.$key1.'][]" value="'.$item->sodium.'"></div><div class="col-md-2 form-group"><label>Trans Fat</label><input type="number" class="form-control" id="trans_fat" placeholder="trans_fat" name="trans_fat['.$key.']['.$key1.'][]" value="'.$item->trans_fat.'"></div><div class="col-md-2 form-group"><label>Iron</label><input type="number" class="form-control" id="iron" placeholder="iron" name="iron['.$key.']['.$key1.'][]" value="'.$item->iron.'"></div><div class="col-md-2 form-group"><label>Sugar</label> <input type="number" class="form-control" id="sugar" placeholder="sugar" name="sugar['.$key.']['.$key1.'][]" value="'.$item->sugar.'"></div></div></br><div class="col-md-12"><label class="item_remove btn btn-danger pull-right">Remove</label></div></div>';
                        }
                    }
                    $res .= '</div>';
                    
                } else {
                    //$res = '';
                }
            }
        }
        echo $res;
    }
}






<?php

namespace App\Helper;
namespace App\Http\Controllers;

use Session;
use Illuminate\Http\Request;

class LoginController extends Controller
{
	public function __construct()
    {
         //$this->middleware('checkRole');
    }

    public function index()
    {
        $value = session()->get('loginUser');

        if(isset($value)) {
            if($value->headquarter == '') {
                return redirect(route('admin.dashboard'));
            } else {
                return redirect(route('dashboard'));
            }
        } else {
            return view('login');
        }
    }

    public function registrationForm()
    {
        $value = session()->get('loginUser');

        if(isset($value)) {
            if($value->headquarter == '') {
                return redirect(route('admin.dashboard'));
            } else {
                return redirect(route('dashboard'));
            }
        } else {
            return view('registration'); 
        }
    }


    public function login(Request $request)
    {
        $appId = config('constants.BACKENDLESS_APP_ID');
        $apiKey = config('constants.BACKENDLESS_REST_API_KEY');
        
        $url = 'https://api.backendless.com/'.$appId.'/'.$apiKey.'/users/login';
    	$postData = array(
		        'password' => $request->password,
		        'login' => $request->email
		    );
    	$response = curlPostFun($url, $postData);
    	$jsonData = json_decode($response);

    	if((isset($jsonData->lastLogin) && ($jsonData->lastLogin != ''))) {

    		session()->put('loginUser', $jsonData);

            $value = session()->get('loginUser');

    		if((isset($value) && ($value->headquarter != ''))) {
	            return redirect('/dashboard');
	        } else if((isset($value) && ($value->headquarter == ''))) {
	            return redirect('/admin');
	        } else {
	        	return redirect('/');
	        }
    	} else {
    		return redirect('/');
    	}
    }

    public function registration(Request $request)
    {
        $appId = config('constants.BACKENDLESS_APP_ID');
        $apiKey = config('constants.BACKENDLESS_REST_API_KEY');
        
    	$url = 'https://api.backendless.com/'.$appId.'/'.$apiKey.'/users/register';
    	$postData = array(
		        'name' => $request->name,
		        'password' => $request->password,
		        'email' => $request->email,
		        'role' => true
		    );
        print_r($postData);
    	$response = curlPostFun($url, $postData);
    	$jsonData = json_decode($response);
        print_r($jsonData);
        die;
		if(isset($jsonData) && (isset($jsonData->objectId)))
		{
			return redirect('/');
		} else {
			return redirect('/registration');
		}
    }
}
